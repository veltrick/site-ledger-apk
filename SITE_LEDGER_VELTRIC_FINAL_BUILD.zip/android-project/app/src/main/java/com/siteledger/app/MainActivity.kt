package com.siteledger.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.siteledger.app.data.repository.SqliteSiteLedgerRepository
import com.siteledger.app.ui.SiteLedgerViewModel
import com.siteledger.app.ui.navigation.SiteLedgerApp
import com.siteledger.app.ui.screens.VeltricSplashScreen
import com.siteledger.app.ui.theme.SiteLedgerTheme

class MainActivity : ComponentActivity() {

    private val sqliteRepository by lazy {
        SqliteSiteLedgerRepository(applicationContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SiteLedgerTheme {
                val vm: SiteLedgerViewModel = viewModel(
                    factory = SiteLedgerViewModel.Factory(sqliteRepository)
                )
                var showSplash by rememberSaveable { mutableStateOf(true) }

                Box(modifier = Modifier.fillMaxSize()) {
                    SiteLedgerApp(viewModel = vm)

                    AnimatedVisibility(
                        visible = showSplash,
                        exit = fadeOut(animationSpec = tween(durationMillis = 300))
                    ) {
                        VeltricSplashScreen(
                            onSplashComplete = { showSplash = false }
                        )
                    }
                }
            }
        }
    }
}
