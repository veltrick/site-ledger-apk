package com.siteledger.app.data.local

import com.siteledger.app.domain.model.DEFAULT_SITE_ID

/**
 * Offline SQLite schema contract for SITE LEDGER.
 * - v1: initial tables
 * - v2: nullable photo_path on workers
 * - v3: worker profile fields, attendance duty snapshots, duty_settings, attendance/payment audit logs
 * - v4: applicable_period & payment_type on payment_ledger, payroll_periods, advances,
 *       payment_allocations, payroll_audit_log, and performance indexes for 500+ workers.
 * - v5: expanded 8 official duty types (0.5, 1.0, 1.5, 2.0, 2.5, 3.0, Absent, Leave) in duty_settings.
 * - v6: Phase 2 & 3 — Multi-site construction management (sites, worker_site_history,
 *       site_id scoping across workers/attendance/payments/advances/allocations/payroll_periods/audits,
 *       UNIQUE(site_id, local_worker_code), expenses & receipt storage, user_site_assignments,
 *       backup_history, and sync_events readiness table).
 */
object SiteLedgerDatabaseContract {
    const val DATABASE_NAME = "site_ledger_offline.db"
    const val DATABASE_VERSION = 6

    object SitesTable {
        const val TABLE_NAME = "sites"
        const val COL_SITE_ID = "site_id"
        const val COL_SITE_NAME = "site_name"
        const val COL_SITE_CODE = "site_code"
        const val COL_DESCRIPTION = "description"
        const val COL_ADDRESS = "address"
        const val COL_CLIENT_NAME = "client_name"
        const val COL_SITE_MANAGER = "site_manager"
        const val COL_START_DATE_ISO = "start_date_iso"
        const val COL_EXPECTED_COMPLETION_ISO = "expected_completion_date_iso"
        const val COL_STATUS = "status"
        const val COL_NOTES = "notes"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_SITE_ID TEXT PRIMARY KEY,
                $COL_SITE_NAME TEXT NOT NULL,
                $COL_SITE_CODE TEXT NOT NULL UNIQUE,
                $COL_DESCRIPTION TEXT NOT NULL DEFAULT '',
                $COL_ADDRESS TEXT NOT NULL DEFAULT '',
                $COL_CLIENT_NAME TEXT NOT NULL DEFAULT '',
                $COL_SITE_MANAGER TEXT NOT NULL DEFAULT '',
                $COL_START_DATE_ISO TEXT NOT NULL DEFAULT '2026-08-01',
                $COL_EXPECTED_COMPLETION_ISO TEXT,
                $COL_STATUS TEXT NOT NULL DEFAULT 'ACTIVE',
                $COL_NOTES TEXT NOT NULL DEFAULT ''
            )
        """
    }

    object WorkersTable {
        const val TABLE_NAME = "workers"
        const val COL_ID = "worker_id"
        const val COL_SITE_ID = "site_id"
        const val COL_LOCAL_WORKER_CODE = "local_worker_code"
        const val COL_FULL_NAME_EN = "full_name_en"
        const val COL_FULL_NAME_BN = "full_name_bn"
        const val COL_PHONE_NUMBER = "phone_number"
        const val COL_CATEGORY = "work_category"
        const val COL_JOINING_DATE = "joining_date"
        const val COL_LEAVING_DATE = "leaving_date"
        const val COL_DAILY_WAGE = "daily_wage"
        const val COL_DAILY_FOOD_ALLOWANCE = "daily_food_allowance"
        const val COL_IS_ACTIVE = "is_active"
        const val COL_AVATAR_KEY = "avatar_key"
        const val COL_PHOTO_PATH = "photo_path"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_ID TEXT PRIMARY KEY,
                $COL_SITE_ID TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID',
                $COL_LOCAL_WORKER_CODE TEXT NOT NULL,
                $COL_FULL_NAME_EN TEXT NOT NULL,
                $COL_FULL_NAME_BN TEXT NOT NULL,
                $COL_PHONE_NUMBER TEXT NOT NULL DEFAULT '',
                $COL_CATEGORY TEXT NOT NULL,
                $COL_JOINING_DATE TEXT NOT NULL DEFAULT '2026-11-01',
                $COL_LEAVING_DATE TEXT,
                $COL_DAILY_WAGE INTEGER NOT NULL,
                $COL_DAILY_FOOD_ALLOWANCE INTEGER NOT NULL DEFAULT 0,
                $COL_IS_ACTIVE INTEGER NOT NULL DEFAULT 1,
                $COL_AVATAR_KEY TEXT NOT NULL DEFAULT 'default',
                $COL_PHOTO_PATH TEXT,
                FOREIGN KEY ($COL_SITE_ID) REFERENCES ${SitesTable.TABLE_NAME}(${SitesTable.COL_SITE_ID})
            )
        """
    }

    object WorkerSiteHistoryTable {
        const val TABLE_NAME = "worker_site_history"
        const val COL_TRANSFER_ID = "transfer_id"
        const val COL_WORKER_ID = "worker_id"
        const val COL_PREVIOUS_SITE_ID = "previous_site_id"
        const val COL_NEW_SITE_ID = "new_site_id"
        const val COL_TRANSFER_DATE_ISO = "transfer_date_iso"
        const val COL_AUTHORIZED_BY_ROLE = "authorized_by_role"
        const val COL_NOTES = "notes"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_TRANSFER_ID TEXT PRIMARY KEY,
                $COL_WORKER_ID TEXT NOT NULL,
                $COL_PREVIOUS_SITE_ID TEXT NOT NULL,
                $COL_NEW_SITE_ID TEXT NOT NULL,
                $COL_TRANSFER_DATE_ISO TEXT NOT NULL,
                $COL_AUTHORIZED_BY_ROLE TEXT NOT NULL,
                $COL_NOTES TEXT NOT NULL DEFAULT '',
                FOREIGN KEY ($COL_WORKER_ID) REFERENCES ${WorkersTable.TABLE_NAME}(${WorkersTable.COL_ID})
            )
        """
    }

    object AttendanceTable {
        const val TABLE_NAME = "attendance_records"
        const val COL_SITE_ID = "site_id"
        const val COL_DATE_ISO = "date_iso"
        const val COL_WORKER_ID = "worker_id"
        const val COL_STATUS = "status"
        const val COL_DUTY_TYPE = "duty_type"
        const val COL_DAILY_WAGE_SNAPSHOT = "daily_wage_snapshot"
        const val COL_MULTIPLIER_SNAPSHOT = "multiplier_snapshot"
        const val COL_EARNED_AMOUNT = "earned_amount"
        const val COL_NOTE = "note"
        const val COL_UPDATED_AT_ISO = "updated_at_iso"
        const val COL_UPDATED_BY_ROLE = "updated_by_role"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_SITE_ID TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID',
                $COL_DATE_ISO TEXT NOT NULL,
                $COL_WORKER_ID TEXT NOT NULL,
                $COL_STATUS TEXT NOT NULL,
                $COL_DUTY_TYPE TEXT NOT NULL DEFAULT 'FULL_DUTY',
                $COL_DAILY_WAGE_SNAPSHOT INTEGER NOT NULL DEFAULT 0,
                $COL_MULTIPLIER_SNAPSHOT REAL NOT NULL DEFAULT 1.0,
                $COL_EARNED_AMOUNT INTEGER NOT NULL DEFAULT 0,
                $COL_NOTE TEXT NOT NULL DEFAULT '',
                $COL_UPDATED_AT_ISO TEXT NOT NULL DEFAULT '',
                $COL_UPDATED_BY_ROLE TEXT NOT NULL DEFAULT 'ADMIN',
                PRIMARY KEY ($COL_SITE_ID, $COL_DATE_ISO, $COL_WORKER_ID),
                FOREIGN KEY ($COL_SITE_ID) REFERENCES ${SitesTable.TABLE_NAME}(${SitesTable.COL_SITE_ID}),
                FOREIGN KEY ($COL_WORKER_ID) REFERENCES ${WorkersTable.TABLE_NAME}(${WorkersTable.COL_ID})
            )
        """
    }

    object PaymentsTable {
        const val TABLE_NAME = "payment_ledger"
        const val COL_ENTRY_ID = "entry_id"
        const val COL_SITE_ID = "site_id"
        const val COL_WORKER_ID = "worker_id"
        const val COL_DATE_ISO = "date_iso"
        const val COL_APPLICABLE_PERIOD = "applicable_period"
        const val COL_PAYMENT_TYPE = "payment_type"
        const val COL_DAILY_AMOUNT = "daily_amount"
        const val COL_PAID_AMOUNT = "paid_amount"
        const val COL_STATUS = "payment_status"
        const val COL_REFERENCE_NO = "reference_no"
        const val COL_NOTE_EN = "note_en"
        const val COL_NOTE_BN = "note_bn"
        const val COL_RECORDED_BY_ROLE = "recorded_by_role"
        const val COL_CREATED_AT_ISO = "created_at_iso"
        const val COL_IS_VOIDED = "is_voided"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_ENTRY_ID TEXT PRIMARY KEY,
                $COL_SITE_ID TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID',
                $COL_WORKER_ID TEXT NOT NULL,
                $COL_DATE_ISO TEXT NOT NULL,
                $COL_APPLICABLE_PERIOD TEXT NOT NULL DEFAULT '',
                $COL_PAYMENT_TYPE TEXT NOT NULL DEFAULT 'SALARY',
                $COL_DAILY_AMOUNT INTEGER NOT NULL DEFAULT 0,
                $COL_PAID_AMOUNT INTEGER NOT NULL,
                $COL_STATUS TEXT NOT NULL DEFAULT 'PAID',
                $COL_REFERENCE_NO TEXT NOT NULL DEFAULT '',
                $COL_NOTE_EN TEXT,
                $COL_NOTE_BN TEXT,
                $COL_RECORDED_BY_ROLE TEXT NOT NULL DEFAULT 'ADMIN',
                $COL_CREATED_AT_ISO TEXT NOT NULL DEFAULT '',
                $COL_IS_VOIDED INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY ($COL_SITE_ID) REFERENCES ${SitesTable.TABLE_NAME}(${SitesTable.COL_SITE_ID}),
                FOREIGN KEY ($COL_WORKER_ID) REFERENCES ${WorkersTable.TABLE_NAME}(${WorkersTable.COL_ID})
            )
        """
    }

    object AdvancesTable {
        const val TABLE_NAME = "advances"
        const val COL_ADVANCE_ID = "advance_id"
        const val COL_SITE_ID = "site_id"
        const val COL_WORKER_ID = "worker_id"
        const val COL_ADVANCE_DATE_ISO = "advance_date_iso"
        const val COL_AMOUNT = "amount"
        const val COL_REFERENCE_NO = "reference_no"
        const val COL_NOTE = "note"
        const val COL_RECORDED_BY_ROLE = "recorded_by_role"
        const val COL_CREATED_AT_ISO = "created_at_iso"
        const val COL_IS_VOIDED = "is_voided"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_ADVANCE_ID TEXT PRIMARY KEY,
                $COL_SITE_ID TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID',
                $COL_WORKER_ID TEXT NOT NULL,
                $COL_ADVANCE_DATE_ISO TEXT NOT NULL,
                $COL_AMOUNT INTEGER NOT NULL,
                $COL_REFERENCE_NO TEXT NOT NULL DEFAULT '',
                $COL_NOTE TEXT NOT NULL DEFAULT '',
                $COL_RECORDED_BY_ROLE TEXT NOT NULL DEFAULT 'ADMIN',
                $COL_CREATED_AT_ISO TEXT NOT NULL DEFAULT '',
                $COL_IS_VOIDED INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY ($COL_SITE_ID) REFERENCES ${SitesTable.TABLE_NAME}(${SitesTable.COL_SITE_ID}),
                FOREIGN KEY ($COL_WORKER_ID) REFERENCES ${WorkersTable.TABLE_NAME}(${WorkersTable.COL_ID})
            )
        """
    }

    object PaymentAllocationsTable {
        const val TABLE_NAME = "payment_allocations"
        const val COL_ALLOCATION_ID = "allocation_id"
        const val COL_SITE_ID = "site_id"
        const val COL_SOURCE_TYPE = "source_type"
        const val COL_SOURCE_ID = "source_id"
        const val COL_WORKER_ID = "worker_id"
        const val COL_PAYROLL_PERIOD = "payroll_period"
        const val COL_ALLOCATED_AMOUNT = "allocated_amount"
        const val COL_ALLOCATED_AT_ISO = "allocated_at_iso"
        const val COL_ALLOCATED_BY_ROLE = "allocated_by_role"
        const val COL_NOTE = "note"
        const val COL_IS_VOIDED = "is_voided"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_ALLOCATION_ID TEXT PRIMARY KEY,
                $COL_SITE_ID TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID',
                $COL_SOURCE_TYPE TEXT NOT NULL,
                $COL_SOURCE_ID TEXT NOT NULL,
                $COL_WORKER_ID TEXT NOT NULL,
                $COL_PAYROLL_PERIOD TEXT NOT NULL,
                $COL_ALLOCATED_AMOUNT INTEGER NOT NULL,
                $COL_ALLOCATED_AT_ISO TEXT NOT NULL,
                $COL_ALLOCATED_BY_ROLE TEXT NOT NULL,
                $COL_NOTE TEXT NOT NULL DEFAULT '',
                $COL_IS_VOIDED INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY ($COL_SITE_ID) REFERENCES ${SitesTable.TABLE_NAME}(${SitesTable.COL_SITE_ID}),
                FOREIGN KEY ($COL_WORKER_ID) REFERENCES ${WorkersTable.TABLE_NAME}(${WorkersTable.COL_ID})
            )
        """
    }

    object PayrollPeriodsTable {
        const val TABLE_NAME = "payroll_periods"
        const val COL_SITE_ID = "site_id"
        const val COL_PERIOD_ISO = "period_iso"
        const val COL_STATUS = "status"
        const val COL_FINALIZED_AT_ISO = "finalized_at_iso"
        const val COL_FINALIZED_BY_ROLE = "finalized_by_role"
        const val COL_REOPENED_AT_ISO = "reopened_at_iso"
        const val COL_REOPENED_BY_ROLE = "reopened_by_role"
        const val COL_NOTES = "notes"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_SITE_ID TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID',
                $COL_PERIOD_ISO TEXT NOT NULL,
                $COL_STATUS TEXT NOT NULL DEFAULT 'OPEN',
                $COL_FINALIZED_AT_ISO TEXT,
                $COL_FINALIZED_BY_ROLE TEXT,
                $COL_REOPENED_AT_ISO TEXT,
                $COL_REOPENED_BY_ROLE TEXT,
                $COL_NOTES TEXT NOT NULL DEFAULT '',
                PRIMARY KEY ($COL_SITE_ID, $COL_PERIOD_ISO),
                FOREIGN KEY ($COL_SITE_ID) REFERENCES ${SitesTable.TABLE_NAME}(${SitesTable.COL_SITE_ID})
            )
        """
    }

    object PayrollAuditTable {
        const val TABLE_NAME = "payroll_audit_log"
        const val COL_AUDIT_ID = "audit_id"
        const val COL_SITE_ID = "site_id"
        const val COL_PERIOD_ISO = "period_iso"
        const val COL_ACTION = "action"
        const val COL_CHANGED_BY_ROLE = "changed_by_role"
        const val COL_CHANGED_AT_ISO = "changed_at_iso"
        const val COL_REASON = "reason"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_AUDIT_ID TEXT PRIMARY KEY,
                $COL_SITE_ID TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID',
                $COL_PERIOD_ISO TEXT NOT NULL,
                $COL_ACTION TEXT NOT NULL,
                $COL_CHANGED_BY_ROLE TEXT NOT NULL,
                $COL_CHANGED_AT_ISO TEXT NOT NULL,
                $COL_REASON TEXT NOT NULL DEFAULT ''
            )
        """
    }

    object DutySettingsTable {
        const val TABLE_NAME = "duty_settings"
        const val COL_SITE_ID = "site_id"
        const val COL_DUTY_TYPE = "duty_type"
        const val COL_MULTIPLIER_HUNDREDTHS = "multiplier_hundredths"
        const val COL_UPDATED_AT_ISO = "updated_at_iso"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_SITE_ID TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID',
                $COL_DUTY_TYPE TEXT NOT NULL,
                $COL_MULTIPLIER_HUNDREDTHS INTEGER NOT NULL,
                $COL_UPDATED_AT_ISO TEXT NOT NULL DEFAULT '',
                PRIMARY KEY ($COL_SITE_ID, $COL_DUTY_TYPE)
            )
        """
    }

    object AttendanceAuditTable {
        const val TABLE_NAME = "attendance_audit_log"
        const val COL_AUDIT_ID = "audit_id"
        const val COL_SITE_ID = "site_id"
        const val COL_DATE_ISO = "date_iso"
        const val COL_WORKER_ID = "worker_id"
        const val COL_PREV_DUTY = "previous_duty_type"
        const val COL_NEW_DUTY = "new_duty_type"
        const val COL_PREV_EARNED = "previous_earned"
        const val COL_NEW_EARNED = "new_earned"
        const val COL_CHANGED_BY_ROLE = "changed_by_role"
        const val COL_CHANGED_AT_ISO = "changed_at_iso"
        const val COL_REASON = "reason"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_AUDIT_ID TEXT PRIMARY KEY,
                $COL_SITE_ID TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID',
                $COL_DATE_ISO TEXT NOT NULL,
                $COL_WORKER_ID TEXT NOT NULL,
                $COL_PREV_DUTY TEXT,
                $COL_NEW_DUTY TEXT NOT NULL,
                $COL_PREV_EARNED INTEGER,
                $COL_NEW_EARNED INTEGER NOT NULL,
                $COL_CHANGED_BY_ROLE TEXT NOT NULL,
                $COL_CHANGED_AT_ISO TEXT NOT NULL,
                $COL_REASON TEXT NOT NULL DEFAULT ''
            )
        """
    }

    object PaymentAuditTable {
        const val TABLE_NAME = "payment_audit_log"
        const val COL_AUDIT_ID = "audit_id"
        const val COL_SITE_ID = "site_id"
        const val COL_TRANSACTION_ID = "transaction_id"
        const val COL_WORKER_ID = "worker_id"
        const val COL_ACTION = "action"
        const val COL_PREV_AMOUNT = "previous_amount"
        const val COL_NEW_AMOUNT = "new_amount"
        const val COL_CHANGED_BY_ROLE = "changed_by_role"
        const val COL_CHANGED_AT_ISO = "changed_at_iso"
        const val COL_REASON = "reason"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_AUDIT_ID TEXT PRIMARY KEY,
                $COL_SITE_ID TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID',
                $COL_TRANSACTION_ID TEXT NOT NULL,
                $COL_WORKER_ID TEXT NOT NULL,
                $COL_ACTION TEXT NOT NULL,
                $COL_PREV_AMOUNT INTEGER,
                $COL_NEW_AMOUNT INTEGER NOT NULL,
                $COL_CHANGED_BY_ROLE TEXT NOT NULL,
                $COL_CHANGED_AT_ISO TEXT NOT NULL,
                $COL_REASON TEXT NOT NULL DEFAULT ''
            )
        """
    }

    object ExpenseCategoriesTable {
        const val TABLE_NAME = "expense_categories"
        const val COL_CATEGORY_ID = "category_id"
        const val COL_NAME_EN = "name_en"
        const val COL_NAME_BN = "name_bn"
        const val COL_IS_DEFAULT = "is_default"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_CATEGORY_ID TEXT PRIMARY KEY,
                $COL_NAME_EN TEXT NOT NULL,
                $COL_NAME_BN TEXT NOT NULL,
                $COL_IS_DEFAULT INTEGER NOT NULL DEFAULT 0
            )
        """
    }

    object ExpensesTable {
        const val TABLE_NAME = "expenses"
        const val COL_EXPENSE_ID = "expense_id"
        const val COL_SITE_ID = "site_id"
        const val COL_CATEGORY_ID = "category_id"
        const val COL_EXPENSE_DATE_ISO = "expense_date_iso"
        const val COL_TITLE = "title"
        const val COL_DESCRIPTION = "description"
        const val COL_AMOUNT = "amount"
        const val COL_PAYMENT_METHOD = "payment_method"
        const val COL_VENDOR_NAME = "vendor_name"
        const val COL_REFERENCE_NO = "reference_no"
        const val COL_RECEIPT_PHOTO_PATH = "receipt_photo_path"
        const val COL_RECORDED_BY_ROLE = "recorded_by_role"
        const val COL_CREATED_AT_ISO = "created_at_iso"
        const val COL_IS_VOIDED = "is_voided"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_EXPENSE_ID TEXT PRIMARY KEY,
                $COL_SITE_ID TEXT NOT NULL,
                $COL_CATEGORY_ID TEXT NOT NULL,
                $COL_EXPENSE_DATE_ISO TEXT NOT NULL,
                $COL_TITLE TEXT NOT NULL,
                $COL_DESCRIPTION TEXT NOT NULL DEFAULT '',
                $COL_AMOUNT INTEGER NOT NULL,
                $COL_PAYMENT_METHOD TEXT NOT NULL DEFAULT 'CASH',
                $COL_VENDOR_NAME TEXT NOT NULL DEFAULT '',
                $COL_REFERENCE_NO TEXT NOT NULL DEFAULT '',
                $COL_RECEIPT_PHOTO_PATH TEXT,
                $COL_RECORDED_BY_ROLE TEXT NOT NULL DEFAULT 'ADMIN',
                $COL_CREATED_AT_ISO TEXT NOT NULL DEFAULT '',
                $COL_IS_VOIDED INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY ($COL_SITE_ID) REFERENCES ${SitesTable.TABLE_NAME}(${SitesTable.COL_SITE_ID}),
                FOREIGN KEY ($COL_CATEGORY_ID) REFERENCES ${ExpenseCategoriesTable.TABLE_NAME}(${ExpenseCategoriesTable.COL_CATEGORY_ID})
            )
        """
    }

    object ExpenseAuditTable {
        const val TABLE_NAME = "expense_audit_log"
        const val COL_AUDIT_ID = "audit_id"
        const val COL_EXPENSE_ID = "expense_id"
        const val COL_SITE_ID = "site_id"
        const val COL_ACTION = "action"
        const val COL_PREV_AMOUNT = "previous_amount"
        const val COL_NEW_AMOUNT = "new_amount"
        const val COL_CHANGED_BY_ROLE = "changed_by_role"
        const val COL_CHANGED_AT_ISO = "changed_at_iso"
        const val COL_REASON = "reason"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_AUDIT_ID TEXT PRIMARY KEY,
                $COL_EXPENSE_ID TEXT NOT NULL,
                $COL_SITE_ID TEXT NOT NULL,
                $COL_ACTION TEXT NOT NULL,
                $COL_PREV_AMOUNT INTEGER,
                $COL_NEW_AMOUNT INTEGER NOT NULL,
                $COL_CHANGED_BY_ROLE TEXT NOT NULL,
                $COL_CHANGED_AT_ISO TEXT NOT NULL,
                $COL_REASON TEXT NOT NULL DEFAULT ''
            )
        """
    }

    object UserSiteAssignmentsTable {
        const val TABLE_NAME = "user_site_assignments"
        const val COL_USER_ID = "user_id"
        const val COL_DISPLAY_NAME = "display_name"
        const val COL_ROLE = "user_role"
        const val COL_ASSIGNED_SITE_IDS = "assigned_site_ids_csv"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_USER_ID TEXT PRIMARY KEY,
                $COL_DISPLAY_NAME TEXT NOT NULL,
                $COL_ROLE TEXT NOT NULL,
                $COL_ASSIGNED_SITE_IDS TEXT NOT NULL DEFAULT ''
            )
        """
    }

    object BackupHistoryTable {
        const val TABLE_NAME = "backup_history"
        const val COL_BACKUP_ID = "backup_id"
        const val COL_FILE_NAME = "file_name"
        const val COL_CREATED_AT_ISO = "created_at_iso"
        const val COL_FILE_SIZE_BYTES = "file_size_bytes"
        const val COL_SCHEMA_VERSION = "schema_version"
        const val COL_FORMAT_VERSION = "format_version"
        const val COL_COUNTS_JSON = "counts_json"
        const val COL_CHECKSUM_SHA256 = "checksum_sha256"
        const val COL_VERIFICATION_STATUS = "verification_status"
        const val COL_LOCATION_URI = "location_uri_or_path"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_BACKUP_ID TEXT PRIMARY KEY,
                $COL_FILE_NAME TEXT NOT NULL,
                $COL_CREATED_AT_ISO TEXT NOT NULL,
                $COL_FILE_SIZE_BYTES INTEGER NOT NULL,
                $COL_SCHEMA_VERSION INTEGER NOT NULL,
                $COL_FORMAT_VERSION INTEGER NOT NULL,
                $COL_COUNTS_JSON TEXT NOT NULL,
                $COL_CHECKSUM_SHA256 TEXT NOT NULL,
                $COL_VERIFICATION_STATUS TEXT NOT NULL,
                $COL_LOCATION_URI TEXT NOT NULL
            )
        """
    }

    object SyncEventsTable {
        const val TABLE_NAME = "sync_events"
        const val COL_EVENT_ID = "event_id"
        const val COL_ENTITY_TYPE = "entity_type"
        const val COL_ENTITY_ID = "entity_id"
        const val COL_SITE_ID = "site_id"
        const val COL_ACTION = "action"
        const val COL_CREATED_AT_ISO = "created_at_iso"
        const val COL_SYNC_STATUS = "sync_status"

        const val CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS $TABLE_NAME (
                $COL_EVENT_ID TEXT PRIMARY KEY,
                $COL_ENTITY_TYPE TEXT NOT NULL,
                $COL_ENTITY_ID TEXT NOT NULL,
                $COL_SITE_ID TEXT NOT NULL,
                $COL_ACTION TEXT NOT NULL,
                $COL_CREATED_AT_ISO TEXT NOT NULL,
                $COL_SYNC_STATUS TEXT NOT NULL DEFAULT 'PENDING'
            )
        """
    }

    val INDEX_STATEMENTS = listOf(
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_workers_site_local_code ON ${WorkersTable.TABLE_NAME}(${WorkersTable.COL_SITE_ID}, ${WorkersTable.COL_LOCAL_WORKER_CODE})",
        "CREATE INDEX IF NOT EXISTS idx_workers_site_active ON ${WorkersTable.TABLE_NAME}(${WorkersTable.COL_SITE_ID}, ${WorkersTable.COL_IS_ACTIVE})",
        "CREATE INDEX IF NOT EXISTS idx_attendance_site_worker_date ON ${AttendanceTable.TABLE_NAME}(${AttendanceTable.COL_SITE_ID}, ${AttendanceTable.COL_WORKER_ID}, ${AttendanceTable.COL_DATE_ISO})",
        "CREATE INDEX IF NOT EXISTS idx_payments_site_worker_period ON ${PaymentsTable.TABLE_NAME}(${PaymentsTable.COL_SITE_ID}, ${PaymentsTable.COL_WORKER_ID}, ${PaymentsTable.COL_APPLICABLE_PERIOD})",
        "CREATE INDEX IF NOT EXISTS idx_advances_site_worker ON ${AdvancesTable.TABLE_NAME}(${AdvancesTable.COL_SITE_ID}, ${AdvancesTable.COL_WORKER_ID})",
        "CREATE INDEX IF NOT EXISTS idx_allocations_site_worker_period ON ${PaymentAllocationsTable.TABLE_NAME}(${PaymentAllocationsTable.COL_SITE_ID}, ${PaymentAllocationsTable.COL_WORKER_ID}, ${PaymentAllocationsTable.COL_PAYROLL_PERIOD})",
        "CREATE INDEX IF NOT EXISTS idx_allocations_source ON ${PaymentAllocationsTable.TABLE_NAME}(${PaymentAllocationsTable.COL_SOURCE_TYPE}, ${PaymentAllocationsTable.COL_SOURCE_ID})",
        "CREATE INDEX IF NOT EXISTS idx_expenses_site_date ON ${ExpensesTable.TABLE_NAME}(${ExpensesTable.COL_SITE_ID}, ${ExpensesTable.COL_EXPENSE_DATE_ISO})",
        "CREATE INDEX IF NOT EXISTS idx_transfers_worker ON ${WorkerSiteHistoryTable.TABLE_NAME}(${WorkerSiteHistoryTable.COL_WORKER_ID})"
    )
}
