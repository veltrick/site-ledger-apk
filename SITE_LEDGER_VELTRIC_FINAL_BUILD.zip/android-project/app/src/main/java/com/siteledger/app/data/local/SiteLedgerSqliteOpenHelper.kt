package com.siteledger.app.data.local

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.siteledger.app.data.sample.SampleSiteData
import com.siteledger.app.domain.model.AdvanceRecord
import com.siteledger.app.domain.model.AttendanceAuditEntry
import com.siteledger.app.domain.model.BackupHistoryRecord
import com.siteledger.app.domain.model.BackupRecordCounts
import com.siteledger.app.domain.model.DEFAULT_SITE_ID
import com.siteledger.app.domain.model.DailyAttendanceRecord
import com.siteledger.app.domain.model.DutyMultiplierConfig
import com.siteledger.app.domain.model.DutyType
import com.siteledger.app.domain.model.ExpenseAuditEntry
import com.siteledger.app.domain.model.ExpenseCategory
import com.siteledger.app.domain.model.ExpensePaymentMethod
import com.siteledger.app.domain.model.PaymentAllocation
import com.siteledger.app.domain.model.PaymentAuditEntry
import com.siteledger.app.domain.model.PaymentLedgerEntry
import com.siteledger.app.domain.model.PaymentType
import com.siteledger.app.domain.model.PayrollAuditEntry
import com.siteledger.app.domain.model.PayrollPeriodRecord
import com.siteledger.app.domain.model.PayrollPeriodStatus
import com.siteledger.app.domain.model.Site
import com.siteledger.app.domain.model.SiteExpense
import com.siteledger.app.domain.model.SiteStatus
import com.siteledger.app.domain.model.SyncEvent
import com.siteledger.app.domain.model.UserRole
import com.siteledger.app.domain.model.UserSiteAccount
import com.siteledger.app.domain.model.WorkCategory
import com.siteledger.app.domain.model.Worker
import com.siteledger.app.domain.model.WorkerSiteHistory
import com.siteledger.app.domain.service.WageCalculator
import org.json.JSONObject

/**
 * Offline SQLiteOpenHelper for SITE LEDGER (v1 -> v6).
 * Performs non-destructive upgrades preserving all workers, photos, attendance snapshots,
 * advances, allocations, payroll locks, and audits, migrating pre-v6 rows cleanly onto SITE-MAIN.
 */
class SiteLedgerSqliteOpenHelper(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    SiteLedgerDatabaseContract.DATABASE_NAME,
    null,
    SiteLedgerDatabaseContract.DATABASE_VERSION
) {

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(SiteLedgerDatabaseContract.SitesTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.WorkersTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.WorkerSiteHistoryTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.AttendanceTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.PaymentsTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.AdvancesTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.PaymentAllocationsTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.PayrollPeriodsTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.PayrollAuditTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.DutySettingsTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.AttendanceAuditTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.PaymentAuditTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.ExpenseCategoriesTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.ExpensesTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.ExpenseAuditTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.UserSiteAssignmentsTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.BackupHistoryTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.SyncEventsTable.CREATE_SQL)
        SiteLedgerDatabaseContract.INDEX_STATEMENTS.forEach { db.execSQL(it) }
        seedDefaultExpenseCategoriesIfEmpty(db)
        seedDefaultUserAssignmentsIfEmpty(db)
        seedInitialSampleDataIfEmpty(db)
        seedDefaultDutyMultipliersIfEmpty(db, DEFAULT_SITE_ID)
        seedDefaultDutyMultipliersIfEmpty(db, SampleSiteData.ANNEX_SITE_ID)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            addColumnIfMissing(
                db,
                SiteLedgerDatabaseContract.WorkersTable.TABLE_NAME,
                SiteLedgerDatabaseContract.WorkersTable.COL_PHOTO_PATH,
                "TEXT"
            )
        }
        if (oldVersion < 3) upgradeToVersion3(db)
        if (oldVersion < 4) upgradeToVersion4(db)
        if (oldVersion < 5) upgradeToVersion5(db)
        if (oldVersion < 6) upgradeToVersion6(db)
    }

    private fun upgradeToVersion3(db: SQLiteDatabase) {
        val wt = SiteLedgerDatabaseContract.WorkersTable
        addColumnIfMissing(db, wt.TABLE_NAME, wt.COL_PHONE_NUMBER, "TEXT NOT NULL DEFAULT ''")
        addColumnIfMissing(db, wt.TABLE_NAME, wt.COL_JOINING_DATE, "TEXT NOT NULL DEFAULT '2026-11-01'")
        addColumnIfMissing(db, wt.TABLE_NAME, wt.COL_LEAVING_DATE, "TEXT")

        val at = SiteLedgerDatabaseContract.AttendanceTable
        addColumnIfMissing(db, at.TABLE_NAME, at.COL_DUTY_TYPE, "TEXT NOT NULL DEFAULT 'FULL_DUTY'")
        addColumnIfMissing(db, at.TABLE_NAME, at.COL_DAILY_WAGE_SNAPSHOT, "INTEGER NOT NULL DEFAULT 0")
        addColumnIfMissing(db, at.TABLE_NAME, at.COL_MULTIPLIER_SNAPSHOT, "REAL NOT NULL DEFAULT 1.0")
        addColumnIfMissing(db, at.TABLE_NAME, at.COL_EARNED_AMOUNT, "INTEGER NOT NULL DEFAULT 0")
        addColumnIfMissing(db, at.TABLE_NAME, at.COL_NOTE, "TEXT NOT NULL DEFAULT ''")
        addColumnIfMissing(db, at.TABLE_NAME, at.COL_UPDATED_AT_ISO, "TEXT NOT NULL DEFAULT ''")
        addColumnIfMissing(db, at.TABLE_NAME, at.COL_UPDATED_BY_ROLE, "TEXT NOT NULL DEFAULT 'ADMIN'")

        db.execSQL(
            """
            UPDATE ${at.TABLE_NAME}
            SET ${at.COL_DUTY_TYPE} = CASE ${at.COL_STATUS}
                WHEN 'ABSENT' THEN 'ABSENT'
                WHEN 'LEAVE' THEN 'LEAVE'
                ELSE 'FULL_DUTY'
            END,
            ${at.COL_MULTIPLIER_SNAPSHOT} = CASE ${at.COL_STATUS}
                WHEN 'ABSENT' THEN 0.0
                WHEN 'LEAVE' THEN 0.0
                ELSE 1.0
            END,
            ${at.COL_DAILY_WAGE_SNAPSHOT} = COALESCE(
                (SELECT w.${wt.COL_DAILY_WAGE} FROM ${wt.TABLE_NAME} w WHERE w.${wt.COL_ID} = ${at.TABLE_NAME}.${at.COL_WORKER_ID}),
                0
            ),
            ${at.COL_EARNED_AMOUNT} = CASE ${at.COL_STATUS}
                WHEN 'ABSENT' THEN 0
                WHEN 'LEAVE' THEN 0
                ELSE COALESCE(
                    (SELECT w.${wt.COL_DAILY_WAGE} FROM ${wt.TABLE_NAME} w WHERE w.${wt.COL_ID} = ${at.TABLE_NAME}.${at.COL_WORKER_ID}),
                    0
                )
            END
            WHERE ${at.COL_DAILY_WAGE_SNAPSHOT} = 0
            """.trimIndent()
        )

        val pt = SiteLedgerDatabaseContract.PaymentsTable
        addColumnIfMissing(db, pt.TABLE_NAME, pt.COL_REFERENCE_NO, "TEXT NOT NULL DEFAULT ''")
        addColumnIfMissing(db, pt.TABLE_NAME, pt.COL_RECORDED_BY_ROLE, "TEXT NOT NULL DEFAULT 'ADMIN'")
        addColumnIfMissing(db, pt.TABLE_NAME, pt.COL_CREATED_AT_ISO, "TEXT NOT NULL DEFAULT ''")
        addColumnIfMissing(db, pt.TABLE_NAME, pt.COL_IS_VOIDED, "INTEGER NOT NULL DEFAULT 0")

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS ${SiteLedgerDatabaseContract.DutySettingsTable.TABLE_NAME} (
                ${SiteLedgerDatabaseContract.DutySettingsTable.COL_DUTY_TYPE} TEXT PRIMARY KEY,
                ${SiteLedgerDatabaseContract.DutySettingsTable.COL_MULTIPLIER_HUNDREDTHS} INTEGER NOT NULL,
                ${SiteLedgerDatabaseContract.DutySettingsTable.COL_UPDATED_AT_ISO} TEXT NOT NULL DEFAULT ''
            )
            """.trimIndent()
        )
        db.execSQL(SiteLedgerDatabaseContract.AttendanceAuditTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.PaymentAuditTable.CREATE_SQL)
    }

    private fun upgradeToVersion4(db: SQLiteDatabase) {
        val pt = SiteLedgerDatabaseContract.PaymentsTable
        addColumnIfMissing(db, pt.TABLE_NAME, pt.COL_APPLICABLE_PERIOD, "TEXT NOT NULL DEFAULT ''")
        addColumnIfMissing(db, pt.TABLE_NAME, pt.COL_PAYMENT_TYPE, "TEXT NOT NULL DEFAULT 'SALARY'")

        db.execSQL(
            """
            UPDATE ${pt.TABLE_NAME}
            SET ${pt.COL_APPLICABLE_PERIOD} = substr(${pt.COL_DATE_ISO}, 1, 7)
            WHERE ${pt.COL_APPLICABLE_PERIOD} = ''
            """.trimIndent()
        )

        db.execSQL(SiteLedgerDatabaseContract.AdvancesTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.PaymentAllocationsTable.CREATE_SQL)
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS ${SiteLedgerDatabaseContract.PayrollPeriodsTable.TABLE_NAME} (
                ${SiteLedgerDatabaseContract.PayrollPeriodsTable.COL_PERIOD_ISO} TEXT PRIMARY KEY,
                ${SiteLedgerDatabaseContract.PayrollPeriodsTable.COL_STATUS} TEXT NOT NULL DEFAULT 'OPEN',
                ${SiteLedgerDatabaseContract.PayrollPeriodsTable.COL_FINALIZED_AT_ISO} TEXT,
                ${SiteLedgerDatabaseContract.PayrollPeriodsTable.COL_FINALIZED_BY_ROLE} TEXT,
                ${SiteLedgerDatabaseContract.PayrollPeriodsTable.COL_REOPENED_AT_ISO} TEXT,
                ${SiteLedgerDatabaseContract.PayrollPeriodsTable.COL_REOPENED_BY_ROLE} TEXT,
                ${SiteLedgerDatabaseContract.PayrollPeriodsTable.COL_NOTES} TEXT NOT NULL DEFAULT ''
            )
            """.trimIndent()
        )
        db.execSQL(SiteLedgerDatabaseContract.PayrollAuditTable.CREATE_SQL)

        val allocT = SiteLedgerDatabaseContract.PaymentAllocationsTable
        db.execSQL(
            """
            INSERT OR IGNORE INTO ${allocT.TABLE_NAME} (
                ${allocT.COL_ALLOCATION_ID},
                ${allocT.COL_SOURCE_TYPE},
                ${allocT.COL_SOURCE_ID},
                ${allocT.COL_WORKER_ID},
                ${allocT.COL_PAYROLL_PERIOD},
                ${allocT.COL_ALLOCATED_AMOUNT},
                ${allocT.COL_ALLOCATED_AT_ISO},
                ${allocT.COL_ALLOCATED_BY_ROLE},
                ${allocT.COL_NOTE},
                ${allocT.COL_IS_VOIDED}
            )
            SELECT
                'ALLOC-' || ${pt.COL_ENTRY_ID},
                'PAYMENT',
                ${pt.COL_ENTRY_ID},
                ${pt.COL_WORKER_ID},
                CASE WHEN length(${pt.COL_APPLICABLE_PERIOD}) = 7 THEN ${pt.COL_APPLICABLE_PERIOD} ELSE substr(${pt.COL_DATE_ISO}, 1, 7) END,
                ${pt.COL_PAID_AMOUNT},
                ${pt.COL_CREATED_AT_ISO},
                ${pt.COL_RECORDED_BY_ROLE},
                COALESCE(${pt.COL_NOTE_EN}, ''),
                ${pt.COL_IS_VOIDED}
            FROM ${pt.TABLE_NAME}
            """.trimIndent()
        )
    }

    private fun upgradeToVersion5(db: SQLiteDatabase) {
        val t = SiteLedgerDatabaseContract.DutySettingsTable
        val defaults = DutyMultiplierConfig()
        DutyType.entries.forEach { dutyType ->
            val cv = ContentValues().apply {
                put(t.COL_DUTY_TYPE, dutyType.name)
                put(t.COL_MULTIPLIER_HUNDREDTHS, WageCalculator.toMultiplierHundredths(defaults.multiplierFor(dutyType)))
                put(t.COL_UPDATED_AT_ISO, "2026-11-15T08:00:00")
            }
            db.insertWithOnConflict(t.TABLE_NAME, null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        }
    }

    /**
     * Non-destructive v5 -> v6 migration:
     * 1) Creates sites table & inserts default SITE-MAIN first so all FKs stay 100% valid.
     * 2) Adds site_id (default SITE-MAIN) and local_worker_code to workers, preserving all worker photos & rows.
     * 3) Rebuilds attendance_records, payroll_periods, and duty_settings with composite PKs including site_id.
     * 4) Adds site_id to payment_ledger, advances, payment_allocations, and audit logs.
     * 5) Creates expense, worker transfer, permission, backup history, and sync event tables.
     */
    private fun upgradeToVersion6(db: SQLiteDatabase) {
        db.execSQL(SiteLedgerDatabaseContract.SitesTable.CREATE_SQL)
        db.insertWithOnConflict(
            SiteLedgerDatabaseContract.SitesTable.TABLE_NAME,
            null,
            SampleSiteData.defaultSite.toContentValues(),
            SQLiteDatabase.CONFLICT_IGNORE
        )

        val wt = SiteLedgerDatabaseContract.WorkersTable
        addColumnIfMissing(db, wt.TABLE_NAME, wt.COL_SITE_ID, "TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID'")
        addColumnIfMissing(db, wt.TABLE_NAME, wt.COL_LOCAL_WORKER_CODE, "TEXT NOT NULL DEFAULT ''")
        db.execSQL("UPDATE ${wt.TABLE_NAME} SET ${wt.COL_LOCAL_WORKER_CODE} = ${wt.COL_ID} WHERE ${wt.COL_LOCAL_WORKER_CODE} = ''")

        // Rebuild attendance_records with PK (site_id, date_iso, worker_id)
        val at = SiteLedgerDatabaseContract.AttendanceTable
        if (!hasColumn(db, at.TABLE_NAME, at.COL_SITE_ID)) {
            db.execSQL(
                """
                CREATE TABLE ${at.TABLE_NAME}_v6 (
                    ${at.COL_SITE_ID} TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID',
                    ${at.COL_DATE_ISO} TEXT NOT NULL,
                    ${at.COL_WORKER_ID} TEXT NOT NULL,
                    ${at.COL_STATUS} TEXT NOT NULL,
                    ${at.COL_DUTY_TYPE} TEXT NOT NULL DEFAULT 'FULL_DUTY',
                    ${at.COL_DAILY_WAGE_SNAPSHOT} INTEGER NOT NULL DEFAULT 0,
                    ${at.COL_MULTIPLIER_SNAPSHOT} REAL NOT NULL DEFAULT 1.0,
                    ${at.COL_EARNED_AMOUNT} INTEGER NOT NULL DEFAULT 0,
                    ${at.COL_NOTE} TEXT NOT NULL DEFAULT '',
                    ${at.COL_UPDATED_AT_ISO} TEXT NOT NULL DEFAULT '',
                    ${at.COL_UPDATED_BY_ROLE} TEXT NOT NULL DEFAULT 'ADMIN',
                    PRIMARY KEY (${at.COL_SITE_ID}, ${at.COL_DATE_ISO}, ${at.COL_WORKER_ID}),
                    FOREIGN KEY (${at.COL_SITE_ID}) REFERENCES ${SiteLedgerDatabaseContract.SitesTable.TABLE_NAME}(${SiteLedgerDatabaseContract.SitesTable.COL_SITE_ID}),
                    FOREIGN KEY (${at.COL_WORKER_ID}) REFERENCES ${wt.TABLE_NAME}(${wt.COL_ID})
                )
                """.trimIndent()
            )
            db.execSQL(
                """
                INSERT INTO ${at.TABLE_NAME}_v6 (
                    ${at.COL_SITE_ID}, ${at.COL_DATE_ISO}, ${at.COL_WORKER_ID}, ${at.COL_STATUS},
                    ${at.COL_DUTY_TYPE}, ${at.COL_DAILY_WAGE_SNAPSHOT}, ${at.COL_MULTIPLIER_SNAPSHOT},
                    ${at.COL_EARNED_AMOUNT}, ${at.COL_NOTE}, ${at.COL_UPDATED_AT_ISO}, ${at.COL_UPDATED_BY_ROLE}
                )
                SELECT
                    '$DEFAULT_SITE_ID', ${at.COL_DATE_ISO}, ${at.COL_WORKER_ID}, ${at.COL_STATUS},
                    ${at.COL_DUTY_TYPE}, ${at.COL_DAILY_WAGE_SNAPSHOT}, ${at.COL_MULTIPLIER_SNAPSHOT},
                    ${at.COL_EARNED_AMOUNT}, ${at.COL_NOTE}, ${at.COL_UPDATED_AT_ISO}, ${at.COL_UPDATED_BY_ROLE}
                FROM ${at.TABLE_NAME}
                """.trimIndent()
            )
            db.execSQL("DROP TABLE ${at.TABLE_NAME}")
            db.execSQL("ALTER TABLE ${at.TABLE_NAME}_v6 RENAME TO ${at.TABLE_NAME}")
        }

        // Rebuild payroll_periods with PK (site_id, period_iso)
        val pp = SiteLedgerDatabaseContract.PayrollPeriodsTable
        if (!hasColumn(db, pp.TABLE_NAME, pp.COL_SITE_ID)) {
            db.execSQL(
                """
                CREATE TABLE ${pp.TABLE_NAME}_v6 (
                    ${pp.COL_SITE_ID} TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID',
                    ${pp.COL_PERIOD_ISO} TEXT NOT NULL,
                    ${pp.COL_STATUS} TEXT NOT NULL DEFAULT 'OPEN',
                    ${pp.COL_FINALIZED_AT_ISO} TEXT,
                    ${pp.COL_FINALIZED_BY_ROLE} TEXT,
                    ${pp.COL_REOPENED_AT_ISO} TEXT,
                    ${pp.COL_REOPENED_BY_ROLE} TEXT,
                    ${pp.COL_NOTES} TEXT NOT NULL DEFAULT '',
                    PRIMARY KEY (${pp.COL_SITE_ID}, ${pp.COL_PERIOD_ISO}),
                    FOREIGN KEY (${pp.COL_SITE_ID}) REFERENCES ${SiteLedgerDatabaseContract.SitesTable.TABLE_NAME}(${SiteLedgerDatabaseContract.SitesTable.COL_SITE_ID})
                )
                """.trimIndent()
            )
            db.execSQL(
                """
                INSERT INTO ${pp.TABLE_NAME}_v6 (
                    ${pp.COL_SITE_ID}, ${pp.COL_PERIOD_ISO}, ${pp.COL_STATUS},
                    ${pp.COL_FINALIZED_AT_ISO}, ${pp.COL_FINALIZED_BY_ROLE},
                    ${pp.COL_REOPENED_AT_ISO}, ${pp.COL_REOPENED_BY_ROLE}, ${pp.COL_NOTES}
                )
                SELECT
                    '$DEFAULT_SITE_ID', ${pp.COL_PERIOD_ISO}, ${pp.COL_STATUS},
                    ${pp.COL_FINALIZED_AT_ISO}, ${pp.COL_FINALIZED_BY_ROLE},
                    ${pp.COL_REOPENED_AT_ISO}, ${pp.COL_REOPENED_BY_ROLE}, ${pp.COL_NOTES}
                FROM ${pp.TABLE_NAME}
                """.trimIndent()
            )
            db.execSQL("DROP TABLE ${pp.TABLE_NAME}")
            db.execSQL("ALTER TABLE ${pp.TABLE_NAME}_v6 RENAME TO ${pp.TABLE_NAME}")
        }

        // Rebuild duty_settings with PK (site_id, duty_type)
        val ds = SiteLedgerDatabaseContract.DutySettingsTable
        if (!hasColumn(db, ds.TABLE_NAME, ds.COL_SITE_ID)) {
            db.execSQL(
                """
                CREATE TABLE ${ds.TABLE_NAME}_v6 (
                    ${ds.COL_SITE_ID} TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID',
                    ${ds.COL_DUTY_TYPE} TEXT NOT NULL,
                    ${ds.COL_MULTIPLIER_HUNDREDTHS} INTEGER NOT NULL,
                    ${ds.COL_UPDATED_AT_ISO} TEXT NOT NULL DEFAULT '',
                    PRIMARY KEY (${ds.COL_SITE_ID}, ${ds.COL_DUTY_TYPE})
                )
                """.trimIndent()
            )
            db.execSQL(
                """
                INSERT INTO ${ds.TABLE_NAME}_v6 (${ds.COL_SITE_ID}, ${ds.COL_DUTY_TYPE}, ${ds.COL_MULTIPLIER_HUNDREDTHS}, ${ds.COL_UPDATED_AT_ISO})
                SELECT '$DEFAULT_SITE_ID', ${ds.COL_DUTY_TYPE}, ${ds.COL_MULTIPLIER_HUNDREDTHS}, ${ds.COL_UPDATED_AT_ISO}
                FROM ${ds.TABLE_NAME}
                """.trimIndent()
            )
            db.execSQL("DROP TABLE ${ds.TABLE_NAME}")
            db.execSQL("ALTER TABLE ${ds.TABLE_NAME}_v6 RENAME TO ${ds.TABLE_NAME}")
        }

        addColumnIfMissing(db, SiteLedgerDatabaseContract.PaymentsTable.TABLE_NAME, SiteLedgerDatabaseContract.PaymentsTable.COL_SITE_ID, "TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID'")
        addColumnIfMissing(db, SiteLedgerDatabaseContract.AdvancesTable.TABLE_NAME, SiteLedgerDatabaseContract.AdvancesTable.COL_SITE_ID, "TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID'")
        addColumnIfMissing(db, SiteLedgerDatabaseContract.PaymentAllocationsTable.TABLE_NAME, SiteLedgerDatabaseContract.PaymentAllocationsTable.COL_SITE_ID, "TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID'")
        addColumnIfMissing(db, SiteLedgerDatabaseContract.PayrollAuditTable.TABLE_NAME, SiteLedgerDatabaseContract.PayrollAuditTable.COL_SITE_ID, "TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID'")
        addColumnIfMissing(db, SiteLedgerDatabaseContract.AttendanceAuditTable.TABLE_NAME, SiteLedgerDatabaseContract.AttendanceAuditTable.COL_SITE_ID, "TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID'")
        addColumnIfMissing(db, SiteLedgerDatabaseContract.PaymentAuditTable.TABLE_NAME, SiteLedgerDatabaseContract.PaymentAuditTable.COL_SITE_ID, "TEXT NOT NULL DEFAULT '$DEFAULT_SITE_ID'")

        db.execSQL(SiteLedgerDatabaseContract.WorkerSiteHistoryTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.ExpenseCategoriesTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.ExpensesTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.ExpenseAuditTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.UserSiteAssignmentsTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.BackupHistoryTable.CREATE_SQL)
        db.execSQL(SiteLedgerDatabaseContract.SyncEventsTable.CREATE_SQL)

        seedDefaultExpenseCategoriesIfEmpty(db)
        seedDefaultUserAssignmentsIfEmpty(db)

        listOf(
            "idx_workers_active",
            "idx_attendance_worker_date",
            "idx_payments_worker_period",
            "idx_advances_worker",
            "idx_allocations_worker_period"
        ).forEach { db.execSQL("DROP INDEX IF EXISTS $it") }
        SiteLedgerDatabaseContract.INDEX_STATEMENTS.forEach { db.execSQL(it) }
    }

    private fun addColumnIfMissing(db: SQLiteDatabase, table: String, column: String, definition: String) {
        if (!hasColumn(db, table, column)) {
            db.execSQL("ALTER TABLE $table ADD COLUMN $column $definition")
        }
    }

    private fun hasColumn(db: SQLiteDatabase, table: String, column: String): Boolean {
        db.rawQuery("PRAGMA table_info($table)", null).use { cursor ->
            val nameIdx = cursor.getColumnIndex("name")
            while (cursor.moveToNext()) {
                if (nameIdx >= 0 && cursor.getString(nameIdx) == column) return true
            }
        }
        return false
    }

    fun seedDefaultExpenseCategoriesIfEmpty(db: SQLiteDatabase) {
        val t = SiteLedgerDatabaseContract.ExpenseCategoriesTable
        SampleSiteData.defaultExpenseCategories.forEach { cat ->
            db.insertWithOnConflict(t.TABLE_NAME, null, cat.toContentValues(), SQLiteDatabase.CONFLICT_IGNORE)
        }
    }

    fun seedDefaultUserAssignmentsIfEmpty(db: SQLiteDatabase) {
        val t = SiteLedgerDatabaseContract.UserSiteAssignmentsTable
        val count = db.rawQuery("SELECT COUNT(*) FROM ${t.TABLE_NAME}", null).use { c ->
            if (c.moveToFirst()) c.getInt(0) else 0
        }
        if (count > 0) return
        SampleSiteData.defaultUserSiteAccounts.forEach { acc ->
            db.insertWithOnConflict(t.TABLE_NAME, null, acc.toContentValues(), SQLiteDatabase.CONFLICT_IGNORE)
        }
    }

    fun seedDefaultDutyMultipliersIfEmpty(db: SQLiteDatabase, siteId: String = DEFAULT_SITE_ID) {
        val t = SiteLedgerDatabaseContract.DutySettingsTable
        val count = db.rawQuery(
            "SELECT COUNT(*) FROM ${t.TABLE_NAME} WHERE ${t.COL_SITE_ID} = ?",
            arrayOf(siteId)
        ).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }
        if (count > 0) return

        val defaults = DutyMultiplierConfig(siteId = siteId)
        DutyType.entries.forEach { dutyType ->
            val cv = ContentValues().apply {
                put(t.COL_SITE_ID, siteId)
                put(t.COL_DUTY_TYPE, dutyType.name)
                put(t.COL_MULTIPLIER_HUNDREDTHS, WageCalculator.toMultiplierHundredths(defaults.multiplierFor(dutyType)))
                put(t.COL_UPDATED_AT_ISO, "2026-11-01T08:00:00")
            }
            db.insert(t.TABLE_NAME, null, cv)
        }
    }

    fun seedInitialSampleDataIfEmpty(db: SQLiteDatabase) {
        val wt = SiteLedgerDatabaseContract.WorkersTable
        val workerCount = db.rawQuery("SELECT COUNT(*) FROM ${wt.TABLE_NAME}", null).use { c ->
            if (c.moveToFirst()) c.getInt(0) else 0
        }
        if (workerCount > 0) return

        db.beginTransaction()
        try {
            SampleSiteData.initialSites.forEach { s ->
                db.insertWithOnConflict(SiteLedgerDatabaseContract.SitesTable.TABLE_NAME, null, s.toContentValues(), SQLiteDatabase.CONFLICT_IGNORE)
            }
            SampleSiteData.workers.forEach { w -> db.insert(wt.TABLE_NAME, null, w.toContentValues()) }
            SampleSiteData.initialAttendance.forEach { a -> db.insert(SiteLedgerDatabaseContract.AttendanceTable.TABLE_NAME, null, a.toContentValues()) }
            SampleSiteData.initialPayments.forEach { p -> db.insert(SiteLedgerDatabaseContract.PaymentsTable.TABLE_NAME, null, p.toContentValues()) }
            SampleSiteData.initialAdvances.forEach { adv -> db.insert(SiteLedgerDatabaseContract.AdvancesTable.TABLE_NAME, null, adv.toContentValues()) }
            SampleSiteData.initialAllocations.forEach { alloc -> db.insert(SiteLedgerDatabaseContract.PaymentAllocationsTable.TABLE_NAME, null, alloc.toContentValues()) }
            SampleSiteData.initialPayrollPeriods.forEach { period -> db.insert(SiteLedgerDatabaseContract.PayrollPeriodsTable.TABLE_NAME, null, period.toContentValues()) }
            SampleSiteData.initialExpenses.forEach { exp -> db.insert(SiteLedgerDatabaseContract.ExpensesTable.TABLE_NAME, null, exp.toContentValues()) }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    // --- Sites ---
    fun readAllSites(): List<Site> {
        val result = mutableListOf<Site>()
        val t = SiteLedgerDatabaseContract.SitesTable
        readableDatabase.rawQuery("SELECT * FROM ${t.TABLE_NAME} ORDER BY rowid ASC", null).use { c ->
            val idIdx = c.getColumnIndexOrThrow(t.COL_SITE_ID)
            val nameIdx = c.getColumnIndexOrThrow(t.COL_SITE_NAME)
            val codeIdx = c.getColumnIndexOrThrow(t.COL_SITE_CODE)
            val descIdx = c.getColumnIndexOrThrow(t.COL_DESCRIPTION)
            val addrIdx = c.getColumnIndexOrThrow(t.COL_ADDRESS)
            val clientIdx = c.getColumnIndexOrThrow(t.COL_CLIENT_NAME)
            val mgrIdx = c.getColumnIndexOrThrow(t.COL_SITE_MANAGER)
            val startIdx = c.getColumnIndexOrThrow(t.COL_START_DATE_ISO)
            val compIdx = c.getColumnIndexOrThrow(t.COL_EXPECTED_COMPLETION_ISO)
            val statusIdx = c.getColumnIndexOrThrow(t.COL_STATUS)
            val notesIdx = c.getColumnIndexOrThrow(t.COL_NOTES)
            while (c.moveToNext()) {
                val status = runCatching { SiteStatus.valueOf(c.getString(statusIdx)) }.getOrDefault(SiteStatus.ACTIVE)
                result.add(
                    Site(
                        id = c.getString(idIdx),
                        siteName = c.getString(nameIdx),
                        siteCode = c.getString(codeIdx),
                        description = c.getString(descIdx) ?: "",
                        address = c.getString(addrIdx) ?: "",
                        clientName = c.getString(clientIdx) ?: "",
                        siteManager = c.getString(mgrIdx) ?: "",
                        startDateIso = c.getString(startIdx) ?: "2026-08-01",
                        expectedCompletionDateIso = if (c.isNull(compIdx)) null else c.getString(compIdx),
                        status = status,
                        notes = c.getString(notesIdx) ?: ""
                    )
                )
            }
        }
        return result
    }

    fun upsertSite(site: Site, syncEvent: SyncEvent? = null) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.insertWithOnConflict(SiteLedgerDatabaseContract.SitesTable.TABLE_NAME, null, site.toContentValues(), SQLiteDatabase.CONFLICT_REPLACE)
            seedDefaultDutyMultipliersIfEmpty(db, site.id)
            if (syncEvent != null) insertSyncEventInternal(db, syncEvent)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    // --- Workers & Transfers ---
    fun readAllWorkers(): List<Worker> {
        val result = mutableListOf<Worker>()
        val t = SiteLedgerDatabaseContract.WorkersTable
        readableDatabase.rawQuery("SELECT * FROM ${t.TABLE_NAME} ORDER BY rowid DESC", null).use { c ->
            val idIdx = c.getColumnIndexOrThrow(t.COL_ID)
            val siteIdx = c.getColumnIndexOrThrow(t.COL_SITE_ID)
            val codeIdx = c.getColumnIndexOrThrow(t.COL_LOCAL_WORKER_CODE)
            val nameEnIdx = c.getColumnIndexOrThrow(t.COL_FULL_NAME_EN)
            val nameBnIdx = c.getColumnIndexOrThrow(t.COL_FULL_NAME_BN)
            val phoneIdx = c.getColumnIndexOrThrow(t.COL_PHONE_NUMBER)
            val catIdx = c.getColumnIndexOrThrow(t.COL_CATEGORY)
            val joinIdx = c.getColumnIndexOrThrow(t.COL_JOINING_DATE)
            val leaveIdx = c.getColumnIndexOrThrow(t.COL_LEAVING_DATE)
            val wageIdx = c.getColumnIndexOrThrow(t.COL_DAILY_WAGE)
            val foodIdx = c.getColumnIndexOrThrow(t.COL_DAILY_FOOD_ALLOWANCE)
            val activeIdx = c.getColumnIndexOrThrow(t.COL_IS_ACTIVE)
            val avatarIdx = c.getColumnIndexOrThrow(t.COL_AVATAR_KEY)
            val photoIdx = c.getColumnIndexOrThrow(t.COL_PHOTO_PATH)

            while (c.moveToNext()) {
                val category = runCatching { WorkCategory.valueOf(c.getString(catIdx)) }.getOrDefault(WorkCategory.HELPER)
                val workerId = c.getString(idIdx)
                result.add(
                    Worker(
                        id = workerId,
                        fullNameEn = c.getString(nameEnIdx),
                        fullNameBn = c.getString(nameBnIdx),
                        phoneNumber = c.getString(phoneIdx) ?: "",
                        category = category,
                        joiningDateIso = c.getString(joinIdx) ?: "2026-11-01",
                        leavingDateIso = if (c.isNull(leaveIdx)) null else c.getString(leaveIdx),
                        dailyWage = c.getInt(wageIdx),
                        dailyFoodAllowance = c.getInt(foodIdx),
                        isActive = c.getInt(activeIdx) == 1,
                        avatarKey = c.getString(avatarIdx) ?: "default",
                        photoPath = if (c.isNull(photoIdx)) null else c.getString(photoIdx),
                        siteId = c.getString(siteIdx) ?: DEFAULT_SITE_ID,
                        localWorkerCode = (c.getString(codeIdx) ?: "").ifBlank { workerId }
                    )
                )
            }
        }
        return result
    }

    fun upsertWorker(worker: Worker, syncEvent: SyncEvent? = null) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val table = SiteLedgerDatabaseContract.WorkersTable
            val values = worker.toContentValues()
            val updatedRows = db.update(
                table.TABLE_NAME,
                values,
                "${table.COL_ID} = ?",
                arrayOf(worker.id)
            )
            if (updatedRows == 0) {
                db.insertOrThrow(table.TABLE_NAME, null, values)
            }
            if (syncEvent != null) insertSyncEventInternal(db, syncEvent)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun transferWorkerSite(updatedWorker: Worker, history: WorkerSiteHistory, syncEvent: SyncEvent? = null) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val workersTable = SiteLedgerDatabaseContract.WorkersTable
            val updatedRows = db.update(
                workersTable.TABLE_NAME,
                updatedWorker.toContentValues(),
                "${workersTable.COL_ID} = ?",
                arrayOf(updatedWorker.id)
            )
            check(updatedRows == 1) { "Cannot transfer worker: worker record not found" }
            db.insertOrThrow(
                SiteLedgerDatabaseContract.WorkerSiteHistoryTable.TABLE_NAME,
                null,
                history.toContentValues()
            )
            if (syncEvent != null) insertSyncEventInternal(db, syncEvent)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun readWorkerSiteHistory(): List<WorkerSiteHistory> {
        val result = mutableListOf<WorkerSiteHistory>()
        val t = SiteLedgerDatabaseContract.WorkerSiteHistoryTable
        readableDatabase.rawQuery("SELECT * FROM ${t.TABLE_NAME} ORDER BY rowid DESC", null).use { c ->
            val idIdx = c.getColumnIndexOrThrow(t.COL_TRANSFER_ID)
            val wIdx = c.getColumnIndexOrThrow(t.COL_WORKER_ID)
            val prevIdx = c.getColumnIndexOrThrow(t.COL_PREVIOUS_SITE_ID)
            val newIdx = c.getColumnIndexOrThrow(t.COL_NEW_SITE_ID)
            val dateIdx = c.getColumnIndexOrThrow(t.COL_TRANSFER_DATE_ISO)
            val roleIdx = c.getColumnIndexOrThrow(t.COL_AUTHORIZED_BY_ROLE)
            val notesIdx = c.getColumnIndexOrThrow(t.COL_NOTES)
            while (c.moveToNext()) {
                result.add(
                    WorkerSiteHistory(
                        transferId = c.getString(idIdx),
                        workerId = c.getString(wIdx),
                        previousSiteId = c.getString(prevIdx),
                        newSiteId = c.getString(newIdx),
                        transferDateIso = c.getString(dateIdx),
                        authorizedByRole = runCatching { UserRole.valueOf(c.getString(roleIdx)) }.getOrDefault(UserRole.ADMIN),
                        notes = c.getString(notesIdx) ?: ""
                    )
                )
            }
        }
        return result
    }

    fun countWorkersWithPhotoPath(photoPath: String): Int {
        val t = SiteLedgerDatabaseContract.WorkersTable
        return readableDatabase.rawQuery(
            "SELECT COUNT(*) FROM ${t.TABLE_NAME} WHERE ${t.COL_PHOTO_PATH} = ?",
            arrayOf(photoPath)
        ).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }
    }

    fun countExpensesWithReceiptPath(receiptPath: String): Int {
        val t = SiteLedgerDatabaseContract.ExpensesTable
        return readableDatabase.rawQuery(
            "SELECT COUNT(*) FROM ${t.TABLE_NAME} WHERE ${t.COL_RECEIPT_PHOTO_PATH} = ?",
            arrayOf(receiptPath)
        ).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }
    }

    // --- Duty Multipliers ---
    fun readDutyMultipliers(siteId: String = DEFAULT_SITE_ID): DutyMultiplierConfig {
        val t = SiteLedgerDatabaseContract.DutySettingsTable
        val map = mutableMapOf<DutyType, Double>()
        readableDatabase.rawQuery(
            "SELECT * FROM ${t.TABLE_NAME} WHERE ${t.COL_SITE_ID} = ?",
            arrayOf(siteId)
        ).use { c ->
            val typeIdx = c.getColumnIndexOrThrow(t.COL_DUTY_TYPE)
            val multIdx = c.getColumnIndexOrThrow(t.COL_MULTIPLIER_HUNDREDTHS)
            while (c.moveToNext()) {
                val type = runCatching { DutyType.valueOf(c.getString(typeIdx)) }.getOrNull()
                if (type != null) map[type] = WageCalculator.fromMultiplierHundredths(c.getInt(multIdx))
            }
        }
        val defaults = DutyMultiplierConfig(siteId = siteId)
        return DutyMultiplierConfig(
            halfDutyMultiplier = map[DutyType.HALF_DUTY] ?: defaults.halfDutyMultiplier,
            fullDutyMultiplier = map[DutyType.FULL_DUTY] ?: defaults.fullDutyMultiplier,
            oneAndHalfDutyMultiplier = map[DutyType.ONE_AND_HALF_DUTY] ?: defaults.oneAndHalfDutyMultiplier,
            doubleDutyMultiplier = map[DutyType.DOUBLE_DUTY] ?: defaults.doubleDutyMultiplier,
            twoAndHalfDutyMultiplier = map[DutyType.TWO_AND_HALF_DUTY] ?: defaults.twoAndHalfDutyMultiplier,
            tripleDutyMultiplier = map[DutyType.TRIPLE_DUTY] ?: defaults.tripleDutyMultiplier,
            absentMultiplier = map[DutyType.ABSENT] ?: defaults.absentMultiplier,
            leaveMultiplier = map[DutyType.LEAVE] ?: defaults.leaveMultiplier,
            siteId = siteId
        )
    }

    fun saveDutyMultipliers(config: DutyMultiplierConfig, updatedAtIso: String) {
        val t = SiteLedgerDatabaseContract.DutySettingsTable
        val db = writableDatabase
        db.beginTransaction()
        try {
            DutyType.entries.forEach { type ->
                val cv = ContentValues().apply {
                    put(t.COL_SITE_ID, config.siteId)
                    put(t.COL_DUTY_TYPE, type.name)
                    put(t.COL_MULTIPLIER_HUNDREDTHS, WageCalculator.toMultiplierHundredths(config.multiplierFor(type)))
                    put(t.COL_UPDATED_AT_ISO, updatedAtIso)
                }
                db.insertWithOnConflict(t.TABLE_NAME, null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    // --- Attendance ---
    fun readAllAttendance(): List<DailyAttendanceRecord> {
        val result = mutableListOf<DailyAttendanceRecord>()
        val t = SiteLedgerDatabaseContract.AttendanceTable
        readableDatabase.rawQuery("SELECT * FROM ${t.TABLE_NAME}", null).use { c ->
            val siteIdx = c.getColumnIndexOrThrow(t.COL_SITE_ID)
            val dateIdx = c.getColumnIndexOrThrow(t.COL_DATE_ISO)
            val workerIdx = c.getColumnIndexOrThrow(t.COL_WORKER_ID)
            val dutyIdx = c.getColumnIndexOrThrow(t.COL_DUTY_TYPE)
            val wageIdx = c.getColumnIndexOrThrow(t.COL_DAILY_WAGE_SNAPSHOT)
            val multIdx = c.getColumnIndexOrThrow(t.COL_MULTIPLIER_SNAPSHOT)
            val earnedIdx = c.getColumnIndexOrThrow(t.COL_EARNED_AMOUNT)
            val noteIdx = c.getColumnIndexOrThrow(t.COL_NOTE)
            val updAtIdx = c.getColumnIndexOrThrow(t.COL_UPDATED_AT_ISO)
            val updRoleIdx = c.getColumnIndexOrThrow(t.COL_UPDATED_BY_ROLE)

            while (c.moveToNext()) {
                result.add(
                    DailyAttendanceRecord(
                        dateIso = c.getString(dateIdx),
                        workerId = c.getString(workerIdx),
                        dutyType = runCatching { DutyType.valueOf(c.getString(dutyIdx)) }.getOrDefault(DutyType.FULL_DUTY),
                        dailyWageSnapshot = c.getInt(wageIdx),
                        multiplierSnapshot = c.getDouble(multIdx),
                        earnedAmount = c.getInt(earnedIdx),
                        note = c.getString(noteIdx) ?: "",
                        updatedAtIso = c.getString(updAtIdx) ?: "",
                        updatedByRole = runCatching { UserRole.valueOf(c.getString(updRoleIdx)) }.getOrDefault(UserRole.ADMIN),
                        siteId = c.getString(siteIdx) ?: DEFAULT_SITE_ID
                    )
                )
            }
        }
        return result
    }

    fun upsertAttendanceWithAudit(record: DailyAttendanceRecord, auditEntry: AttendanceAuditEntry?, syncEvent: SyncEvent? = null) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.insertWithOnConflict(SiteLedgerDatabaseContract.AttendanceTable.TABLE_NAME, null, record.toContentValues(), SQLiteDatabase.CONFLICT_REPLACE)
            if (auditEntry != null) {
                val a = SiteLedgerDatabaseContract.AttendanceAuditTable
                val cv = ContentValues().apply {
                    put(a.COL_AUDIT_ID, auditEntry.auditId)
                    put(a.COL_SITE_ID, auditEntry.siteId)
                    put(a.COL_DATE_ISO, auditEntry.dateIso)
                    put(a.COL_WORKER_ID, auditEntry.workerId)
                    if (auditEntry.previousDutyType == null) putNull(a.COL_PREV_DUTY) else put(a.COL_PREV_DUTY, auditEntry.previousDutyType.name)
                    put(a.COL_NEW_DUTY, auditEntry.newDutyType.name)
                    if (auditEntry.previousEarned == null) putNull(a.COL_PREV_EARNED) else put(a.COL_PREV_EARNED, auditEntry.previousEarned)
                    put(a.COL_NEW_EARNED, auditEntry.newEarned)
                    put(a.COL_CHANGED_BY_ROLE, auditEntry.changedByRole.name)
                    put(a.COL_CHANGED_AT_ISO, auditEntry.changedAtIso)
                    put(a.COL_REASON, auditEntry.reason)
                }
                db.insertWithOnConflict(a.TABLE_NAME, null, cv, SQLiteDatabase.CONFLICT_IGNORE)
            }
            if (syncEvent != null) insertSyncEventInternal(db, syncEvent)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun readAttendanceAudits(): List<AttendanceAuditEntry> {
        val result = mutableListOf<AttendanceAuditEntry>()
        val a = SiteLedgerDatabaseContract.AttendanceAuditTable
        readableDatabase.rawQuery("SELECT * FROM ${a.TABLE_NAME} ORDER BY rowid DESC", null).use { c ->
            val idIdx = c.getColumnIndexOrThrow(a.COL_AUDIT_ID)
            val siteIdx = c.getColumnIndexOrThrow(a.COL_SITE_ID)
            val dateIdx = c.getColumnIndexOrThrow(a.COL_DATE_ISO)
            val workerIdx = c.getColumnIndexOrThrow(a.COL_WORKER_ID)
            val prevDutyIdx = c.getColumnIndexOrThrow(a.COL_PREV_DUTY)
            val newDutyIdx = c.getColumnIndexOrThrow(a.COL_NEW_DUTY)
            val prevEarnIdx = c.getColumnIndexOrThrow(a.COL_PREV_EARNED)
            val newEarnIdx = c.getColumnIndexOrThrow(a.COL_NEW_EARNED)
            val roleIdx = c.getColumnIndexOrThrow(a.COL_CHANGED_BY_ROLE)
            val atIdx = c.getColumnIndexOrThrow(a.COL_CHANGED_AT_ISO)
            val reasonIdx = c.getColumnIndexOrThrow(a.COL_REASON)

            while (c.moveToNext()) {
                val prevDuty = if (c.isNull(prevDutyIdx)) null else runCatching { DutyType.valueOf(c.getString(prevDutyIdx)) }.getOrNull()
                result.add(
                    AttendanceAuditEntry(
                        auditId = c.getString(idIdx),
                        dateIso = c.getString(dateIdx),
                        workerId = c.getString(workerIdx),
                        previousDutyType = prevDuty,
                        newDutyType = runCatching { DutyType.valueOf(c.getString(newDutyIdx)) }.getOrDefault(DutyType.FULL_DUTY),
                        previousEarned = if (c.isNull(prevEarnIdx)) null else c.getInt(prevEarnIdx),
                        newEarned = c.getInt(newEarnIdx),
                        changedByRole = runCatching { UserRole.valueOf(c.getString(roleIdx)) }.getOrDefault(UserRole.ADMIN),
                        changedAtIso = c.getString(atIdx),
                        reason = c.getString(reasonIdx) ?: "",
                        siteId = c.getString(siteIdx) ?: DEFAULT_SITE_ID
                    )
                )
            }
        }
        return result
    }

    // --- Payments, Advances, Allocations & Payroll Periods ---
    fun readAllPayments(): List<PaymentLedgerEntry> {
        val result = mutableListOf<PaymentLedgerEntry>()
        val t = SiteLedgerDatabaseContract.PaymentsTable
        readableDatabase.rawQuery("SELECT * FROM ${t.TABLE_NAME} ORDER BY rowid DESC", null).use { c ->
            val idIdx = c.getColumnIndexOrThrow(t.COL_ENTRY_ID)
            val siteIdx = c.getColumnIndexOrThrow(t.COL_SITE_ID)
            val workerIdx = c.getColumnIndexOrThrow(t.COL_WORKER_ID)
            val dateIdx = c.getColumnIndexOrThrow(t.COL_DATE_ISO)
            val periodIdx = c.getColumnIndexOrThrow(t.COL_APPLICABLE_PERIOD)
            val typeIdx = c.getColumnIndexOrThrow(t.COL_PAYMENT_TYPE)
            val paidIdx = c.getColumnIndexOrThrow(t.COL_PAID_AMOUNT)
            val refIdx = c.getColumnIndexOrThrow(t.COL_REFERENCE_NO)
            val noteEnIdx = c.getColumnIndexOrThrow(t.COL_NOTE_EN)
            val noteBnIdx = c.getColumnIndexOrThrow(t.COL_NOTE_BN)
            val roleIdx = c.getColumnIndexOrThrow(t.COL_RECORDED_BY_ROLE)
            val createdIdx = c.getColumnIndexOrThrow(t.COL_CREATED_AT_ISO)
            val voidIdx = c.getColumnIndexOrThrow(t.COL_IS_VOIDED)

            while (c.moveToNext()) {
                val dateIso = c.getString(dateIdx)
                result.add(
                    PaymentLedgerEntry(
                        id = c.getString(idIdx),
                        workerId = c.getString(workerIdx),
                        dateIso = dateIso,
                        applicablePeriod = (c.getString(periodIdx) ?: "").ifBlank { dateIso.take(7) },
                        paymentType = runCatching { PaymentType.valueOf(c.getString(typeIdx)) }.getOrDefault(PaymentType.SALARY),
                        paidAmount = c.getInt(paidIdx),
                        referenceNo = c.getString(refIdx) ?: "",
                        noteEn = c.getString(noteEnIdx) ?: "",
                        noteBn = c.getString(noteBnIdx) ?: "",
                        recordedByRole = runCatching { UserRole.valueOf(c.getString(roleIdx)) }.getOrDefault(UserRole.ADMIN),
                        createdAtIso = c.getString(createdIdx) ?: "",
                        isVoided = c.getInt(voidIdx) == 1,
                        siteId = c.getString(siteIdx) ?: DEFAULT_SITE_ID
                    )
                )
            }
        }
        return result
    }

    fun insertOrUpdatePaymentWithAllocationAndAudit(
        entry: PaymentLedgerEntry,
        allocation: PaymentAllocation?,
        auditEntry: PaymentAuditEntry?,
        syncEvent: SyncEvent? = null
    ) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.insertWithOnConflict(SiteLedgerDatabaseContract.PaymentsTable.TABLE_NAME, null, entry.toContentValues(), SQLiteDatabase.CONFLICT_REPLACE)
            if (allocation != null) {
                db.insertWithOnConflict(SiteLedgerDatabaseContract.PaymentAllocationsTable.TABLE_NAME, null, allocation.toContentValues(), SQLiteDatabase.CONFLICT_REPLACE)
            }
            if (entry.isVoided) {
                val allocT = SiteLedgerDatabaseContract.PaymentAllocationsTable
                val voidCv = ContentValues().apply { put(allocT.COL_IS_VOIDED, 1) }
                db.update(allocT.TABLE_NAME, voidCv, "${allocT.COL_SOURCE_TYPE} = ? AND ${allocT.COL_SOURCE_ID} = ?", arrayOf("PAYMENT", entry.id))
            }
            if (auditEntry != null) insertPaymentAuditInternal(db, auditEntry)
            if (syncEvent != null) insertSyncEventInternal(db, syncEvent)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun readAllAdvances(): List<AdvanceRecord> {
        val result = mutableListOf<AdvanceRecord>()
        val t = SiteLedgerDatabaseContract.AdvancesTable
        readableDatabase.rawQuery("SELECT * FROM ${t.TABLE_NAME} ORDER BY rowid DESC", null).use { c ->
            val idIdx = c.getColumnIndexOrThrow(t.COL_ADVANCE_ID)
            val siteIdx = c.getColumnIndexOrThrow(t.COL_SITE_ID)
            val wIdx = c.getColumnIndexOrThrow(t.COL_WORKER_ID)
            val dateIdx = c.getColumnIndexOrThrow(t.COL_ADVANCE_DATE_ISO)
            val amtIdx = c.getColumnIndexOrThrow(t.COL_AMOUNT)
            val refIdx = c.getColumnIndexOrThrow(t.COL_REFERENCE_NO)
            val noteIdx = c.getColumnIndexOrThrow(t.COL_NOTE)
            val roleIdx = c.getColumnIndexOrThrow(t.COL_RECORDED_BY_ROLE)
            val crIdx = c.getColumnIndexOrThrow(t.COL_CREATED_AT_ISO)
            val voidIdx = c.getColumnIndexOrThrow(t.COL_IS_VOIDED)

            while (c.moveToNext()) {
                result.add(
                    AdvanceRecord(
                        id = c.getString(idIdx),
                        workerId = c.getString(wIdx),
                        advanceDateIso = c.getString(dateIdx),
                        amount = c.getInt(amtIdx),
                        referenceNo = c.getString(refIdx) ?: "",
                        note = c.getString(noteIdx) ?: "",
                        recordedByRole = runCatching { UserRole.valueOf(c.getString(roleIdx)) }.getOrDefault(UserRole.ADMIN),
                        createdAtIso = c.getString(crIdx) ?: "",
                        isVoided = c.getInt(voidIdx) == 1,
                        siteId = c.getString(siteIdx) ?: DEFAULT_SITE_ID
                    )
                )
            }
        }
        return result
    }

    fun insertAdvanceWithAudit(advance: AdvanceRecord, auditEntry: PaymentAuditEntry?) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.insertWithOnConflict(SiteLedgerDatabaseContract.AdvancesTable.TABLE_NAME, null, advance.toContentValues(), SQLiteDatabase.CONFLICT_REPLACE)
            if (auditEntry != null) insertPaymentAuditInternal(db, auditEntry)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun readAllAllocations(): List<PaymentAllocation> {
        val result = mutableListOf<PaymentAllocation>()
        val t = SiteLedgerDatabaseContract.PaymentAllocationsTable
        readableDatabase.rawQuery("SELECT * FROM ${t.TABLE_NAME} ORDER BY rowid DESC", null).use { c ->
            val idIdx = c.getColumnIndexOrThrow(t.COL_ALLOCATION_ID)
            val siteIdx = c.getColumnIndexOrThrow(t.COL_SITE_ID)
            val srcTypeIdx = c.getColumnIndexOrThrow(t.COL_SOURCE_TYPE)
            val srcIdIdx = c.getColumnIndexOrThrow(t.COL_SOURCE_ID)
            val wIdx = c.getColumnIndexOrThrow(t.COL_WORKER_ID)
            val perIdx = c.getColumnIndexOrThrow(t.COL_PAYROLL_PERIOD)
            val amtIdx = c.getColumnIndexOrThrow(t.COL_ALLOCATED_AMOUNT)
            val atIdx = c.getColumnIndexOrThrow(t.COL_ALLOCATED_AT_ISO)
            val roleIdx = c.getColumnIndexOrThrow(t.COL_ALLOCATED_BY_ROLE)
            val noteIdx = c.getColumnIndexOrThrow(t.COL_NOTE)
            val voidIdx = c.getColumnIndexOrThrow(t.COL_IS_VOIDED)

            while (c.moveToNext()) {
                result.add(
                    PaymentAllocation(
                        allocationId = c.getString(idIdx),
                        sourceType = c.getString(srcTypeIdx),
                        sourceId = c.getString(srcIdIdx),
                        workerId = c.getString(wIdx),
                        payrollPeriod = c.getString(perIdx),
                        allocatedAmount = c.getInt(amtIdx),
                        allocatedAtIso = c.getString(atIdx),
                        allocatedByRole = runCatching { UserRole.valueOf(c.getString(roleIdx)) }.getOrDefault(UserRole.ADMIN),
                        note = c.getString(noteIdx) ?: "",
                        isVoided = c.getInt(voidIdx) == 1,
                        siteId = c.getString(siteIdx) ?: DEFAULT_SITE_ID
                    )
                )
            }
        }
        return result
    }

    fun insertAllocationWithAudit(allocation: PaymentAllocation, auditEntry: PaymentAuditEntry?) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.insertWithOnConflict(SiteLedgerDatabaseContract.PaymentAllocationsTable.TABLE_NAME, null, allocation.toContentValues(), SQLiteDatabase.CONFLICT_REPLACE)
            if (auditEntry != null) insertPaymentAuditInternal(db, auditEntry)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun readPayrollPeriods(): List<PayrollPeriodRecord> {
        val result = mutableListOf<PayrollPeriodRecord>()
        val t = SiteLedgerDatabaseContract.PayrollPeriodsTable
        readableDatabase.rawQuery("SELECT * FROM ${t.TABLE_NAME} ORDER BY ${t.COL_PERIOD_ISO} DESC", null).use { c ->
            val siteIdx = c.getColumnIndexOrThrow(t.COL_SITE_ID)
            val perIdx = c.getColumnIndexOrThrow(t.COL_PERIOD_ISO)
            val stIdx = c.getColumnIndexOrThrow(t.COL_STATUS)
            val finAtIdx = c.getColumnIndexOrThrow(t.COL_FINALIZED_AT_ISO)
            val finRoleIdx = c.getColumnIndexOrThrow(t.COL_FINALIZED_BY_ROLE)
            val reAtIdx = c.getColumnIndexOrThrow(t.COL_REOPENED_AT_ISO)
            val reRoleIdx = c.getColumnIndexOrThrow(t.COL_REOPENED_BY_ROLE)
            val notesIdx = c.getColumnIndexOrThrow(t.COL_NOTES)

            while (c.moveToNext()) {
                val finRole = if (c.isNull(finRoleIdx)) null else runCatching { UserRole.valueOf(c.getString(finRoleIdx)) }.getOrNull()
                val reRole = if (c.isNull(reRoleIdx)) null else runCatching { UserRole.valueOf(c.getString(reRoleIdx)) }.getOrNull()
                result.add(
                    PayrollPeriodRecord(
                        periodIso = c.getString(perIdx),
                        status = runCatching { PayrollPeriodStatus.valueOf(c.getString(stIdx)) }.getOrDefault(PayrollPeriodStatus.OPEN),
                        finalizedAtIso = if (c.isNull(finAtIdx)) null else c.getString(finAtIdx),
                        finalizedByRole = finRole,
                        reopenedAtIso = if (c.isNull(reAtIdx)) null else c.getString(reAtIdx),
                        reopenedByRole = reRole,
                        notes = c.getString(notesIdx) ?: "",
                        siteId = c.getString(siteIdx) ?: DEFAULT_SITE_ID
                    )
                )
            }
        }
        return result
    }

    fun upsertPayrollPeriodWithAudit(record: PayrollPeriodRecord, auditEntry: PayrollAuditEntry) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.insertWithOnConflict(SiteLedgerDatabaseContract.PayrollPeriodsTable.TABLE_NAME, null, record.toContentValues(), SQLiteDatabase.CONFLICT_REPLACE)
            val a = SiteLedgerDatabaseContract.PayrollAuditTable
            val cv = ContentValues().apply {
                put(a.COL_AUDIT_ID, auditEntry.auditId)
                put(a.COL_SITE_ID, auditEntry.siteId)
                put(a.COL_PERIOD_ISO, auditEntry.periodIso)
                put(a.COL_ACTION, auditEntry.action)
                put(a.COL_CHANGED_BY_ROLE, auditEntry.changedByRole.name)
                put(a.COL_CHANGED_AT_ISO, auditEntry.changedAtIso)
                put(a.COL_REASON, auditEntry.reason)
            }
            db.insertWithOnConflict(a.TABLE_NAME, null, cv, SQLiteDatabase.CONFLICT_IGNORE)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun readPayrollAudits(): List<PayrollAuditEntry> {
        val result = mutableListOf<PayrollAuditEntry>()
        val t = SiteLedgerDatabaseContract.PayrollAuditTable
        readableDatabase.rawQuery("SELECT * FROM ${t.TABLE_NAME} ORDER BY rowid DESC", null).use { c ->
            val idIdx = c.getColumnIndexOrThrow(t.COL_AUDIT_ID)
            val siteIdx = c.getColumnIndexOrThrow(t.COL_SITE_ID)
            val perIdx = c.getColumnIndexOrThrow(t.COL_PERIOD_ISO)
            val actIdx = c.getColumnIndexOrThrow(t.COL_ACTION)
            val roleIdx = c.getColumnIndexOrThrow(t.COL_CHANGED_BY_ROLE)
            val atIdx = c.getColumnIndexOrThrow(t.COL_CHANGED_AT_ISO)
            val reasonIdx = c.getColumnIndexOrThrow(t.COL_REASON)

            while (c.moveToNext()) {
                result.add(
                    PayrollAuditEntry(
                        auditId = c.getString(idIdx),
                        periodIso = c.getString(perIdx),
                        action = c.getString(actIdx),
                        changedByRole = runCatching { UserRole.valueOf(c.getString(roleIdx)) }.getOrDefault(UserRole.ADMIN),
                        changedAtIso = c.getString(atIdx),
                        reason = c.getString(reasonIdx) ?: "",
                        siteId = c.getString(siteIdx) ?: DEFAULT_SITE_ID
                    )
                )
            }
        }
        return result
    }

    private fun insertPaymentAuditInternal(db: SQLiteDatabase, auditEntry: PaymentAuditEntry) {
        val p = SiteLedgerDatabaseContract.PaymentAuditTable
        val cv = ContentValues().apply {
            put(p.COL_AUDIT_ID, auditEntry.auditId)
            put(p.COL_SITE_ID, auditEntry.siteId)
            put(p.COL_TRANSACTION_ID, auditEntry.transactionId)
            put(p.COL_WORKER_ID, auditEntry.workerId)
            put(p.COL_ACTION, auditEntry.action)
            if (auditEntry.previousAmount == null) putNull(p.COL_PREV_AMOUNT) else put(p.COL_PREV_AMOUNT, auditEntry.previousAmount)
            put(p.COL_NEW_AMOUNT, auditEntry.newAmount)
            put(p.COL_CHANGED_BY_ROLE, auditEntry.changedByRole.name)
            put(p.COL_CHANGED_AT_ISO, auditEntry.changedAtIso)
            put(p.COL_REASON, auditEntry.reason)
        }
        db.insertWithOnConflict(p.TABLE_NAME, null, cv, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun readPaymentAudits(): List<PaymentAuditEntry> {
        val result = mutableListOf<PaymentAuditEntry>()
        val p = SiteLedgerDatabaseContract.PaymentAuditTable
        readableDatabase.rawQuery("SELECT * FROM ${p.TABLE_NAME} ORDER BY rowid DESC", null).use { c ->
            val idIdx = c.getColumnIndexOrThrow(p.COL_AUDIT_ID)
            val siteIdx = c.getColumnIndexOrThrow(p.COL_SITE_ID)
            val txIdx = c.getColumnIndexOrThrow(p.COL_TRANSACTION_ID)
            val workerIdx = c.getColumnIndexOrThrow(p.COL_WORKER_ID)
            val actIdx = c.getColumnIndexOrThrow(p.COL_ACTION)
            val prevIdx = c.getColumnIndexOrThrow(p.COL_PREV_AMOUNT)
            val newIdx = c.getColumnIndexOrThrow(p.COL_NEW_AMOUNT)
            val roleIdx = c.getColumnIndexOrThrow(p.COL_CHANGED_BY_ROLE)
            val atIdx = c.getColumnIndexOrThrow(p.COL_CHANGED_AT_ISO)
            val reasonIdx = c.getColumnIndexOrThrow(p.COL_REASON)

            while (c.moveToNext()) {
                result.add(
                    PaymentAuditEntry(
                        auditId = c.getString(idIdx),
                        transactionId = c.getString(txIdx),
                        workerId = c.getString(workerIdx),
                        action = c.getString(actIdx),
                        previousAmount = if (c.isNull(prevIdx)) null else c.getInt(prevIdx),
                        newAmount = c.getInt(newIdx),
                        changedByRole = runCatching { UserRole.valueOf(c.getString(roleIdx)) }.getOrDefault(UserRole.ADMIN),
                        changedAtIso = c.getString(atIdx),
                        reason = c.getString(reasonIdx) ?: "",
                        siteId = c.getString(siteIdx) ?: DEFAULT_SITE_ID
                    )
                )
            }
        }
        return result
    }

    // --- Expenses & Categories ---
    fun readExpenseCategories(): List<ExpenseCategory> {
        val result = mutableListOf<ExpenseCategory>()
        val t = SiteLedgerDatabaseContract.ExpenseCategoriesTable
        readableDatabase.rawQuery("SELECT * FROM ${t.TABLE_NAME} ORDER BY rowid ASC", null).use { c ->
            val idIdx = c.getColumnIndexOrThrow(t.COL_CATEGORY_ID)
            val enIdx = c.getColumnIndexOrThrow(t.COL_NAME_EN)
            val bnIdx = c.getColumnIndexOrThrow(t.COL_NAME_BN)
            val defIdx = c.getColumnIndexOrThrow(t.COL_IS_DEFAULT)
            while (c.moveToNext()) {
                result.add(
                    ExpenseCategory(
                        id = c.getString(idIdx),
                        nameEn = c.getString(enIdx),
                        nameBn = c.getString(bnIdx),
                        isDefault = c.getInt(defIdx) == 1
                    )
                )
            }
        }
        return result
    }

    fun upsertExpenseCategory(category: ExpenseCategory) {
        writableDatabase.insertWithOnConflict(
            SiteLedgerDatabaseContract.ExpenseCategoriesTable.TABLE_NAME,
            null,
            category.toContentValues(),
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    fun readAllExpenses(): List<SiteExpense> {
        val result = mutableListOf<SiteExpense>()
        val t = SiteLedgerDatabaseContract.ExpensesTable
        readableDatabase.rawQuery("SELECT * FROM ${t.TABLE_NAME} ORDER BY ${t.COL_EXPENSE_DATE_ISO} DESC, rowid DESC", null).use { c ->
            val idIdx = c.getColumnIndexOrThrow(t.COL_EXPENSE_ID)
            val siteIdx = c.getColumnIndexOrThrow(t.COL_SITE_ID)
            val catIdx = c.getColumnIndexOrThrow(t.COL_CATEGORY_ID)
            val dateIdx = c.getColumnIndexOrThrow(t.COL_EXPENSE_DATE_ISO)
            val titleIdx = c.getColumnIndexOrThrow(t.COL_TITLE)
            val descIdx = c.getColumnIndexOrThrow(t.COL_DESCRIPTION)
            val amtIdx = c.getColumnIndexOrThrow(t.COL_AMOUNT)
            val methodIdx = c.getColumnIndexOrThrow(t.COL_PAYMENT_METHOD)
            val vendorIdx = c.getColumnIndexOrThrow(t.COL_VENDOR_NAME)
            val refIdx = c.getColumnIndexOrThrow(t.COL_REFERENCE_NO)
            val receiptIdx = c.getColumnIndexOrThrow(t.COL_RECEIPT_PHOTO_PATH)
            val roleIdx = c.getColumnIndexOrThrow(t.COL_RECORDED_BY_ROLE)
            val crIdx = c.getColumnIndexOrThrow(t.COL_CREATED_AT_ISO)
            val voidIdx = c.getColumnIndexOrThrow(t.COL_IS_VOIDED)

            while (c.moveToNext()) {
                result.add(
                    SiteExpense(
                        id = c.getString(idIdx),
                        siteId = c.getString(siteIdx),
                        categoryId = c.getString(catIdx),
                        expenseDateIso = c.getString(dateIdx),
                        title = c.getString(titleIdx),
                        description = c.getString(descIdx) ?: "",
                        amount = c.getInt(amtIdx),
                        paymentMethod = runCatching { ExpensePaymentMethod.valueOf(c.getString(methodIdx)) }.getOrDefault(ExpensePaymentMethod.CASH),
                        vendorName = c.getString(vendorIdx) ?: "",
                        referenceNo = c.getString(refIdx) ?: "",
                        receiptPhotoPath = if (c.isNull(receiptIdx)) null else c.getString(receiptIdx),
                        recordedByRole = runCatching { UserRole.valueOf(c.getString(roleIdx)) }.getOrDefault(UserRole.ADMIN),
                        createdAtIso = c.getString(crIdx) ?: "",
                        isVoided = c.getInt(voidIdx) == 1
                    )
                )
            }
        }
        return result
    }

    fun upsertExpenseWithAudit(expense: SiteExpense, auditEntry: ExpenseAuditEntry?, syncEvent: SyncEvent? = null) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.insertWithOnConflict(SiteLedgerDatabaseContract.ExpensesTable.TABLE_NAME, null, expense.toContentValues(), SQLiteDatabase.CONFLICT_REPLACE)
            if (auditEntry != null) {
                val a = SiteLedgerDatabaseContract.ExpenseAuditTable
                val cv = ContentValues().apply {
                    put(a.COL_AUDIT_ID, auditEntry.auditId)
                    put(a.COL_EXPENSE_ID, auditEntry.expenseId)
                    put(a.COL_SITE_ID, auditEntry.siteId)
                    put(a.COL_ACTION, auditEntry.action)
                    if (auditEntry.previousAmount == null) putNull(a.COL_PREV_AMOUNT) else put(a.COL_PREV_AMOUNT, auditEntry.previousAmount)
                    put(a.COL_NEW_AMOUNT, auditEntry.newAmount)
                    put(a.COL_CHANGED_BY_ROLE, auditEntry.changedByRole.name)
                    put(a.COL_CHANGED_AT_ISO, auditEntry.changedAtIso)
                    put(a.COL_REASON, auditEntry.reason)
                }
                db.insertWithOnConflict(a.TABLE_NAME, null, cv, SQLiteDatabase.CONFLICT_IGNORE)
            }
            if (syncEvent != null) insertSyncEventInternal(db, syncEvent)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun readExpenseAudits(): List<ExpenseAuditEntry> {
        val result = mutableListOf<ExpenseAuditEntry>()
        val a = SiteLedgerDatabaseContract.ExpenseAuditTable
        readableDatabase.rawQuery("SELECT * FROM ${a.TABLE_NAME} ORDER BY rowid DESC", null).use { c ->
            val idIdx = c.getColumnIndexOrThrow(a.COL_AUDIT_ID)
            val expIdx = c.getColumnIndexOrThrow(a.COL_EXPENSE_ID)
            val siteIdx = c.getColumnIndexOrThrow(a.COL_SITE_ID)
            val actIdx = c.getColumnIndexOrThrow(a.COL_ACTION)
            val prevIdx = c.getColumnIndexOrThrow(a.COL_PREV_AMOUNT)
            val newIdx = c.getColumnIndexOrThrow(a.COL_NEW_AMOUNT)
            val roleIdx = c.getColumnIndexOrThrow(a.COL_CHANGED_BY_ROLE)
            val atIdx = c.getColumnIndexOrThrow(a.COL_CHANGED_AT_ISO)
            val reasonIdx = c.getColumnIndexOrThrow(a.COL_REASON)
            while (c.moveToNext()) {
                result.add(
                    ExpenseAuditEntry(
                        auditId = c.getString(idIdx),
                        expenseId = c.getString(expIdx),
                        siteId = c.getString(siteIdx),
                        action = c.getString(actIdx),
                        previousAmount = if (c.isNull(prevIdx)) null else c.getInt(prevIdx),
                        newAmount = c.getInt(newIdx),
                        changedByRole = runCatching { UserRole.valueOf(c.getString(roleIdx)) }.getOrDefault(UserRole.ADMIN),
                        changedAtIso = c.getString(atIdx),
                        reason = c.getString(reasonIdx) ?: ""
                    )
                )
            }
        }
        return result
    }

    // --- User Site Permissions ---
    fun readUserSiteAccounts(): List<UserSiteAccount> {
        val result = mutableListOf<UserSiteAccount>()
        val t = SiteLedgerDatabaseContract.UserSiteAssignmentsTable
        readableDatabase.rawQuery("SELECT * FROM ${t.TABLE_NAME} ORDER BY rowid ASC", null).use { c ->
            val idIdx = c.getColumnIndexOrThrow(t.COL_USER_ID)
            val nameIdx = c.getColumnIndexOrThrow(t.COL_DISPLAY_NAME)
            val roleIdx = c.getColumnIndexOrThrow(t.COL_ROLE)
            val sitesIdx = c.getColumnIndexOrThrow(t.COL_ASSIGNED_SITE_IDS)
            while (c.moveToNext()) {
                val csv = c.getString(sitesIdx) ?: ""
                val siteIds = csv.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                result.add(
                    UserSiteAccount(
                        userId = c.getString(idIdx),
                        displayName = c.getString(nameIdx),
                        role = runCatching { UserRole.valueOf(c.getString(roleIdx)) }.getOrDefault(UserRole.MANAGER),
                        assignedSiteIds = siteIds
                    )
                )
            }
        }
        return result
    }

    fun upsertUserSiteAccount(account: UserSiteAccount) {
        writableDatabase.insertWithOnConflict(
            SiteLedgerDatabaseContract.UserSiteAssignmentsTable.TABLE_NAME,
            null,
            account.toContentValues(),
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    // --- Backup History & Sync Events ---
    fun readBackupHistory(): List<BackupHistoryRecord> {
        val result = mutableListOf<BackupHistoryRecord>()
        val t = SiteLedgerDatabaseContract.BackupHistoryTable
        readableDatabase.rawQuery("SELECT * FROM ${t.TABLE_NAME} ORDER BY ${t.COL_CREATED_AT_ISO} DESC, rowid DESC", null).use { c ->
            val idIdx = c.getColumnIndexOrThrow(t.COL_BACKUP_ID)
            val nameIdx = c.getColumnIndexOrThrow(t.COL_FILE_NAME)
            val crIdx = c.getColumnIndexOrThrow(t.COL_CREATED_AT_ISO)
            val sizeIdx = c.getColumnIndexOrThrow(t.COL_FILE_SIZE_BYTES)
            val schIdx = c.getColumnIndexOrThrow(t.COL_SCHEMA_VERSION)
            val fmtIdx = c.getColumnIndexOrThrow(t.COL_FORMAT_VERSION)
            val cntIdx = c.getColumnIndexOrThrow(t.COL_COUNTS_JSON)
            val shaIdx = c.getColumnIndexOrThrow(t.COL_CHECKSUM_SHA256)
            val stIdx = c.getColumnIndexOrThrow(t.COL_VERIFICATION_STATUS)
            val locIdx = c.getColumnIndexOrThrow(t.COL_LOCATION_URI)
            while (c.moveToNext()) {
                result.add(
                    BackupHistoryRecord(
                        backupId = c.getString(idIdx),
                        fileName = c.getString(nameIdx),
                        createdAtIso = c.getString(crIdx),
                        fileSizeBytes = c.getLong(sizeIdx),
                        schemaVersion = c.getInt(schIdx),
                        formatVersion = c.getInt(fmtIdx),
                        counts = parseCountsJson(c.getString(cntIdx)),
                        checksumSha256 = c.getString(shaIdx),
                        verificationStatus = c.getString(stIdx),
                        locationUriOrPath = c.getString(locIdx)
                    )
                )
            }
        }
        return result
    }

    fun insertBackupHistory(record: BackupHistoryRecord) {
        writableDatabase.insertWithOnConflict(
            SiteLedgerDatabaseContract.BackupHistoryTable.TABLE_NAME,
            null,
            record.toContentValues(),
            SQLiteDatabase.CONFLICT_REPLACE
        )
    }

    private fun insertSyncEventInternal(db: SQLiteDatabase, syncEvent: SyncEvent) {
        val s = SiteLedgerDatabaseContract.SyncEventsTable
        val cv = ContentValues().apply {
            put(s.COL_EVENT_ID, syncEvent.eventId)
            put(s.COL_ENTITY_TYPE, syncEvent.entityType)
            put(s.COL_ENTITY_ID, syncEvent.entityId)
            put(s.COL_SITE_ID, syncEvent.siteId)
            put(s.COL_ACTION, syncEvent.action)
            put(s.COL_CREATED_AT_ISO, syncEvent.createdAtIso)
            put(s.COL_SYNC_STATUS, syncEvent.syncStatus)
        }
        db.insertWithOnConflict(s.TABLE_NAME, null, cv, SQLiteDatabase.CONFLICT_IGNORE)
    }

    private fun parseCountsJson(jsonStr: String): BackupRecordCounts {
        return runCatching {
            val o = JSONObject(jsonStr)
            BackupRecordCounts(
                sites = o.optInt("sites", 0),
                workers = o.optInt("workers", 0),
                attendanceRecords = o.optInt("attendanceRecords", 0),
                payments = o.optInt("payments", 0),
                advances = o.optInt("advances", 0),
                allocations = o.optInt("allocations", 0),
                expenses = o.optInt("expenses", 0),
                payrollPeriods = o.optInt("payrollPeriods", 0),
                workerPhotos = o.optInt("workerPhotos", 0),
                receiptImages = o.optInt("receiptImages", 0)
            )
        }.getOrDefault(BackupRecordCounts())
    }

    // --- ContentValues Mappers ---
    private fun Site.toContentValues(): ContentValues {
        val t = SiteLedgerDatabaseContract.SitesTable
        return ContentValues().apply {
            put(t.COL_SITE_ID, id)
            put(t.COL_SITE_NAME, siteName)
            put(t.COL_SITE_CODE, siteCode)
            put(t.COL_DESCRIPTION, description)
            put(t.COL_ADDRESS, address)
            put(t.COL_CLIENT_NAME, clientName)
            put(t.COL_SITE_MANAGER, siteManager)
            put(t.COL_START_DATE_ISO, startDateIso)
            if (expectedCompletionDateIso == null) putNull(t.COL_EXPECTED_COMPLETION_ISO) else put(t.COL_EXPECTED_COMPLETION_ISO, expectedCompletionDateIso)
            put(t.COL_STATUS, status.name)
            put(t.COL_NOTES, notes)
        }
    }

    private fun Worker.toContentValues(): ContentValues {
        val t = SiteLedgerDatabaseContract.WorkersTable
        return ContentValues().apply {
            put(t.COL_ID, id)
            put(t.COL_SITE_ID, siteId)
            put(t.COL_LOCAL_WORKER_CODE, localWorkerCode)
            put(t.COL_FULL_NAME_EN, fullNameEn)
            put(t.COL_FULL_NAME_BN, fullNameBn)
            put(t.COL_PHONE_NUMBER, phoneNumber)
            put(t.COL_CATEGORY, category.name)
            put(t.COL_JOINING_DATE, joiningDateIso)
            if (leavingDateIso == null) putNull(t.COL_LEAVING_DATE) else put(t.COL_LEAVING_DATE, leavingDateIso)
            put(t.COL_DAILY_WAGE, dailyWage)
            put(t.COL_DAILY_FOOD_ALLOWANCE, dailyFoodAllowance)
            put(t.COL_IS_ACTIVE, if (isActive) 1 else 0)
            put(t.COL_AVATAR_KEY, avatarKey)
            if (photoPath == null) putNull(t.COL_PHOTO_PATH) else put(t.COL_PHOTO_PATH, photoPath)
        }
    }

    private fun WorkerSiteHistory.toContentValues(): ContentValues {
        val t = SiteLedgerDatabaseContract.WorkerSiteHistoryTable
        return ContentValues().apply {
            put(t.COL_TRANSFER_ID, transferId)
            put(t.COL_WORKER_ID, workerId)
            put(t.COL_PREVIOUS_SITE_ID, previousSiteId)
            put(t.COL_NEW_SITE_ID, newSiteId)
            put(t.COL_TRANSFER_DATE_ISO, transferDateIso)
            put(t.COL_AUTHORIZED_BY_ROLE, authorizedByRole.name)
            put(t.COL_NOTES, notes)
        }
    }

    private fun DailyAttendanceRecord.toContentValues(): ContentValues {
        val t = SiteLedgerDatabaseContract.AttendanceTable
        val legacyStatus = when (dutyType) {
            DutyType.ABSENT -> "ABSENT"
            DutyType.LEAVE -> "LEAVE"
            else -> "PRESENT"
        }
        return ContentValues().apply {
            put(t.COL_SITE_ID, siteId)
            put(t.COL_DATE_ISO, dateIso)
            put(t.COL_WORKER_ID, workerId)
            put(t.COL_STATUS, legacyStatus)
            put(t.COL_DUTY_TYPE, dutyType.name)
            put(t.COL_DAILY_WAGE_SNAPSHOT, dailyWageSnapshot)
            put(t.COL_MULTIPLIER_SNAPSHOT, multiplierSnapshot)
            put(t.COL_EARNED_AMOUNT, earnedAmount)
            put(t.COL_NOTE, note)
            put(t.COL_UPDATED_AT_ISO, updatedAtIso)
            put(t.COL_UPDATED_BY_ROLE, updatedByRole.name)
        }
    }

    private fun PaymentLedgerEntry.toContentValues(): ContentValues {
        val t = SiteLedgerDatabaseContract.PaymentsTable
        return ContentValues().apply {
            put(t.COL_ENTRY_ID, id)
            put(t.COL_SITE_ID, siteId)
            put(t.COL_WORKER_ID, workerId)
            put(t.COL_DATE_ISO, dateIso)
            put(t.COL_APPLICABLE_PERIOD, applicablePeriod)
            put(t.COL_PAYMENT_TYPE, paymentType.name)
            put(t.COL_DAILY_AMOUNT, paidAmount)
            put(t.COL_PAID_AMOUNT, paidAmount)
            put(t.COL_STATUS, if (isVoided) "VOIDED" else "PAID")
            put(t.COL_REFERENCE_NO, referenceNo)
            put(t.COL_NOTE_EN, noteEn)
            put(t.COL_NOTE_BN, noteBn)
            put(t.COL_RECORDED_BY_ROLE, recordedByRole.name)
            put(t.COL_CREATED_AT_ISO, createdAtIso)
            put(t.COL_IS_VOIDED, if (isVoided) 1 else 0)
        }
    }

    private fun AdvanceRecord.toContentValues(): ContentValues {
        val t = SiteLedgerDatabaseContract.AdvancesTable
        return ContentValues().apply {
            put(t.COL_ADVANCE_ID, id)
            put(t.COL_SITE_ID, siteId)
            put(t.COL_WORKER_ID, workerId)
            put(t.COL_ADVANCE_DATE_ISO, advanceDateIso)
            put(t.COL_AMOUNT, amount)
            put(t.COL_REFERENCE_NO, referenceNo)
            put(t.COL_NOTE, note)
            put(t.COL_RECORDED_BY_ROLE, recordedByRole.name)
            put(t.COL_CREATED_AT_ISO, createdAtIso)
            put(t.COL_IS_VOIDED, if (isVoided) 1 else 0)
        }
    }

    private fun PaymentAllocation.toContentValues(): ContentValues {
        val t = SiteLedgerDatabaseContract.PaymentAllocationsTable
        return ContentValues().apply {
            put(t.COL_ALLOCATION_ID, allocationId)
            put(t.COL_SITE_ID, siteId)
            put(t.COL_SOURCE_TYPE, sourceType)
            put(t.COL_SOURCE_ID, sourceId)
            put(t.COL_WORKER_ID, workerId)
            put(t.COL_PAYROLL_PERIOD, payrollPeriod)
            put(t.COL_ALLOCATED_AMOUNT, allocatedAmount)
            put(t.COL_ALLOCATED_AT_ISO, allocatedAtIso)
            put(t.COL_ALLOCATED_BY_ROLE, allocatedByRole.name)
            put(t.COL_NOTE, note)
            put(t.COL_IS_VOIDED, if (isVoided) 1 else 0)
        }
    }

    private fun PayrollPeriodRecord.toContentValues(): ContentValues {
        val t = SiteLedgerDatabaseContract.PayrollPeriodsTable
        return ContentValues().apply {
            put(t.COL_SITE_ID, siteId)
            put(t.COL_PERIOD_ISO, periodIso)
            put(t.COL_STATUS, status.name)
            if (finalizedAtIso == null) putNull(t.COL_FINALIZED_AT_ISO) else put(t.COL_FINALIZED_AT_ISO, finalizedAtIso)
            if (finalizedByRole == null) putNull(t.COL_FINALIZED_BY_ROLE) else put(t.COL_FINALIZED_BY_ROLE, finalizedByRole.name)
            if (reopenedAtIso == null) putNull(t.COL_REOPENED_AT_ISO) else put(t.COL_REOPENED_AT_ISO, reopenedAtIso)
            if (reopenedByRole == null) putNull(t.COL_REOPENED_BY_ROLE) else put(t.COL_REOPENED_BY_ROLE, reopenedByRole.name)
            put(t.COL_NOTES, notes)
        }
    }

    private fun ExpenseCategory.toContentValues(): ContentValues {
        val t = SiteLedgerDatabaseContract.ExpenseCategoriesTable
        return ContentValues().apply {
            put(t.COL_CATEGORY_ID, id)
            put(t.COL_NAME_EN, nameEn)
            put(t.COL_NAME_BN, nameBn)
            put(t.COL_IS_DEFAULT, if (isDefault) 1 else 0)
        }
    }

    private fun SiteExpense.toContentValues(): ContentValues {
        val t = SiteLedgerDatabaseContract.ExpensesTable
        return ContentValues().apply {
            put(t.COL_EXPENSE_ID, id)
            put(t.COL_SITE_ID, siteId)
            put(t.COL_CATEGORY_ID, categoryId)
            put(t.COL_EXPENSE_DATE_ISO, expenseDateIso)
            put(t.COL_TITLE, title)
            put(t.COL_DESCRIPTION, description)
            put(t.COL_AMOUNT, amount)
            put(t.COL_PAYMENT_METHOD, paymentMethod.name)
            put(t.COL_VENDOR_NAME, vendorName)
            put(t.COL_REFERENCE_NO, referenceNo)
            if (receiptPhotoPath == null) putNull(t.COL_RECEIPT_PHOTO_PATH) else put(t.COL_RECEIPT_PHOTO_PATH, receiptPhotoPath)
            put(t.COL_RECORDED_BY_ROLE, recordedByRole.name)
            put(t.COL_CREATED_AT_ISO, createdAtIso)
            put(t.COL_IS_VOIDED, if (isVoided) 1 else 0)
        }
    }

    private fun UserSiteAccount.toContentValues(): ContentValues {
        val t = SiteLedgerDatabaseContract.UserSiteAssignmentsTable
        return ContentValues().apply {
            put(t.COL_USER_ID, userId)
            put(t.COL_DISPLAY_NAME, displayName)
            put(t.COL_ROLE, role.name)
            put(t.COL_ASSIGNED_SITE_IDS, assignedSiteIds.joinToString(","))
        }
    }

    private fun BackupHistoryRecord.toContentValues(): ContentValues {
        val t = SiteLedgerDatabaseContract.BackupHistoryTable
        val countsJson = JSONObject().apply {
            put("sites", counts.sites)
            put("workers", counts.workers)
            put("attendanceRecords", counts.attendanceRecords)
            put("payments", counts.payments)
            put("advances", counts.advances)
            put("allocations", counts.allocations)
            put("expenses", counts.expenses)
            put("payrollPeriods", counts.payrollPeriods)
            put("workerPhotos", counts.workerPhotos)
            put("receiptImages", counts.receiptImages)
        }.toString()
        return ContentValues().apply {
            put(t.COL_BACKUP_ID, backupId)
            put(t.COL_FILE_NAME, fileName)
            put(t.COL_CREATED_AT_ISO, createdAtIso)
            put(t.COL_FILE_SIZE_BYTES, fileSizeBytes)
            put(t.COL_SCHEMA_VERSION, schemaVersion)
            put(t.COL_FORMAT_VERSION, formatVersion)
            put(t.COL_COUNTS_JSON, countsJson)
            put(t.COL_CHECKSUM_SHA256, checksumSha256)
            put(t.COL_VERIFICATION_STATUS, verificationStatus)
            put(t.COL_LOCATION_URI, locationUriOrPath)
        }
    }
}
