package com.siteledger.app.data.sample

import com.siteledger.app.domain.model.AdvanceRecord
import com.siteledger.app.domain.model.DEFAULT_SITE_ID
import com.siteledger.app.domain.model.DailyAttendanceRecord
import com.siteledger.app.domain.model.DutyType
import com.siteledger.app.domain.model.ExpenseCategory
import com.siteledger.app.domain.model.ExpensePaymentMethod
import com.siteledger.app.domain.model.MonthlyExpenseBreakdown
import com.siteledger.app.domain.model.PaymentAllocation
import com.siteledger.app.domain.model.PaymentLedgerEntry
import com.siteledger.app.domain.model.PaymentType
import com.siteledger.app.domain.model.PayrollPeriodRecord
import com.siteledger.app.domain.model.PayrollPeriodStatus
import com.siteledger.app.domain.model.Site
import com.siteledger.app.domain.model.SiteExpense
import com.siteledger.app.domain.model.SiteStatus
import com.siteledger.app.domain.model.UserRole
import com.siteledger.app.domain.model.UserSiteAccount
import com.siteledger.app.domain.model.WorkCategory
import com.siteledger.app.domain.model.Worker
import com.siteledger.app.domain.model.WorkerSiteHistory

/**
 * Initial offline sample dataset seeded once into SQLite when empty.
 * Includes two active construction sites, 12 workers, multi-month history,
 * worker transfer log, official expense categories, and site-scoped expenses.
 */
object SampleSiteData {

    const val ANNEX_SITE_ID = "SITE-BANANI"

    val availableDates = listOf(
        "2026-11-15",
        "2026-11-14",
        "2026-11-13",
        "2026-11-12",
        "2026-11-11"
    )

    val defaultSite = Site(
        id = DEFAULT_SITE_ID,
        siteName = "Gulshan Tower Foundation",
        siteCode = "GLS-01",
        description = "14-story commercial structure & basement diaphragm wall",
        address = "Plot 28, Road 71, Gulshan-2, Dhaka",
        clientName = "Eastern Urban Developments",
        siteManager = "Engr. Tariqul Islam",
        startDateIso = "2026-08-01",
        expectedCompletionDateIso = "2027-09-30",
        status = SiteStatus.ACTIVE,
        notes = "Primary headquarters active structural crew"
    )

    val initialSites: List<Site> = listOf(
        defaultSite,
        Site(
            id = ANNEX_SITE_ID,
            siteName = "Banani Commercial Annex",
            siteCode = "BNN-02",
            description = "6-story annex interior finishing & MEP fit-out",
            address = "House 14, Block C, Banani, Dhaka",
            clientName = "Northline Properties Ltd.",
            siteManager = "Md. Sohel Rana",
            startDateIso = "2026-09-15",
            expectedCompletionDateIso = "2027-04-15",
            status = SiteStatus.ACTIVE,
            notes = "Separate ledger site for annex crew"
        )
    )

    val defaultExpenseCategories: List<ExpenseCategory> = listOf(
        ExpenseCategory("CAT-FOOD", "Food & Khuraki", "খাবার ও খোরাকি", true),
        ExpenseCategory("CAT-TRANSPORT", "Transportation", "পরিবহন", true),
        ExpenseCategory("CAT-MATERIALS", "Construction Materials", "নির্মাণ সামগ্রী", true),
        ExpenseCategory("CAT-TOOLS", "Equipment & Tools", "যন্ত্রপাতি ও সরঞ্জাম", true),
        ExpenseCategory("CAT-RENTAL", "Equipment Rental", "যন্ত্রপাতি ভাড়া", true),
        ExpenseCategory("CAT-UTILITIES", "Utilities", "বিদ্যুৎ ও পানি বিল", true),
        ExpenseCategory("CAT-LABOUR-MISC", "Labour-related Other Expenses", "শ্রমিক সংক্রান্ত অন্যান্য খরচ", true),
        ExpenseCategory("CAT-MAINTENANCE", "Maintenance", "রক্ষণাবেক্ষণ", true),
        ExpenseCategory("CAT-OTHER", "Other Expenses", "অন্যান্য ব্যয়", true)
    )

    val defaultUserSiteAccounts: List<UserSiteAccount> = listOf(
        UserSiteAccount("USR-ADMIN", "Site Director (Admin)", UserRole.ADMIN, listOf(DEFAULT_SITE_ID, ANNEX_SITE_ID)),
        UserSiteAccount("USR-MGR", "Field Manager", UserRole.MANAGER, listOf(DEFAULT_SITE_ID, ANNEX_SITE_ID)),
        UserSiteAccount("USR-ACC", "Site Accountant", UserRole.ACCOUNTANT, listOf(DEFAULT_SITE_ID, ANNEX_SITE_ID))
    )

    val workers: List<Worker> = listOf(
        Worker("SL-101", "Rafiqul Islam", "রফিকুল ইসলাম", "01711-240101", WorkCategory.MASON, "2026-08-10", null, 750, 150, true, "mason", null, DEFAULT_SITE_ID, "SL-101"),
        Worker("SL-102", "Kamrul Hasan", "কামরুল হাসান", "01819-330102", WorkCategory.STEEL_FIXER, "2026-08-15", null, 800, 150, true, "foreman", null, DEFAULT_SITE_ID, "SL-102"),
        Worker("SL-103", "Sajjad Hossain", "সাজ্জাদ হোসেন", "01912-440103", WorkCategory.ELECTRICIAN, "2026-09-01", null, 780, 150, true, "electrician", null, DEFAULT_SITE_ID, "SL-103"),
        Worker("SL-104", "Mizanur Rahman", "মিজানুর রহমান", "01715-550104", WorkCategory.CARPENTER, "2026-09-05", null, 720, 150, true, "carpenter", null, DEFAULT_SITE_ID, "SL-104"),
        Worker("SL-105", "Alamin Mia", "আলামিন মিয়া", "01614-660105", WorkCategory.HELPER, "2026-09-12", null, 300, 120, true, "mason", null, DEFAULT_SITE_ID, "SL-105"),
        Worker("SL-106", "Faruk Ahmed", "ফারুক আহমেদ", "01720-770106", WorkCategory.MASON, "2026-09-20", null, 750, 150, true, "foreman", null, DEFAULT_SITE_ID, "SL-106"),
        Worker("SL-107", "Tanvir Ahmed", "তানভীর আহমেদ", "01822-880107", WorkCategory.PLUMBER, "2026-10-01", null, 700, 150, true, "electrician", null, DEFAULT_SITE_ID, "SL-107"),
        Worker("SL-108", "Babul Sarder", "বাবুল সরদার", "01930-990108", WorkCategory.HELPER, "2026-07-14", "2026-11-10", 500, 120, false, "carpenter", null, DEFAULT_SITE_ID, "SL-108"),
        Worker("SL-109", "Nurul Amin", "নুরুল আমিন", "01733-110109", WorkCategory.STEEL_FIXER, "2026-10-08", null, 800, 150, true, "foreman", null, DEFAULT_SITE_ID, "SL-109"),
        Worker("SL-110", "Jahangir Alam", "জাহাঙ্গীর আলম", "01644-220110", WorkCategory.HELPER, "2026-10-15", null, 520, 120, true, "mason", null, DEFAULT_SITE_ID, "SL-110"),
        // Banani Commercial Annex workers (note per-site numbering starts cleanly at BN-201 / BN-202)
        Worker("SL-201", "Rubel Mia", "রুবেল মিয়া", "01755-310201", WorkCategory.ELECTRICIAN, "2026-10-02", null, 760, 150, true, "electrician", null, ANNEX_SITE_ID, "BN-201"),
        Worker("SL-202", "Habibur Rahman", "হাবিবুর রহমান", "01866-410202", WorkCategory.MASON, "2026-10-05", null, 740, 150, true, "mason", null, ANNEX_SITE_ID, "BN-202")
    )

    val initialAttendance: List<DailyAttendanceRecord> = listOf(
        // Gulshan Main Site: November 2026
        DailyAttendanceRecord("2026-11-15", "SL-101", DutyType.FULL_DUTY, 750, 1.0, 750, "Foundation slab work", "2026-11-15T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-11-15", "SL-102", DutyType.TRIPLE_DUTY, 800, 3.0, 2400, "Continuous concrete pour shift", "2026-11-15T20:00:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-11-15", "SL-103", DutyType.HALF_DUTY, 780, 0.5, 390, "Morning panel wiring", "2026-11-15T13:15:00", UserRole.MANAGER, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-11-15", "SL-104", DutyType.FULL_DUTY, 720, 1.0, 720, "Formwork shuttering", "2026-11-15T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-11-15", "SL-105", DutyType.TRIPLE_DUTY, 300, 3.0, 900, "Night slab curing", "2026-11-15T21:00:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-11-15", "SL-106", DutyType.ABSENT, 750, 0.0, 0, "Uninformed absence", "2026-11-15T17:30:00", UserRole.MANAGER, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-11-15", "SL-107", DutyType.FULL_DUTY, 700, 1.0, 700, "", "2026-11-15T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-11-15", "SL-109", DutyType.FULL_DUTY, 800, 1.0, 800, "", "2026-11-15T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-11-15", "SL-110", DutyType.LEAVE, 520, 0.0, 0, "Approved family leave", "2026-11-15T10:00:00", UserRole.MANAGER, DEFAULT_SITE_ID),

        DailyAttendanceRecord("2026-11-14", "SL-101", DutyType.FULL_DUTY, 750, 1.0, 750, "", "2026-11-14T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-11-14", "SL-102", DutyType.FULL_DUTY, 800, 1.0, 800, "", "2026-11-14T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-11-14", "SL-103", DutyType.LEAVE, 780, 0.0, 0, "Medical checkup", "2026-11-14T10:00:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-11-14", "SL-104", DutyType.HALF_DUTY, 720, 0.5, 360, "Half day rain stop", "2026-11-14T13:00:00", UserRole.MANAGER, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-11-14", "SL-105", DutyType.FULL_DUTY, 300, 1.0, 300, "", "2026-11-14T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),

        DailyAttendanceRecord("2026-11-13", "SL-101", DutyType.TRIPLE_DUTY, 750, 3.0, 2250, "Night slab curing", "2026-11-13T21:00:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-11-13", "SL-102", DutyType.FULL_DUTY, 800, 1.0, 800, "", "2026-11-13T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-11-13", "SL-103", DutyType.FULL_DUTY, 780, 1.0, 780, "", "2026-11-13T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-11-13", "SL-105", DutyType.FULL_DUTY, 300, 1.0, 300, "", "2026-11-13T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-11-12", "SL-105", DutyType.HALF_DUTY, 300, 0.5, 150, "Half-day material unload", "2026-11-12T13:00:00", UserRole.MANAGER, DEFAULT_SITE_ID),

        // October 2026 (Main Site)
        DailyAttendanceRecord("2026-10-28", "SL-101", DutyType.FULL_DUTY, 700, 1.0, 700, "Prior wage rate ৳700", "2026-10-28T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-10-29", "SL-101", DutyType.FULL_DUTY, 700, 1.0, 700, "Prior wage rate ৳700", "2026-10-29T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-10-30", "SL-101", DutyType.HALF_DUTY, 700, 0.5, 350, "Prior wage rate ৳700", "2026-10-30T13:00:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-10-28", "SL-102", DutyType.FULL_DUTY, 800, 1.0, 800, "", "2026-10-28T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-10-29", "SL-102", DutyType.TRIPLE_DUTY, 800, 3.0, 2400, "Tower footing pour", "2026-10-29T21:00:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-10-28", "SL-105", DutyType.FULL_DUTY, 300, 1.0, 300, "", "2026-10-28T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-10-29", "SL-105", DutyType.FULL_DUTY, 300, 1.0, 300, "", "2026-10-29T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),

        // September 2026 (Main Site)
        DailyAttendanceRecord("2026-09-25", "SL-101", DutyType.FULL_DUTY, 700, 1.0, 700, "Boundary wall", "2026-09-25T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-09-26", "SL-101", DutyType.FULL_DUTY, 700, 1.0, 700, "Boundary wall", "2026-09-26T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),
        DailyAttendanceRecord("2026-09-25", "SL-102", DutyType.FULL_DUTY, 750, 1.0, 750, "Rebar cutting", "2026-09-25T17:30:00", UserRole.ADMIN, DEFAULT_SITE_ID),

        // Banani Commercial Annex: November 2026
        DailyAttendanceRecord("2026-11-15", "SL-201", DutyType.ONE_AND_HALF_DUTY, 760, 1.5, 1140, "Main DB distribution board", "2026-11-15T18:45:00", UserRole.MANAGER, ANNEX_SITE_ID),
        DailyAttendanceRecord("2026-11-15", "SL-202", DutyType.DOUBLE_DUTY, 740, 2.0, 1480, "Exterior plaster double shift", "2026-11-15T20:00:00", UserRole.MANAGER, ANNEX_SITE_ID),
        DailyAttendanceRecord("2026-11-14", "SL-201", DutyType.FULL_DUTY, 760, 1.0, 760, "", "2026-11-14T17:30:00", UserRole.MANAGER, ANNEX_SITE_ID),
        DailyAttendanceRecord("2026-11-14", "SL-202", DutyType.FULL_DUTY, 740, 1.0, 740, "", "2026-11-14T17:30:00", UserRole.MANAGER, ANNEX_SITE_ID)
    )

    val initialPayments: List<PaymentLedgerEntry> = listOf(
        PaymentLedgerEntry("TXN-501", "SL-101", "2026-11-15", "2026-11", PaymentType.SALARY, 1500, "CASH-101", "Partial wage settlement", "আংশিক মজুরি পরিশোধ", UserRole.ACCOUNTANT, "2026-11-15T18:00:00", false, DEFAULT_SITE_ID),
        PaymentLedgerEntry("TXN-502", "SL-102", "2026-11-15", "2026-11", PaymentType.SALARY, 2000, "CASH-102", "Triple duty settlement", "তিনগুণ ডিউটি পরিশোধ", UserRole.ACCOUNTANT, "2026-11-15T18:10:00", false, DEFAULT_SITE_ID),
        PaymentLedgerEntry("TXN-503", "SL-103", "2026-11-15", "2026-11", PaymentType.SALARY, 390, "CASH-103", "Half duty settlement", "অর্ধেক ডিউটি পরিশোধ", UserRole.ADMIN, "2026-11-15T18:20:00", false, DEFAULT_SITE_ID),
        PaymentLedgerEntry("TXN-504", "SL-105", "2026-11-14", "2026-11", PaymentType.SALARY, 650, "CASH-104", "Partial wage payment", "আংশিক মজুরি পরিশোধ", UserRole.ACCOUNTANT, "2026-11-14T18:00:00", false, DEFAULT_SITE_ID),
        PaymentLedgerEntry("TXN-490", "SL-101", "2026-11-02", "2026-10", PaymentType.SALARY, 1750, "CASH-090", "October final settlement (paid in Nov)", "অক্টোবরের বকেয়া পরিশোধ", UserRole.ACCOUNTANT, "2026-11-02T17:00:00", false, DEFAULT_SITE_ID),
        PaymentLedgerEntry("TXN-491", "SL-102", "2026-11-02", "2026-10", PaymentType.SALARY, 2500, "BKASH-091", "October partial salary", "অক্টোবরের আংশিক বেতন", UserRole.ACCOUNTANT, "2026-11-02T17:15:00", false, DEFAULT_SITE_ID),
        PaymentLedgerEntry("TXN-470", "SL-101", "2026-10-01", "2026-09", PaymentType.SALARY, 1400, "CASH-070", "September salary cleared", "সেপ্টেম্বরের বেতন পরিশোধ", UserRole.ADMIN, "2026-10-01T17:00:00", false, DEFAULT_SITE_ID),
        PaymentLedgerEntry("TXN-471", "SL-102", "2026-10-01", "2026-09", PaymentType.SALARY, 750, "CASH-071", "September salary cleared", "সেপ্টেম্বরের বেতন পরিশোধ", UserRole.ADMIN, "2026-10-01T17:05:00", false, DEFAULT_SITE_ID),
        // Banani Annex payments
        PaymentLedgerEntry("TXN-601", "SL-201", "2026-11-15", "2026-11", PaymentType.SALARY, 1000, "CASH-B01", "Annex partial electrical wage", "অ্যানেক্স আংশিক মজুরি", UserRole.ACCOUNTANT, "2026-11-15T19:00:00", false, ANNEX_SITE_ID)
    )

    val initialAdvances: List<AdvanceRecord> = listOf(
        AdvanceRecord("ADV-201", "SL-101", "2026-11-10", 1000, "ADV-101", "Family medical advance (unallocated)", UserRole.ADMIN, "2026-11-10T11:00:00", false, DEFAULT_SITE_ID),
        AdvanceRecord("ADV-202", "SL-105", "2026-10-25", 600, "ADV-105", "October salary advance", UserRole.ACCOUNTANT, "2026-10-25T16:00:00", false, DEFAULT_SITE_ID)
    )

    val initialAllocations: List<PaymentAllocation> = listOf(
        PaymentAllocation("ALLOC-501", "PAYMENT", "TXN-501", "SL-101", "2026-11", 1500, "2026-11-15T18:00:00", UserRole.ACCOUNTANT, "Partial wage settlement", false, DEFAULT_SITE_ID),
        PaymentAllocation("ALLOC-502", "PAYMENT", "TXN-502", "SL-102", "2026-11", 2000, "2026-11-15T18:10:00", UserRole.ACCOUNTANT, "Triple duty settlement", false, DEFAULT_SITE_ID),
        PaymentAllocation("ALLOC-503", "PAYMENT", "TXN-503", "SL-103", "2026-11", 390, "2026-11-15T18:20:00", UserRole.ADMIN, "Half duty settlement", false, DEFAULT_SITE_ID),
        PaymentAllocation("ALLOC-504", "PAYMENT", "TXN-504", "SL-105", "2026-11", 650, "2026-11-14T18:00:00", UserRole.ACCOUNTANT, "Partial wage payment", false, DEFAULT_SITE_ID),
        PaymentAllocation("ALLOC-490", "PAYMENT", "TXN-490", "SL-101", "2026-10", 1750, "2026-11-02T17:00:00", UserRole.ACCOUNTANT, "October final settlement", false, DEFAULT_SITE_ID),
        PaymentAllocation("ALLOC-491", "PAYMENT", "TXN-491", "SL-102", "2026-10", 2500, "2026-11-02T17:15:00", UserRole.ACCOUNTANT, "October partial salary", false, DEFAULT_SITE_ID),
        PaymentAllocation("ALLOC-470", "PAYMENT", "TXN-470", "SL-101", "2026-09", 1400, "2026-10-01T17:00:00", UserRole.ADMIN, "September salary cleared", false, DEFAULT_SITE_ID),
        PaymentAllocation("ALLOC-471", "PAYMENT", "TXN-471", "SL-102", "2026-09", 750, "2026-10-01T17:05:00", UserRole.ADMIN, "September salary cleared", false, DEFAULT_SITE_ID),
        PaymentAllocation("ALLOC-ADV-202", "ADVANCE", "ADV-202", "SL-105", "2026-10", 600, "2026-10-31T18:00:00", UserRole.ACCOUNTANT, "Allocated October advance", false, DEFAULT_SITE_ID),
        PaymentAllocation("ALLOC-601", "PAYMENT", "TXN-601", "SL-201", "2026-11", 1000, "2026-11-15T19:00:00", UserRole.ACCOUNTANT, "Annex partial electrical wage", false, ANNEX_SITE_ID)
    )

    val initialPayrollPeriods: List<PayrollPeriodRecord> = listOf(
        PayrollPeriodRecord("2026-09", PayrollPeriodStatus.FINALIZED, "2026-10-02T10:00:00", UserRole.ADMIN, null, null, "September payroll closed", DEFAULT_SITE_ID),
        PayrollPeriodRecord("2026-10", PayrollPeriodStatus.OPEN, null, null, null, null, "October settlement in progress", DEFAULT_SITE_ID),
        PayrollPeriodRecord("2026-11", PayrollPeriodStatus.OPEN, null, null, null, null, "Current active month", DEFAULT_SITE_ID),
        PayrollPeriodRecord("2026-11", PayrollPeriodStatus.OPEN, null, null, null, null, "Current active month (Banani)", ANNEX_SITE_ID)
    )

    val initialExpenses: List<SiteExpense> = listOf(
        SiteExpense("EXP-101", DEFAULT_SITE_ID, "CAT-MATERIALS", "2026-11-15", "Ready-Mix Cement & Aggregate", "60 bags OPC cement for slab pour", 34200, ExpensePaymentMethod.BANK, "Crown Cement Agency", "INV-GLS-881", null, UserRole.ACCOUNTANT, "2026-11-15T11:30:00", false),
        SiteExpense("EXP-102", DEFAULT_SITE_ID, "CAT-FOOD", "2026-11-15", "Evening Crew Khuraki", "Tea & tiffin for triple-duty concrete pour", 1850, ExpensePaymentMethod.CASH, "Bismillah Hotel", "BILL-115", null, UserRole.MANAGER, "2026-11-15T19:20:00", false),
        SiteExpense("EXP-103", DEFAULT_SITE_ID, "CAT-RENTAL", "2026-11-14", "Vibrator & Mixer Rental", "2 concrete vibrators 2 days", 4500, ExpensePaymentMethod.MOBILE_MONEY, "Dhaka Equipment Rentals", "BK-7721", null, UserRole.ADMIN, "2026-11-14T15:00:00", false),
        SiteExpense("EXP-201", ANNEX_SITE_ID, "CAT-MATERIALS", "2026-11-15", "FR Electrical Conduit & Cable", "BRB 2.5mm & 4mm coils for 3rd floor", 12800, ExpensePaymentMethod.BANK, "Nawabpur Electric Supply", "INV-BNN-204", null, UserRole.MANAGER, "2026-11-15T14:10:00", false),
        SiteExpense("EXP-202", ANNEX_SITE_ID, "CAT-TRANSPORT", "2026-11-14", "Pickup Van Material Delivery", "Scaffolding & conduit transport", 2200, ExpensePaymentMethod.CASH, "Banani Transport Co.", "TR-440", null, UserRole.MANAGER, "2026-11-14T16:40:00", false)
    )

    val initialTransfers: List<WorkerSiteHistory> = emptyList()

    val monthlyExpenseBaseline = MonthlyExpenseBreakdown(
        laborCost = 148500,
        foodAllowances = 28400,
        siteMaterials = 64200
    )
}
