package com.siteledger.app.domain.model

const val DEFAULT_SITE_ID = "SITE-MAIN"

enum class AppLanguage(val code: String, val displayLabel: String) {
    ENGLISH("en", "English"),
    BENGALI("bn", "বাংলা")
}

enum class NavDestination(val route: String) {
    DASHBOARD("dashboard"),
    WORKERS("workers"),
    ATTENDANCE("attendance"),
    SPREADSHEET("spreadsheet"),
    PAYMENTS("payments"),
    EXPENSES("expenses"),
    REPORTS("reports"),
    SITES("sites"),
    SETTINGS("settings"),
    ABOUT("about")
}

enum class WorkCategory(val labelEn: String, val labelBn: String) {
    MASON("Mason", "রাজমিস্ত্রি"),
    HELPER("Helper", "হেল্পার"),
    STEEL_FIXER("Steel Fixer", "রডমিস্ত্রি"),
    ELECTRICIAN("Electrician", "ইলেকট্রিশিয়ান"),
    CARPENTER("Carpenter", "কাঠমিস্ত্রি"),
    PLUMBER("Plumber", "প্লাম্বার")
}

enum class UserRole(val labelEn: String, val labelBn: String) {
    ADMIN("Admin", "অ্যাডমিন"),
    MANAGER("Manager", "ম্যানেজার"),
    ACCOUNTANT("Accountant", "হিসাবরক্ষক")
}

enum class SiteStatus(val labelEn: String, val labelBn: String) {
    ACTIVE("Active", "সক্রিয়"),
    INACTIVE("Inactive", "নিষ্ক্রিয়"),
    COMPLETED("Completed", "সম্পন্ন"),
    ARCHIVED("Archived", "আর্কাইভড")
}

enum class ExpensePaymentMethod(val labelEn: String, val labelBn: String) {
    CASH("Cash", "নগদ"),
    BANK("Bank Transfer", "ব্যাংক"),
    MOBILE_MONEY("Mobile Money", "মোবাইল ব্যাংকিং"),
    CREDIT("Supplier Credit", "বাকি / ক্রেডিট")
}

enum class DutyType(
    val shortCode: String,
    val labelEn: String,
    val labelBn: String
) {
    HALF_DUTY("H", "Half Duty", "হাফ হাজিরা"),
    FULL_DUTY("F", "Full Duty", "এক হাজিরা"),
    ONE_AND_HALF_DUTY("1.5", "One and Half Duty", "দেড় হাজিরা"),
    DOUBLE_DUTY("D", "Double Duty", "দুই হাজিরা"),
    TWO_AND_HALF_DUTY("2.5", "Two and Half Duty", "আড়াই হাজিরা"),
    TRIPLE_DUTY("T", "Triple Duty", "তিন হাজিরা"),
    ABSENT("A", "Absent", "অনুপস্থিত"),
    LEAVE("L", "Leave", "ছুটি")
}

enum class PayrollPeriodStatus(val labelEn: String, val labelBn: String) {
    OPEN("Open", "খোলা"),
    FINALIZED("Finalized", "চূড়ান্ত")
}

enum class WorkerPayrollStatus(val labelEn: String, val labelBn: String) {
    PAID("Paid", "পরিশোধিত"),
    PARTIAL("Partial", "আংশিক"),
    UNPAID("Unpaid", "বকেয়া"),
    OVERPAID("Overpaid", "অতিরিক্ত পরিশোধিত"),
    NO_ATTENDANCE("No Attendance", "উপস্থিতি নেই")
}

enum class PaymentType(val labelEn: String, val labelBn: String) {
    SALARY("Salary", "বেতন"),
    ADVANCE("Advance", "অগ্রিম"),
    REVERSAL("Reversal", "রিভার্সাল")
}

data class Site(
    val id: String,
    val siteName: String,
    val siteCode: String,
    val description: String = "",
    val address: String = "",
    val clientName: String = "",
    val siteManager: String = "",
    val startDateIso: String = "2026-08-01",
    val expectedCompletionDateIso: String? = null,
    val status: SiteStatus = SiteStatus.ACTIVE,
    val notes: String = ""
)

data class WorkerSiteHistory(
    val transferId: String,
    val workerId: String,
    val previousSiteId: String,
    val newSiteId: String,
    val transferDateIso: String,
    val authorizedByRole: UserRole,
    val notes: String = ""
)

data class ExpenseCategory(
    val id: String,
    val nameEn: String,
    val nameBn: String,
    val isDefault: Boolean = false
)

data class SiteExpense(
    val id: String,
    val siteId: String,
    val categoryId: String,
    val expenseDateIso: String,
    val title: String,
    val description: String = "",
    val amount: Int,
    val paymentMethod: ExpensePaymentMethod = ExpensePaymentMethod.CASH,
    val vendorName: String = "",
    val referenceNo: String = "",
    val receiptPhotoPath: String? = null,
    val recordedByRole: UserRole = UserRole.ADMIN,
    val createdAtIso: String = "",
    val isVoided: Boolean = false
)

data class ExpenseAuditEntry(
    val auditId: String,
    val expenseId: String,
    val siteId: String,
    val action: String, // "CREATED" | "EDITED" | "VOIDED"
    val previousAmount: Int?,
    val newAmount: Int,
    val changedByRole: UserRole,
    val changedAtIso: String,
    val reason: String
)

data class UserSiteAccount(
    val userId: String,
    val displayName: String,
    val role: UserRole,
    val assignedSiteIds: List<String>
)

data class DutyMultiplierConfig(
    val halfDutyMultiplier: Double = 0.5,
    val fullDutyMultiplier: Double = 1.0,
    val oneAndHalfDutyMultiplier: Double = 1.5,
    val doubleDutyMultiplier: Double = 2.0,
    val twoAndHalfDutyMultiplier: Double = 2.5,
    val tripleDutyMultiplier: Double = 3.0,
    val absentMultiplier: Double = 0.0,
    val leaveMultiplier: Double = 0.0,
    val siteId: String = DEFAULT_SITE_ID
) {
    fun multiplierFor(dutyType: DutyType): Double = when (dutyType) {
        DutyType.HALF_DUTY -> halfDutyMultiplier
        DutyType.FULL_DUTY -> fullDutyMultiplier
        DutyType.ONE_AND_HALF_DUTY -> oneAndHalfDutyMultiplier
        DutyType.DOUBLE_DUTY -> doubleDutyMultiplier
        DutyType.TWO_AND_HALF_DUTY -> twoAndHalfDutyMultiplier
        DutyType.TRIPLE_DUTY -> tripleDutyMultiplier
        DutyType.ABSENT -> absentMultiplier
        DutyType.LEAVE -> leaveMultiplier
    }
}

data class Worker(
    val id: String,
    val fullNameEn: String,
    val fullNameBn: String,
    val phoneNumber: String = "",
    val category: WorkCategory,
    val joiningDateIso: String = "2026-11-01",
    val leavingDateIso: String? = null,
    val dailyWage: Int,
    val dailyFoodAllowance: Int = 0,
    val isActive: Boolean = true,
    val avatarKey: String = "default",
    val photoPath: String? = null,
    val siteId: String = DEFAULT_SITE_ID,
    val localWorkerCode: String = id
)

data class DailyAttendanceRecord(
    val dateIso: String,
    val workerId: String,
    val dutyType: DutyType,
    val dailyWageSnapshot: Int,
    val multiplierSnapshot: Double,
    val earnedAmount: Int,
    val note: String = "",
    val updatedAtIso: String = "",
    val updatedByRole: UserRole = UserRole.ADMIN,
    val siteId: String = DEFAULT_SITE_ID
)

data class AttendanceAuditEntry(
    val auditId: String,
    val dateIso: String,
    val workerId: String,
    val previousDutyType: DutyType?,
    val newDutyType: DutyType,
    val previousEarned: Int?,
    val newEarned: Int,
    val changedByRole: UserRole,
    val changedAtIso: String,
    val reason: String,
    val siteId: String = DEFAULT_SITE_ID
)

data class PaymentLedgerEntry(
    val id: String,
    val workerId: String,
    val dateIso: String,
    val applicablePeriod: String = dateIso.take(7),
    val paymentType: PaymentType = PaymentType.SALARY,
    val paidAmount: Int,
    val referenceNo: String = "",
    val noteEn: String = "",
    val noteBn: String = "",
    val recordedByRole: UserRole = UserRole.ADMIN,
    val createdAtIso: String = "",
    val isVoided: Boolean = false,
    val siteId: String = DEFAULT_SITE_ID
)

data class AdvanceRecord(
    val id: String,
    val workerId: String,
    val advanceDateIso: String,
    val amount: Int,
    val referenceNo: String = "",
    val note: String = "",
    val recordedByRole: UserRole = UserRole.ADMIN,
    val createdAtIso: String = "",
    val isVoided: Boolean = false,
    val siteId: String = DEFAULT_SITE_ID
)

data class PaymentAllocation(
    val allocationId: String,
    val sourceType: String, // "PAYMENT" or "ADVANCE"
    val sourceId: String,
    val workerId: String,
    val payrollPeriod: String, // "YYYY-MM"
    val allocatedAmount: Int,
    val allocatedAtIso: String,
    val allocatedByRole: UserRole,
    val note: String = "",
    val isVoided: Boolean = false,
    val siteId: String = DEFAULT_SITE_ID
)

data class PayrollPeriodRecord(
    val periodIso: String, // "YYYY-MM"
    val status: PayrollPeriodStatus = PayrollPeriodStatus.OPEN,
    val finalizedAtIso: String? = null,
    val finalizedByRole: UserRole? = null,
    val reopenedAtIso: String? = null,
    val reopenedByRole: UserRole? = null,
    val notes: String = "",
    val siteId: String = DEFAULT_SITE_ID
)

data class PayrollAuditEntry(
    val auditId: String,
    val periodIso: String,
    val action: String, // "FINALIZED" | "REOPENED"
    val changedByRole: UserRole,
    val changedAtIso: String,
    val reason: String,
    val siteId: String = DEFAULT_SITE_ID
)

data class PaymentAuditEntry(
    val auditId: String,
    val transactionId: String,
    val workerId: String,
    val action: String,
    val previousAmount: Int?,
    val newAmount: Int,
    val changedByRole: UserRole,
    val changedAtIso: String,
    val reason: String,
    val siteId: String = DEFAULT_SITE_ID
)

data class WorkerMonthlySummary(
    val worker: Worker,
    val year: Int,
    val month: Int,
    val periodIso: String,
    val totalCalendarDays: Int,
    val halfDutyCount: Int,
    val fullDutyCount: Int,
    val oneAndHalfDutyCount: Int,
    val doubleDutyCount: Int,
    val twoAndHalfDutyCount: Int,
    val tripleDutyCount: Int,
    val absentCount: Int,
    val leaveCount: Int,
    val totalDutyUnits: Double,
    val totalEarnedAmount: Int,
    val totalPaidAmount: Int,
    val advanceAllocatedAmount: Int,
    val outstandingBalance: Int,
    val payrollStatus: WorkerPayrollStatus,
    val periodLockStatus: PayrollPeriodStatus,
    val siteId: String = worker.siteId,
    val siteName: String = ""
)

data class CurrentMonthProjection(
    val earnedToDate: Int,
    val paidToDate: Int,
    val remainingBalance: Int,
    val dutyUnitsToDate: Double,
    val estimatedMonthEndSalary: Int,
    val asOfDay: Int,
    val totalCalendarDays: Int
)

data class MasterSpreadsheetTotals(
    val totalWorkers: Int,
    val totalDutyUnits: Double,
    val totalEarnedSalary: Int,
    val totalPaidSalary: Int,
    val totalOutstandingSalary: Int
)

data class MonthlyExpenseBreakdown(
    val laborCost: Int,
    val foodAllowances: Int,
    val siteMaterials: Int
) {
    val total: Int
        get() = laborCost + foodAllowances + siteMaterials
}

data class SiteFinancialSummary(
    val site: Site,
    val activeWorkersCount: Int,
    val totalWorkersCount: Int,
    val totalEarnedPayroll: Int,
    val totalPaidPayroll: Int,
    val totalGeneralExpenses: Int,
    val totalOutstandingPayroll: Int
)

data class AllSitesOverviewSummary(
    val activeSiteCount: Int,
    val totalWorkersCount: Int,
    val combinedEarnedPayroll: Int,
    val combinedPaidPayroll: Int,
    val combinedGeneralExpenses: Int,
    val combinedOutstandingPayroll: Int,
    val perSiteSummaries: List<SiteFinancialSummary>
)

data class BackupRecordCounts(
    val sites: Int = 0,
    val workers: Int = 0,
    val attendanceRecords: Int = 0,
    val payments: Int = 0,
    val advances: Int = 0,
    val allocations: Int = 0,
    val expenses: Int = 0,
    val payrollPeriods: Int = 0,
    val workerPhotos: Int = 0,
    val receiptImages: Int = 0
)

data class BackupHistoryRecord(
    val backupId: String,
    val fileName: String,
    val createdAtIso: String,
    val fileSizeBytes: Long,
    val schemaVersion: Int,
    val formatVersion: Int,
    val counts: BackupRecordCounts,
    val checksumSha256: String,
    val verificationStatus: String, // "VERIFIED" | "WARNING" | "FAILED"
    val locationUriOrPath: String,
    val fileExists: Boolean = true
)

data class BackupProgress(
    val isRunning: Boolean = false,
    val operation: String = "", // "BACKUP" | "VERIFY" | "RESTORE" | "RECOVERY"
    val progressPercent: Int = 0,
    val stageLabel: String = ""
)

data class BackupValidationResult(
    val isValid: Boolean,
    val fileName: String,
    val createdAtIso: String,
    val appVersion: String,
    val schemaVersion: Int,
    val formatVersion: Int,
    val counts: BackupRecordCounts,
    val checksumVerified: Boolean,
    val sqliteIntegrityOk: Boolean,
    val isOlderThanCurrentData: Boolean,
    val missingMediaCount: Int,
    val errors: List<String> = emptyList(),
    val missingMediaFiles: List<String> = emptyList(),
    val countsMatched: Boolean = true,
    val mediaIntegrityOk: Boolean = true,
    val failedStage: String? = null,
    val safetyBackupPath: String? = null
)

enum class RestoreJournalStatus {
    NONE,
    STAGING,
    VALIDATED_STAGE,
    SAFETY_BACKUP_CREATED,
    SWAPPING,
    VERIFYING,
    COMPLETED,
    ROLLED_BACK,
    FAILED_NEEDS_RECOVERY
}

data class RestoreRecoveryReport(
    val recoveryNeeded: Boolean = false,
    val recoveryAttempted: Boolean = false,
    val recoverySucceeded: Boolean = true,
    val previousStatus: RestoreJournalStatus = RestoreJournalStatus.NONE,
    val stillRequiresManualRecovery: Boolean = false,
    val safetyBackupPath: String? = null,
    val message: String = ""
)

data class SyncEvent(
    val eventId: String,
    val entityType: String,
    val entityId: String,
    val siteId: String,
    val action: String,
    val createdAtIso: String,
    val syncStatus: String = "PENDING"
)
