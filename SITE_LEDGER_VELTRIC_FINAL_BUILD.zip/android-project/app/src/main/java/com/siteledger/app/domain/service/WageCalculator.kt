package com.siteledger.app.domain.service

import com.siteledger.app.domain.model.AdvanceRecord
import com.siteledger.app.domain.model.AllSitesOverviewSummary
import com.siteledger.app.domain.model.CurrentMonthProjection
import com.siteledger.app.domain.model.DailyAttendanceRecord
import com.siteledger.app.domain.model.DutyType
import com.siteledger.app.domain.model.MasterSpreadsheetTotals
import com.siteledger.app.domain.model.PaymentAllocation
import com.siteledger.app.domain.model.PaymentLedgerEntry
import com.siteledger.app.domain.model.PayrollPeriodRecord
import com.siteledger.app.domain.model.PayrollPeriodStatus
import com.siteledger.app.domain.model.Site
import com.siteledger.app.domain.model.SiteExpense
import com.siteledger.app.domain.model.SiteFinancialSummary
import com.siteledger.app.domain.model.SiteStatus
import com.siteledger.app.domain.model.Worker
import com.siteledger.app.domain.model.WorkerMonthlySummary
import com.siteledger.app.domain.model.WorkerPayrollStatus
import kotlin.math.roundToInt

/**
 * Pure integer-safe calculation engine for SITE LEDGER.
 *
 * Supports multi-site isolation, historical wage snapshots, explicit allocations,
 * worker transfers across sites without losing prior site balances,
 * and consolidated All-Sites totals without double counting.
 */
object WageCalculator {

    fun toMultiplierHundredths(multiplier: Double): Int =
        (multiplier * 100.0).roundToInt().coerceAtLeast(0)

    fun fromMultiplierHundredths(hundredths: Int): Double =
        hundredths / 100.0

    fun formatPeriodIso(year: Int, month: Int): String =
        "%04d-%02d".format(year, month)

    fun calculateDailyEarnedTaka(dailyWage: Int, multiplier: Double): Int {
        if (dailyWage <= 0) return 0
        val hundredths = toMultiplierHundredths(multiplier)
        return (dailyWage * hundredths + 50) / 100
    }

    fun sumDutyUnits(records: List<DailyAttendanceRecord>): Double {
        val totalHundredths = records.sumOf { toMultiplierHundredths(it.multiplierSnapshot) }
        return totalHundredths / 100.0
    }

    /**
     * Enforces uniqueness of localWorkerCode within the same construction site,
     * while allowing different sites to reuse numbering if desired.
     */
    fun isLocalWorkerCodeDuplicate(
        siteId: String,
        localWorkerCode: String,
        excludeWorkerId: String?,
        workers: List<Worker>
    ): Boolean {
        val normalized = localWorkerCode.trim().lowercase()
        if (normalized.isEmpty()) return false
        return workers.any {
            it.siteId == siteId &&
                it.id != excludeWorkerId &&
                it.localWorkerCode.trim().lowercase() == normalized
        }
    }

    /**
     * Computes monthly payroll summary for a worker.
     * When [siteIdFilter] is non-null, filters attendance/allocations/locks strictly to that site.
     * When [siteIdFilter] is null (consolidated All-Sites or worker profile rollup), aggregates across sites.
     */
    fun computeWorkerMonthlySummary(
        worker: Worker,
        year: Int,
        month: Int,
        allAttendance: List<DailyAttendanceRecord>,
        allAllocations: List<PaymentAllocation>,
        periodRecords: List<PayrollPeriodRecord> = emptyList(),
        siteIdFilter: String? = worker.siteId,
        sitesById: Map<String, Site> = emptyMap()
    ): WorkerMonthlySummary {
        val periodIso = formatPeriodIso(year, month)
        val monthPrefix = "$periodIso-"
        val monthAttendance = allAttendance.filter {
            it.workerId == worker.id &&
                it.dateIso.startsWith(monthPrefix) &&
                (siteIdFilter == null || it.siteId == siteIdFilter)
        }
        val monthAllocations = allAllocations.filter {
            !it.isVoided &&
                it.workerId == worker.id &&
                it.payrollPeriod == periodIso &&
                (siteIdFilter == null || it.siteId == siteIdFilter)
        }

        val totalCalendarDays = daysInMonth(year, month)
        val halfCount = monthAttendance.count { it.dutyType == DutyType.HALF_DUTY }
        val fullCount = monthAttendance.count { it.dutyType == DutyType.FULL_DUTY }
        val oneAndHalfCount = monthAttendance.count { it.dutyType == DutyType.ONE_AND_HALF_DUTY }
        val doubleCount = monthAttendance.count { it.dutyType == DutyType.DOUBLE_DUTY }
        val twoAndHalfCount = monthAttendance.count { it.dutyType == DutyType.TWO_AND_HALF_DUTY }
        val tripleCount = monthAttendance.count { it.dutyType == DutyType.TRIPLE_DUTY }
        val absentCount = monthAttendance.count { it.dutyType == DutyType.ABSENT }
        val leaveCount = monthAttendance.count { it.dutyType == DutyType.LEAVE }

        val totalDutyUnits = sumDutyUnits(monthAttendance)
        val totalEarned = monthAttendance.sumOf { it.earnedAmount }
        val totalPaid = monthAllocations.sumOf { it.allocatedAmount }
        val advanceAllocated = monthAllocations
            .filter { it.sourceType == "ADVANCE" }
            .sumOf { it.allocatedAmount }
        val outstanding = totalEarned - totalPaid

        val workingRecordCount =
            halfCount + fullCount + oneAndHalfCount + doubleCount + twoAndHalfCount + tripleCount
        val payrollStatus = when {
            workingRecordCount == 0 && totalPaid == 0 -> WorkerPayrollStatus.NO_ATTENDANCE
            outstanding < 0 -> WorkerPayrollStatus.OVERPAID
            outstanding == 0 && totalEarned > 0 -> WorkerPayrollStatus.PAID
            totalPaid > 0 && outstanding > 0 -> WorkerPayrollStatus.PARTIAL
            else -> WorkerPayrollStatus.UNPAID
        }

        val effectiveSiteId = siteIdFilter ?: worker.siteId
        val periodLockStatus = periodRecords
            .find { it.periodIso == periodIso && it.siteId == effectiveSiteId }
            ?.status ?: PayrollPeriodStatus.OPEN
        val siteName = sitesById[effectiveSiteId]?.siteName ?: effectiveSiteId

        return WorkerMonthlySummary(
            worker = worker,
            year = year,
            month = month,
            periodIso = periodIso,
            totalCalendarDays = totalCalendarDays,
            halfDutyCount = halfCount,
            fullDutyCount = fullCount,
            oneAndHalfDutyCount = oneAndHalfCount,
            doubleDutyCount = doubleCount,
            twoAndHalfDutyCount = twoAndHalfCount,
            tripleDutyCount = tripleCount,
            absentCount = absentCount,
            leaveCount = leaveCount,
            totalDutyUnits = totalDutyUnits,
            totalEarnedAmount = totalEarned,
            totalPaidAmount = totalPaid,
            advanceAllocatedAmount = advanceAllocated,
            outstandingBalance = outstanding,
            payrollStatus = payrollStatus,
            periodLockStatus = periodLockStatus,
            siteId = effectiveSiteId,
            siteName = siteName
        )
    }

    /**
     * Generates rows for the Master Site Payroll Spreadsheet.
     * In single-site mode, shows workers belonging to [selectedSiteId] PLUS any worker who has
     * historical attendance or allocations in that site for that month (so transferred workers' prior
     * site earnings remain visible without double counting across sites).
     * In All-Sites consolidated mode ([allSitesMode] = true), creates one row per (site, worker)
     * that either currently belongs to the site or has activity in that site during the month.
     */
    fun computeSpreadsheetRows(
        year: Int,
        month: Int,
        selectedSiteId: String,
        allSitesMode: Boolean,
        sites: List<Site>,
        workers: List<Worker>,
        allAttendance: List<DailyAttendanceRecord>,
        allAllocations: List<PaymentAllocation>,
        periodRecords: List<PayrollPeriodRecord>,
        allowedSiteIds: Set<String>? = null
    ): List<WorkerMonthlySummary> {
        val periodIso = formatPeriodIso(year, month)
        val monthPrefix = "$periodIso-"
        val sitesById = sites.associateBy { it.id }

        val targetSites = if (allSitesMode) {
            sites.filter { allowedSiteIds == null || it.id in allowedSiteIds }
        } else {
            sites.filter { it.id == selectedSiteId }
        }

        val rows = mutableListOf<WorkerMonthlySummary>()
        targetSites.forEach { site ->
            val activityWorkerIds = buildSet {
                workers.filter { it.siteId == site.id }.forEach { add(it.id) }
                allAttendance.filter { it.siteId == site.id && it.dateIso.startsWith(monthPrefix) }
                    .forEach { add(it.workerId) }
                allAllocations.filter { !it.isVoided && it.siteId == site.id && it.payrollPeriod == periodIso }
                    .forEach { add(it.workerId) }
            }
            workers.filter { it.id in activityWorkerIds }.forEach { worker ->
                rows.add(
                    computeWorkerMonthlySummary(
                        worker = worker,
                        year = year,
                        month = month,
                        allAttendance = allAttendance,
                        allAllocations = allAllocations,
                        periodRecords = periodRecords,
                        siteIdFilter = site.id,
                        sitesById = sitesById
                    )
                )
            }
        }
        return rows
    }

    /**
     * Computes clean separation of:
     * 1) Earned Payroll (sum of attendance snapshots)
     * 2) Actual Paid Payroll (sum of non-voided allocations)
     * 3) General Site Expenses (sum of non-voided SiteExpense items)
     * 4) Outstanding Payroll (Earned - Paid)
     * Never double-counts payroll inside general site expenses.
     */
    fun computeSiteFinancialSummary(
        site: Site,
        workers: List<Worker>,
        attendance: List<DailyAttendanceRecord>,
        allocations: List<PaymentAllocation>,
        expenses: List<SiteExpense>,
        periodIsoFilter: String? = null
    ): SiteFinancialSummary {
        val siteWorkers = workers.filter { it.siteId == site.id }
        val activeWorkersCount = siteWorkers.count { it.isActive }
        val monthPrefix = periodIsoFilter?.let { "$it-" }

        val earnedPayroll = attendance
            .filter { it.siteId == site.id && (monthPrefix == null || it.dateIso.startsWith(monthPrefix)) }
            .sumOf { it.earnedAmount }

        val paidPayroll = allocations
            .filter { !it.isVoided && it.siteId == site.id && (periodIsoFilter == null || it.payrollPeriod == periodIsoFilter) }
            .sumOf { it.allocatedAmount }

        val generalExpenses = expenses
            .filter { !it.isVoided && it.siteId == site.id && (monthPrefix == null || it.expenseDateIso.startsWith(monthPrefix)) }
            .sumOf { it.amount }

        return SiteFinancialSummary(
            site = site,
            activeWorkersCount = activeWorkersCount,
            totalWorkersCount = siteWorkers.size,
            totalEarnedPayroll = earnedPayroll,
            totalPaidPayroll = paidPayroll,
            totalGeneralExpenses = generalExpenses,
            totalOutstandingPayroll = earnedPayroll - paidPayroll
        )
    }

    fun computeAllSitesOverview(
        sites: List<Site>,
        workers: List<Worker>,
        attendance: List<DailyAttendanceRecord>,
        allocations: List<PaymentAllocation>,
        expenses: List<SiteExpense>,
        periodIsoFilter: String? = null,
        allowedSiteIds: Set<String>? = null
    ): AllSitesOverviewSummary {
        val visibleSites = sites.filter { allowedSiteIds == null || it.id in allowedSiteIds }
        val perSite = visibleSites.map { site ->
            computeSiteFinancialSummary(site, workers, attendance, allocations, expenses, periodIsoFilter)
        }
        return AllSitesOverviewSummary(
            activeSiteCount = visibleSites.count { it.status == SiteStatus.ACTIVE },
            totalWorkersCount = perSite.sumOf { it.totalWorkersCount },
            combinedEarnedPayroll = perSite.sumOf { it.totalEarnedPayroll },
            combinedPaidPayroll = perSite.sumOf { it.totalPaidPayroll },
            combinedGeneralExpenses = perSite.sumOf { it.totalGeneralExpenses },
            combinedOutstandingPayroll = perSite.sumOf { it.totalOutstandingPayroll },
            perSiteSummaries = perSite
        )
    }

    fun computeCurrentMonthProjection(
        summary: WorkerMonthlySummary,
        asOfDay: Int
    ): CurrentMonthProjection {
        val clampedDay = asOfDay.coerceIn(1, summary.totalCalendarDays)
        val remainingDays = (summary.totalCalendarDays - clampedDay).coerceAtLeast(0)
        val estimatedAdditional = if (summary.totalEarnedAmount > 0) {
            (summary.totalEarnedAmount * remainingDays) / clampedDay
        } else {
            0
        }
        return CurrentMonthProjection(
            earnedToDate = summary.totalEarnedAmount,
            paidToDate = summary.totalPaidAmount,
            remainingBalance = summary.outstandingBalance,
            dutyUnitsToDate = summary.totalDutyUnits,
            estimatedMonthEndSalary = summary.totalEarnedAmount + estimatedAdditional,
            asOfDay = clampedDay,
            totalCalendarDays = summary.totalCalendarDays
        )
    }

    fun computeSpreadsheetTotals(rows: List<WorkerMonthlySummary>): MasterSpreadsheetTotals {
        val totalHundredths = rows.sumOf { toMultiplierHundredths(it.totalDutyUnits) }
        val earned = rows.sumOf { it.totalEarnedAmount }
        val paid = rows.sumOf { it.totalPaidAmount }
        return MasterSpreadsheetTotals(
            totalWorkers = rows.size,
            totalDutyUnits = totalHundredths / 100.0,
            totalEarnedSalary = earned,
            totalPaidSalary = paid,
            totalOutstandingSalary = earned - paid
        )
    }

    fun computeWorkerOverallBalances(
        workerId: String,
        allAttendance: List<DailyAttendanceRecord>,
        allAllocations: List<PaymentAllocation>,
        siteIdFilter: String? = null
    ): Triple<Int, Int, Int> {
        val totalEarned = allAttendance
            .filter { it.workerId == workerId && (siteIdFilter == null || it.siteId == siteIdFilter) }
            .sumOf { it.earnedAmount }
        val totalPaid = allAllocations
            .filter { !it.isVoided && it.workerId == workerId && (siteIdFilter == null || it.siteId == siteIdFilter) }
            .sumOf { it.allocatedAmount }
        return Triple(totalEarned, totalPaid, totalEarned - totalPaid)
    }

    fun computeUnallocatedAdvanceBalance(
        workerId: String,
        advances: List<AdvanceRecord>,
        allocations: List<PaymentAllocation>,
        siteIdFilter: String? = null
    ): Int {
        val totalAdvances = advances
            .filter { !it.isVoided && it.workerId == workerId && (siteIdFilter == null || it.siteId == siteIdFilter) }
            .sumOf { it.amount }
        val totalAllocatedFromAdvances = allocations
            .filter {
                !it.isVoided &&
                    it.workerId == workerId &&
                    it.sourceType == "ADVANCE" &&
                    (siteIdFilter == null || it.siteId == siteIdFilter)
            }
            .sumOf { it.allocatedAmount }
        return (totalAdvances - totalAllocatedFromAdvances).coerceAtLeast(0)
    }

    fun computeAdvanceRemaining(
        advance: AdvanceRecord,
        allocations: List<PaymentAllocation>
    ): Int {
        if (advance.isVoided) return 0
        val allocated = allocations
            .filter { !it.isVoided && it.sourceType == "ADVANCE" && it.sourceId == advance.id }
            .sumOf { it.allocatedAmount }
        return (advance.amount - allocated).coerceAtLeast(0)
    }

    fun collectWorkerPayrollPeriods(
        worker: Worker,
        allAttendance: List<DailyAttendanceRecord>,
        allAllocations: List<PaymentAllocation>,
        allPayments: List<PaymentLedgerEntry>,
        currentPeriodIso: String = "2026-11"
    ): List<Pair<Int, Int>> {
        val periods = mutableSetOf<String>()
        periods.add(currentPeriodIso)
        allAttendance
            .filter { it.workerId == worker.id && it.dateIso.length >= 7 }
            .forEach { periods.add(it.dateIso.substring(0, 7)) }
        allAllocations
            .filter { !it.isVoided && it.workerId == worker.id && it.payrollPeriod.length == 7 }
            .forEach { periods.add(it.payrollPeriod) }
        allPayments
            .filter { !it.isVoided && it.workerId == worker.id && it.applicablePeriod.length == 7 }
            .forEach { periods.add(it.applicablePeriod) }

        return periods
            .mapNotNull { p ->
                val parts = p.split("-")
                if (parts.size == 2) {
                    val y = parts[0].toIntOrNull()
                    val m = parts[1].toIntOrNull()
                    if (y != null && m != null && m in 1..12) y to m else null
                } else null
            }
            .sortedWith(compareByDescending<Pair<Int, Int>> { it.first }.thenByDescending { it.second })
    }

    fun daysInMonth(year: Int, month: Int): Int = when (month) {
        1, 3, 5, 7, 8, 10, 12 -> 31
        4, 6, 9, 11 -> 30
        2 -> if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) 29 else 28
        else -> 30
    }
}
