package com.siteledger.app.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.siteledger.app.data.backup.BackupRestoreException
import com.siteledger.app.data.repository.InMemorySampleSiteLedgerRepository
import com.siteledger.app.data.repository.SiteLedgerRepository
import com.siteledger.app.data.sample.SampleSiteData
import com.siteledger.app.domain.model.AppLanguage
import com.siteledger.app.domain.model.BackupValidationResult
import com.siteledger.app.domain.model.DEFAULT_SITE_ID
import com.siteledger.app.domain.model.DutyMultiplierConfig
import com.siteledger.app.domain.model.DutyType
import com.siteledger.app.domain.model.NavDestination
import com.siteledger.app.domain.model.RestoreRecoveryReport
import com.siteledger.app.domain.model.Site
import com.siteledger.app.domain.model.SiteExpense
import com.siteledger.app.domain.model.SiteStatus
import com.siteledger.app.domain.model.UserRole
import com.siteledger.app.domain.model.WorkCategory
import com.siteledger.app.domain.model.Worker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SiteLedgerViewModel(
    private val repository: SiteLedgerRepository = InMemorySampleSiteLedgerRepository()
) : ViewModel() {

    val sites = repository.sites
    val workers = repository.workers
    val workerTransfers = repository.workerTransfers
    val attendanceRecords = repository.attendanceRecords
    val attendanceAudits = repository.attendanceAudits
    val payments = repository.payments
    val advances = repository.advances
    val paymentAllocations = repository.paymentAllocations
    val paymentAudits = repository.paymentAudits
    val payrollPeriods = repository.payrollPeriods
    val payrollAudits = repository.payrollAudits
    val dutyMultipliers = repository.dutyMultipliers
    val expenseCategories = repository.expenseCategories
    val expenses = repository.expenses
    val expenseAudits = repository.expenseAudits
    val userSiteAccounts = repository.userSiteAccounts
    val backupHistory = repository.backupHistory
    val backupProgress = repository.backupProgress
    val monthlyExpenses = repository.monthlyExpenses

    private val _currentLanguage = MutableStateFlow(AppLanguage.ENGLISH)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    private val _currentDestination = MutableStateFlow(NavDestination.DASHBOARD)
    val currentDestination: StateFlow<NavDestination> = _currentDestination.asStateFlow()

    private val _selectedSiteId = MutableStateFlow(DEFAULT_SITE_ID)
    val selectedSiteId: StateFlow<String> = _selectedSiteId.asStateFlow()

    private val _selectedDate = MutableStateFlow(SampleSiteData.availableDates.first())
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    private val _activeRole = MutableStateFlow(UserRole.ADMIN)
    val activeRole: StateFlow<UserRole> = _activeRole.asStateFlow()

    private val _pendingRestoreInspectUri = MutableStateFlow<Pair<Uri, BackupValidationResult>?>(null)
    val pendingRestoreInspectUri: StateFlow<Pair<Uri, BackupValidationResult>?> = _pendingRestoreInspectUri.asStateFlow()

    private val _lastBackupValidation = MutableStateFlow<BackupValidationResult?>(null)
    val lastBackupValidation: StateFlow<BackupValidationResult?> = _lastBackupValidation.asStateFlow()

    private val _restoreRecoveryReport = MutableStateFlow<RestoreRecoveryReport?>(null)
    val restoreRecoveryReport: StateFlow<RestoreRecoveryReport?> = _restoreRecoveryReport.asStateFlow()

    private val _backupStatusDetail = MutableStateFlow<String?>(null)
    val backupStatusDetail: StateFlow<String?> = _backupStatusDetail.asStateFlow()

    private val _statusBannerMessage = MutableStateFlow<String?>(null)
    val statusBannerMessage: StateFlow<String?> = _statusBannerMessage.asStateFlow()

    init {
        runStartupRecoveryCheck()
    }

    fun runStartupRecoveryCheck() {
        viewModelScope.launch {
            val report = repository.recoverInterruptedRestoreIfNeeded()
            if (report.recoveryNeeded) {
                _restoreRecoveryReport.value = report
                _statusBannerMessage.value = if (report.stillRequiresManualRecovery) {
                    "Recovery required: ${report.message}"
                } else {
                    report.message
                }
            } else {
                _restoreRecoveryReport.value = null
            }
        }
    }

    fun clearStatusBanner() {
        _statusBannerMessage.value = null
    }

    fun dismissPendingRestore() {
        _pendingRestoreInspectUri.value = null
    }

    fun setLanguage(language: AppLanguage) {
        _currentLanguage.value = language
    }

    fun setActiveRole(role: UserRole) {
        _activeRole.value = role
        val accessible = repository.getAccessibleSiteIds(role)
        if (_selectedSiteId.value !in accessible && accessible.isNotEmpty()) {
            _selectedSiteId.value = accessible.first()
        }
    }

    fun selectSite(siteId: String) {
        if (repository.canRoleAccessSite(_activeRole.value, siteId)) {
            _selectedSiteId.value = siteId
        }
    }

    fun canAccessSite(siteId: String): Boolean =
        repository.canRoleAccessSite(_activeRole.value, siteId)

    fun getAccessibleSiteIds(): Set<String> =
        repository.getAccessibleSiteIds(_activeRole.value)

    fun getDutyConfigForSelectedSite(): DutyMultiplierConfig =
        repository.getDutyMultipliersForSite(_selectedSiteId.value)

    fun navigateTo(destination: NavDestination) {
        _currentDestination.value = destination
    }

    fun selectDate(dateIso: String) {
        _selectedDate.value = dateIso
    }

    fun isPeriodFinalized(periodIso: String, siteId: String = _selectedSiteId.value): Boolean =
        repository.isPeriodFinalized(siteId, periodIso)

    // --- Sites & Permissions ---
    fun addOrUpdateSite(site: Site) {
        viewModelScope.launch {
            val ok = repository.addOrUpdateSite(site, _activeRole.value)
            _statusBannerMessage.value = if (ok) "Saved site ${site.siteName}" else "Unable to save site (duplicate code or insufficient permission)"
        }
    }

    fun updateSiteStatus(siteId: String, status: SiteStatus) {
        viewModelScope.launch {
            repository.archiveOrUpdateSiteStatus(siteId, status, _activeRole.value)
        }
    }

    fun updateUserSiteAssignments(roleToUpdate: UserRole, siteIds: List<String>) {
        viewModelScope.launch {
            repository.updateUserSiteAssignments(roleToUpdate, siteIds, _activeRole.value)
        }
    }

    // --- Workers & Transfers ---
    fun addWorker(
        fullName: String,
        localWorkerCode: String,
        phoneNumber: String,
        category: WorkCategory,
        joiningDateIso: String,
        dailyWage: Int,
        foodAllowance: Int,
        pendingPhotoUri: Uri?,
        siteId: String = _selectedSiteId.value
    ) {
        viewModelScope.launch {
            val globalId = "W-${siteId.takeLast(4)}-${localWorkerCode.trim().replace(" ", "")}-${System.currentTimeMillis().toString().takeLast(3)}"
            val ok = repository.addWorker(
                worker = Worker(
                    id = globalId,
                    fullNameEn = fullName,
                    fullNameBn = fullName,
                    phoneNumber = phoneNumber,
                    category = category,
                    joiningDateIso = joiningDateIso,
                    leavingDateIso = null,
                    dailyWage = dailyWage,
                    dailyFoodAllowance = foodAllowance,
                    isActive = true,
                    avatarKey = "default",
                    photoPath = null,
                    siteId = siteId,
                    localWorkerCode = localWorkerCode.trim()
                ),
                pendingPhotoUri = pendingPhotoUri,
                role = _activeRole.value
            )
            if (!ok) {
                _statusBannerMessage.value = "Duplicate Worker ID at this site or permission denied."
            }
        }
    }

    fun updateWorker(
        updatedWorker: Worker,
        pendingPhotoUri: Uri?,
        removeExistingPhoto: Boolean
    ) {
        viewModelScope.launch {
            val ok = repository.updateWorker(updatedWorker, pendingPhotoUri, removeExistingPhoto, _activeRole.value)
            if (!ok) {
                _statusBannerMessage.value = "Duplicate Worker ID at this site or permission denied."
            }
        }
    }

    fun transferWorker(
        workerId: String,
        targetSiteId: String,
        newLocalWorkerCode: String?,
        notes: String
    ) {
        viewModelScope.launch {
            val ok = repository.transferWorker(workerId, targetSiteId, newLocalWorkerCode, notes, _activeRole.value)
            _statusBannerMessage.value = if (ok) {
                "Worker transferred cleanly; prior site records remain intact."
            } else {
                "Transfer blocked: Admin required or Worker ID conflict at destination site."
            }
        }
    }

    // --- Attendance & Payroll ---
    fun recordAttendance(
        dateIso: String,
        worker: Worker,
        dutyType: DutyType,
        note: String,
        editReason: String = "",
        siteId: String = _selectedSiteId.value
    ) {
        if (_activeRole.value == UserRole.ACCOUNTANT) return
        viewModelScope.launch {
            repository.recordAttendance(siteId, dateIso, worker, dutyType, note, _activeRole.value, editReason)
        }
    }

    fun recordPayment(
        workerId: String,
        paymentDateIso: String,
        applicablePeriod: String,
        paidAmount: Int,
        referenceNo: String,
        note: String,
        submissionToken: String,
        siteId: String = _selectedSiteId.value
    ) {
        if (_activeRole.value == UserRole.MANAGER) return
        viewModelScope.launch {
            repository.recordPaymentTransaction(siteId, workerId, paymentDateIso, applicablePeriod, paidAmount, referenceNo, note, _activeRole.value, submissionToken)
        }
    }

    fun recordAdvance(
        workerId: String,
        advanceDateIso: String,
        amount: Int,
        referenceNo: String,
        note: String,
        submissionToken: String,
        siteId: String = _selectedSiteId.value
    ) {
        if (_activeRole.value == UserRole.MANAGER) return
        viewModelScope.launch {
            repository.recordAdvance(siteId, workerId, advanceDateIso, amount, referenceNo, note, _activeRole.value, submissionToken)
        }
    }

    fun allocateAdvanceToPeriod(advanceId: String, targetPeriod: String, amountToAllocate: Int, note: String) {
        if (_activeRole.value == UserRole.MANAGER) return
        viewModelScope.launch {
            repository.allocateAdvanceToPeriod(advanceId, targetPeriod, amountToAllocate, _activeRole.value, note)
        }
    }

    fun voidPayment(transactionId: String, reason: String) {
        if (_activeRole.value == UserRole.MANAGER) return
        viewModelScope.launch {
            repository.voidPaymentTransaction(transactionId, _activeRole.value, reason)
        }
    }

    fun finalizePayrollPeriod(periodIso: String, reason: String, siteId: String = _selectedSiteId.value) {
        if (_activeRole.value != UserRole.ADMIN) return
        viewModelScope.launch {
            repository.finalizePayrollPeriod(siteId, periodIso, _activeRole.value, reason)
        }
    }

    fun reopenPayrollPeriod(periodIso: String, reason: String, siteId: String = _selectedSiteId.value) {
        if (_activeRole.value != UserRole.ADMIN) return
        viewModelScope.launch {
            repository.reopenPayrollPeriod(siteId, periodIso, _activeRole.value, reason)
        }
    }

    fun updateDutyMultipliers(config: DutyMultiplierConfig) {
        if (_activeRole.value != UserRole.ADMIN) return
        viewModelScope.launch {
            repository.updateDutyMultipliers(config.copy(siteId = _selectedSiteId.value))
        }
    }

    // --- Expenses ---
    fun addCustomExpenseCategory(nameEn: String, nameBn: String) {
        viewModelScope.launch {
            repository.addExpenseCategory(nameEn, nameBn, _activeRole.value)
        }
    }

    fun addOrUpdateExpense(
        expense: SiteExpense,
        pendingReceiptUri: Uri?,
        removeExistingReceipt: Boolean
    ) {
        viewModelScope.launch {
            repository.addOrUpdateExpense(expense, pendingReceiptUri, removeExistingReceipt, _activeRole.value)
        }
    }

    fun voidExpense(expenseId: String, reason: String) {
        viewModelScope.launch {
            repository.voidExpense(expenseId, _activeRole.value, reason)
        }
    }

    // --- Backup & Restore ---
    fun suggestedBackupFileName(): String = repository.suggestedBackupFileName()

    fun createFullBackup(targetUri: Uri) {
        viewModelScope.launch {
            _lastBackupValidation.value = null
            _backupStatusDetail.value = "Backup creation started..."
            _statusBannerMessage.value = "Backup creation started..."
            val res = repository.createFullBackupToUri(targetUri)
            res.fold(
                onSuccess = { rec ->
                    val msg = "Backup creation successful (${rec.fileName}) · Sites: ${rec.counts.sites} · Workers: ${rec.counts.workers} · Photos: ${rec.counts.workerPhotos} · Receipts: ${rec.counts.receiptImages} · Expenses: ${rec.counts.expenses}"
                    _backupStatusDetail.value = msg
                    _statusBannerMessage.value = msg
                },
                onFailure = { err ->
                    val msg = "Backup failed: ${err.message ?: "I/O error"}"
                    _backupStatusDetail.value = msg
                    _statusBannerMessage.value = msg
                }
            )
        }
    }

    fun inspectBackupForVerifyOrRestore(sourceUri: Uri, prepareForRestore: Boolean) {
        viewModelScope.launch {
            val validation = repository.inspectBackupUri(sourceUri)
            _lastBackupValidation.value = validation
            if (!validation.isValid) {
                val missingInfo = if (validation.missingMediaFiles.isNotEmpty()) {
                    " | Missing media: ${validation.missingMediaFiles.joinToString(", ")}"
                } else ""
                val msg = "Backup validation failed: ${validation.errors.joinToString("; ")}$missingInfo"
                _backupStatusDetail.value = msg
                _statusBannerMessage.value = msg
                _pendingRestoreInspectUri.value = null
            } else if (prepareForRestore) {
                val msg = "Restore validation successful · Format v${validation.formatVersion} · Schema v${validation.schemaVersion} · Workers: ${validation.counts.workers} · Photos: ${validation.counts.workerPhotos}"
                _backupStatusDetail.value = msg
                _pendingRestoreInspectUri.value = sourceUri to validation
            } else {
                val msg = "Backup validation successful · Format v${validation.formatVersion} · Schema v${validation.schemaVersion} · Workers: ${validation.counts.workers} · Attendance: ${validation.counts.attendanceRecords} · Payments: ${validation.counts.payments} · Expenses: ${validation.counts.expenses} · Photos: ${validation.counts.workerPhotos} · Receipts: ${validation.counts.receiptImages}"
                _backupStatusDetail.value = msg
                _statusBannerMessage.value = msg
            }
        }
    }

    fun confirmRestoreFromPendingUri() {
        val (uri, _) = _pendingRestoreInspectUri.value ?: return
        _pendingRestoreInspectUri.value = null
        viewModelScope.launch {
            _backupStatusDetail.value = "Restore in progress..."
            _statusBannerMessage.value = "Restore in progress..."
            val res = repository.restoreFromBackupUri(uri)
            res.fold(
                onSuccess = { v ->
                    _restoreRecoveryReport.value = null
                    val msg = "Restore successful (${v.fileName}) · Sites: ${v.counts.sites} · Workers: ${v.counts.workers} · Photos: ${v.counts.workerPhotos} · Receipts: ${v.counts.receiptImages}"
                    _backupStatusDetail.value = msg
                    _statusBannerMessage.value = msg
                },
                onFailure = { err ->
                    val msg = if (err is BackupRestoreException) {
                        if (!err.recoverySucceeded) {
                            _restoreRecoveryReport.value = RestoreRecoveryReport(
                                recoveryNeeded = true,
                                recoveryAttempted = err.recoveryAttempted,
                                recoverySucceeded = false,
                                stillRequiresManualRecovery = true,
                                safetyBackupPath = err.safetyBackupPath,
                                message = err.message ?: "Restore failed"
                            )
                            "Recovery required · Failed at ${err.failedStage}: ${err.message}"
                        } else {
                            "Restore failed at ${err.failedStage} (previous data preserved cleanly): ${err.message}"
                        }
                    } else {
                        "Restore failed (previous data safe): ${err.message ?: "error"}"
                    }
                    _backupStatusDetail.value = msg
                    _statusBannerMessage.value = msg
                }
            )
        }
    }

    fun refreshBackupHistory() {
        viewModelScope.launch {
            repository.refreshBackupHistoryAvailability()
        }
    }

    fun resetSampleData() {
        viewModelScope.launch {
            repository.resetSampleData()
            _selectedSiteId.value = DEFAULT_SITE_ID
        }
    }

    class Factory(private val repository: SiteLedgerRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SiteLedgerViewModel(repository) as T
        }
    }
}
