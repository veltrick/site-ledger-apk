package com.siteledger.app.ui.components

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddAPhoto
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.siteledger.app.data.local.WorkerPhotoStorage
import com.siteledger.app.ui.i18n.AppStrings
import com.siteledger.app.ui.theme.CanvasGrey
import com.siteledger.app.ui.theme.CrispWhite
import com.siteledger.app.ui.theme.DeepNavyBlue
import com.siteledger.app.ui.theme.EngineeringBlue
import com.siteledger.app.ui.theme.SlateInk
import com.siteledger.app.ui.theme.SlateMuted
import com.siteledger.app.ui.theme.SoftBlueTint
import com.siteledger.app.ui.theme.StatusRed
import com.siteledger.app.ui.theme.SubtleBorderGrey

@Composable
fun SampleDataNoticeBanner(noticeText: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = SoftBlueTint,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, SubtleBorderGrey)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Outlined.Info,
                contentDescription = null,
                tint = EngineeringBlue,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = noticeText,
                style = MaterialTheme.typography.bodySmall,
                color = DeepNavyBlue
            )
        }
    }
}

@Composable
fun SummaryMetricCard(
    label: String,
    value: String,
    supportingText: String? = null,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CrispWhite),
        border = BorderStroke(1.dp, SubtleBorderGrey),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = SlateMuted
            )
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = SlateInk
            )
            if (supportingText != null) {
                Text(
                    text = supportingText,
                    style = MaterialTheme.typography.bodySmall,
                    color = EngineeringBlue
                )
            }
        }
    }
}

/**
 * Displays a circular worker photo loaded from private internal storage (photoPath)
 * or a clean default profile placeholder when no photo exists.
 */
@Composable
fun WorkerAvatar(
    name: String,
    photoPath: String?,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp
) {
    val context = LocalContext.current
    val storage = remember(context) { WorkerPhotoStorage(context) }
    var bitmap by remember(photoPath) { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(photoPath) {
        bitmap = if (!photoPath.isNullOrBlank()) {
            storage.loadSavedBitmap(photoPath)
        } else {
            null
        }
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(SoftBlueTint)
            .border(1.dp, SubtleBorderGrey, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        val loaded = bitmap
        if (loaded != null) {
            Image(
                bitmap = loaded.asImageBitmap(),
                contentDescription = name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(
                imageVector = Icons.Outlined.Person,
                contentDescription = name,
                tint = DeepNavyBlue,
                modifier = Modifier.size(size * 0.52f)
            )
        }
    }
}

/**
 * Reusable circular Photo Picker component for Add Worker and Edit Worker dialogs.
 * Uses Android's ActivityResultContracts.PickVisualMedia without requesting broad storage permissions.
 */
@Composable
fun WorkerPhotoPickerSection(
    strings: AppStrings,
    existingPhotoPath: String?,
    pendingPhotoUri: Uri?,
    photoRemoved: Boolean,
    onPhotoPicked: (Uri) -> Unit,
    onRemovePhoto: () -> Unit
) {
    val context = LocalContext.current
    val storage = remember(context) { WorkerPhotoStorage(context) }

    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(pendingPhotoUri, existingPhotoPath, photoRemoved) {
        previewBitmap = when {
            pendingPhotoUri != null -> storage.loadPreviewBitmap(pendingPhotoUri)
            !photoRemoved && !existingPhotoPath.isNullOrBlank() ->
                storage.loadSavedBitmap(existingPhotoPath)
            else -> null
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onPhotoPicked(uri)
        }
    }

    val hasVisiblePhoto = previewBitmap != null

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(CanvasGrey)
            .border(1.dp, SubtleBorderGrey, RoundedCornerShape(14.dp))
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(88.dp)
                .clip(CircleShape)
                .background(SoftBlueTint)
                .border(2.dp, CrispWhite, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            val loaded = previewBitmap
            if (loaded != null) {
                Image(
                    bitmap = loaded.asImageBitmap(),
                    contentDescription = strings.workerProfile,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = Icons.Outlined.Person,
                    contentDescription = strings.noPhotoPlaceholderText,
                    tint = DeepNavyBlue,
                    modifier = Modifier.size(42.dp)
                )
            }
        }

        if (pendingPhotoUri != null) {
            Text(
                text = strings.photoPreviewNotice,
                style = MaterialTheme.typography.bodySmall,
                color = EngineeringBlue
            )
        }

        if (!hasVisiblePhoto) {
            OutlinedButton(
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                }
            ) {
                Icon(
                    imageVector = Icons.Outlined.AddAPhoto,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(strings.addPhoto)
            }
        } else {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(strings.replacePhoto)
                }

                TextButton(
                    onClick = onRemovePhoto,
                    colors = ButtonDefaults.textButtonColors(contentColor = StatusRed)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.DeleteOutline,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(strings.removePhoto)
                }
            }
        }
    }
}
