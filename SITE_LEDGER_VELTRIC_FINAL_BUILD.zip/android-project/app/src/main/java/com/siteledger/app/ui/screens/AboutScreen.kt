package com.siteledger.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apartment
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Engineering
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.siteledger.app.R
import com.siteledger.app.ui.i18n.AppStrings

private val VeltricNavyDeep = Color(0xFF040A18)
private val VeltricNavyMid = Color(0xFF08142B)
private val VeltricCardBg = Color(0xFF0B1933)
private val VeltricCardInnerBg = Color(0xFF071124)
private val VeltricBorderBlue = Color(0x3D38BDF8)
private val VeltricBorderSubtle = Color(0x2E3B82F6)
private val VeltricCyanAccent = Color(0xFF38BDF8)
private val VeltricElectricBlue = Color(0xFF60A5FA)
private val VeltricTextPrimary = Color(0xFFF8FAFC)
private val VeltricTextSecondary = Color(0xFFCBD5E1)
private val VeltricTextMuted = Color(0xFF94A3B8)

@Composable
fun AboutScreen(strings: AppStrings) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(VeltricNavyDeep, VeltricNavyMid, VeltricNavyDeep)
                )
            ),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Brand Hero Card with Exact Official VELTRIC PNG Logo
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = VeltricCardBg),
                border = BorderStroke(1.dp, VeltricBorderBlue)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        // Subtle ambient halo strictly behind the unmodified PNG
                        Canvas(modifier = Modifier.size(184.dp)) {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        Color(0x4000D4FF),
                                        Color(0x1F0066FF),
                                        Color.Transparent
                                    ),
                                    center = center,
                                    radius = size.minDimension / 2f
                                )
                            )
                        }

                        Image(
                            painter = painterResource(id = R.drawable.veltric_logo),
                            contentDescription = strings.aboutCompanyName,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.size(138.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = strings.aboutCompanyName,
                        style = MaterialTheme.typography.labelLarge,
                        letterSpacing = 3.sp,
                        fontWeight = FontWeight.Bold,
                        color = VeltricCyanAccent
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = strings.aboutProductName,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = VeltricTextPrimary,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = VeltricCardInnerBg,
                        border = BorderStroke(1.dp, VeltricBorderBlue)
                    ) {
                        Text(
                            text = strings.aboutAttribution,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = VeltricElectricBlue,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = VeltricBorderSubtle)
                    Spacer(modifier = Modifier.height(14.dp))

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = VeltricCardInnerBg,
                        border = BorderStroke(1.dp, VeltricBorderSubtle)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Person,
                                contentDescription = null,
                                tint = VeltricCyanAccent,
                                modifier = Modifier.size(20.dp)
                            )
                            Column {
                                Text(
                                    text = strings.aboutFounderLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = VeltricTextMuted
                                )
                                Text(
                                    text = strings.aboutFounderName,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = VeltricTextPrimary,
                                    letterSpacing = 0.6.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. About VELTRIC Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = VeltricCardBg),
                border = BorderStroke(1.dp, VeltricBorderSubtle)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Apartment,
                            contentDescription = null,
                            tint = VeltricCyanAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = strings.aboutVeltricHeading,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = VeltricTextPrimary
                        )
                    }

                    Text(
                        text = strings.aboutVeltricBody,
                        style = MaterialTheme.typography.bodyMedium,
                        color = VeltricTextSecondary,
                        lineHeight = 22.sp
                    )
                }
            }
        }

        // 3. About SITE LEDGER Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = VeltricCardBg),
                border = BorderStroke(1.dp, VeltricBorderSubtle)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Engineering,
                            contentDescription = null,
                            tint = VeltricCyanAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = strings.aboutSiteLedgerHeading,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = VeltricTextPrimary
                        )
                    }

                    Text(
                        text = strings.aboutSiteLedgerIntro,
                        style = MaterialTheme.typography.bodyMedium,
                        color = VeltricTextSecondary,
                        lineHeight = 22.sp
                    )

                    Text(
                        text = strings.aboutHelpsManageTitle,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = VeltricElectricBlue,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        strings.aboutCapabilities.forEach { capability ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.CheckCircle,
                                    contentDescription = null,
                                    tint = VeltricCyanAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = capability,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = VeltricTextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
