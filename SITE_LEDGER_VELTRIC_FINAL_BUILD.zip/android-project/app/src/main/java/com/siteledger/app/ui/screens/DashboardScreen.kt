package com.siteledger.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.siteledger.app.domain.model.NavDestination
import com.siteledger.app.domain.model.Site
import com.siteledger.app.ui.components.SampleDataNoticeBanner
import com.siteledger.app.ui.components.SummaryMetricCard
import com.siteledger.app.ui.i18n.AppStrings
import com.siteledger.app.ui.theme.CrispWhite
import com.siteledger.app.ui.theme.EngineeringBlue
import com.siteledger.app.ui.theme.SlateInk
import com.siteledger.app.ui.theme.SlateMuted
import com.siteledger.app.ui.theme.SubtleBorderGrey

@Composable
fun DashboardScreen(
    strings: AppStrings,
    activeSite: Site,
    totalWorkers: Int,
    presentToday: Int,
    absentToday: Int,
    todaysPaymentsTotal: Int,
    earnedPayrollTotal: Int,
    paidPayrollTotal: Int,
    generalExpensesTotal: Int,
    outstandingPayrollTotal: Int,
    onNavigate: (NavDestination) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SampleDataNoticeBanner(noticeText = strings.sampleDataNotice)
        }

        item {
            Column(modifier = Modifier.padding(top = 4.dp)) {
                Text(
                    text = "${strings.siteOverviewTitle} · ${activeSite.siteName}",
                    style = MaterialTheme.typography.titleLarge,
                    color = SlateInk
                )
                Text(
                    text = "${activeSite.siteCode} · ${activeSite.address} · ${activeSite.siteManager}",
                    style = MaterialTheme.typography.bodySmall,
                    color = SlateMuted
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SummaryMetricCard(
                    label = strings.totalWorkers,
                    value = totalWorkers.toString(),
                    modifier = Modifier.weight(1f)
                )
                SummaryMetricCard(
                    label = strings.presentToday,
                    value = presentToday.toString(),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SummaryMetricCard(
                    label = strings.absentToday,
                    value = absentToday.toString(),
                    modifier = Modifier.weight(1f)
                )
                SummaryMetricCard(
                    label = strings.todaysPayments,
                    value = "৳$todaysPaymentsTotal",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Clean separation: Earned Payroll, Actual Paid Payroll, General Site Expenses, Outstanding Payroll
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                SummaryMetricCard(
                    label = strings.monthlyExpenses,
                    value = "৳$earnedPayrollTotal",
                    supportingText = "${strings.paidPayrollCardLabel}: ৳$paidPayrollTotal",
                    modifier = Modifier.weight(1f)
                )
                SummaryMetricCard(
                    label = strings.outstandingPayrollCardLabel,
                    value = "৳$outstandingPayrollTotal",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            SummaryMetricCard(
                label = strings.generalExpensesCardLabel,
                value = "৳$generalExpensesTotal",
                supportingText = "${activeSite.siteName} · ${strings.totalGeneralExpensesLabel}",
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = strings.quickActionsTitle,
                style = MaterialTheme.typography.titleMedium,
                color = SlateInk
            )
        }

        item {
            val actions = listOf(
                strings.navSpreadsheet to NavDestination.SPREADSHEET,
                strings.navWorkers to NavDestination.WORKERS,
                strings.navAttendance to NavDestination.ATTENDANCE,
                strings.navPayments to NavDestination.PAYMENTS,
                strings.navExpenses to NavDestination.EXPENSES,
                strings.navSites to NavDestination.SITES,
                strings.navReports to NavDestination.REPORTS,
                strings.navSettings to NavDestination.SETTINGS
            )
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                actions.chunked(2).forEach { pair ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        pair.forEach { (label, destination) ->
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onNavigate(destination) },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                                border = BorderStroke(1.dp, SubtleBorderGrey)
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = EngineeringBlue,
                                    modifier = Modifier.padding(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
