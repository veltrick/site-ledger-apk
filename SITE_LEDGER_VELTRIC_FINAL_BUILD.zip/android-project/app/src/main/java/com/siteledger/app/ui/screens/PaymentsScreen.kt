package com.siteledger.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.siteledger.app.domain.model.AdvanceRecord
import com.siteledger.app.domain.model.AppLanguage
import com.siteledger.app.domain.model.DailyAttendanceRecord
import com.siteledger.app.domain.model.PaymentAllocation
import com.siteledger.app.domain.model.PaymentLedgerEntry
import com.siteledger.app.domain.model.PayrollPeriodRecord
import com.siteledger.app.domain.model.PayrollPeriodStatus
import com.siteledger.app.domain.model.UserRole
import com.siteledger.app.domain.model.Worker
import com.siteledger.app.domain.service.WageCalculator
import com.siteledger.app.ui.components.SampleDataNoticeBanner
import com.siteledger.app.ui.components.WorkerAvatar
import com.siteledger.app.ui.i18n.AppStrings
import com.siteledger.app.ui.theme.CrispWhite
import com.siteledger.app.ui.theme.EngineeringBlue
import com.siteledger.app.ui.theme.SlateInk
import com.siteledger.app.ui.theme.SlateMuted
import com.siteledger.app.ui.theme.StatusAmber
import com.siteledger.app.ui.theme.StatusGreen
import com.siteledger.app.ui.theme.StatusRed
import com.siteledger.app.ui.theme.SubtleBorderGrey
import java.util.UUID

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PaymentsScreen(
    strings: AppStrings,
    language: AppLanguage,
    activeRole: UserRole,
    workers: List<Worker>,
    attendance: List<DailyAttendanceRecord>,
    payments: List<PaymentLedgerEntry>,
    advances: List<AdvanceRecord>,
    allocations: List<PaymentAllocation>,
    payrollPeriods: List<PayrollPeriodRecord>,
    onRecordPayment: (
        workerId: String,
        paymentDateIso: String,
        applicablePeriod: String,
        paidAmount: Int,
        referenceNo: String,
        note: String,
        submissionToken: String
    ) -> Unit,
    onRecordAdvance: (
        workerId: String,
        advanceDateIso: String,
        amount: Int,
        referenceNo: String,
        note: String,
        submissionToken: String
    ) -> Unit,
    onAllocateAdvance: (
        advanceId: String,
        targetPeriod: String,
        amountToAllocate: Int,
        note: String
    ) -> Unit,
    onVoidPayment: (txId: String, reason: String) -> Unit
) {
    var showEntryDialog by remember { mutableStateOf(false) }
    var showAdvanceDialog by remember { mutableStateOf(false) }
    var allocateTarget by remember { mutableStateOf<AdvanceRecord?>(null) }
    var voidTarget by remember { mutableStateOf<PaymentLedgerEntry?>(null) }
    val workerLookup = remember(workers) { workers.associateBy { it.id } }
    val canEditPayments = activeRole != UserRole.MANAGER

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { SampleDataNoticeBanner(noticeText = strings.sampleDataNotice) }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(strings.paymentLedgerTitle, style = MaterialTheme.typography.titleLarge, color = SlateInk)
                if (canEditPayments) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { showAdvanceDialog = true }) { Text(strings.recordAdvanceBtn) }
                        Button(onClick = { showEntryDialog = true }) { Text(strings.recordPayment) }
                    }
                }
            }
        }

        items(workers, key = { it.id }) { worker ->
            val balances = WageCalculator.computeWorkerOverallBalances(worker.id, attendance, allocations)
            val unallocatedAdv = WageCalculator.computeUnallocatedAdvanceBalance(worker.id, advances, allocations)
            val name = if (language == AppLanguage.BENGALI) worker.fullNameBn else worker.fullNameEn
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                border = BorderStroke(1.dp, SubtleBorderGrey)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    WorkerAvatar(name = name, photoPath = worker.photoPath, size = 42.dp)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(name, style = MaterialTheme.typography.titleMedium, color = SlateInk)
                        Text("${worker.id} · ${strings.totalEarnedAmount}: ৳${balances.first}", style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                        Text("${strings.totalPaidAmount}: ৳${balances.second}", style = MaterialTheme.typography.bodySmall, color = StatusGreen)
                        if (unallocatedAdv > 0) {
                            Text("${strings.unallocatedAdvancesLabel}: ৳$unallocatedAdv", style = MaterialTheme.typography.labelSmall, color = StatusAmber)
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(strings.remainingBalance, style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                        Text("৳${balances.third}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = EngineeringBlue)
                    }
                }
            }
        }

        if (advances.isNotEmpty()) {
            item {
                Text(strings.unallocatedAdvancesLabel, style = MaterialTheme.typography.titleMedium, color = SlateInk)
            }
            items(advances, key = { it.id }) { adv ->
                val remaining = WageCalculator.computeAdvanceRemaining(adv, allocations)
                val worker = workerLookup[adv.workerId]
                val wName = when {
                    worker == null -> adv.workerId
                    language == AppLanguage.BENGALI -> worker.fullNameBn
                    else -> worker.fullNameEn
                }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CrispWhite),
                    border = BorderStroke(1.dp, SubtleBorderGrey)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("$wName (${adv.id})", style = MaterialTheme.typography.titleMedium, color = SlateInk)
                            Text("${adv.advanceDateIso} · ${adv.referenceNo} · ${adv.note}", style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                            Text("৳${adv.amount} (Remaining: ৳$remaining)", style = MaterialTheme.typography.bodySmall, color = StatusAmber)
                        }
                        if (remaining > 0 && canEditPayments) {
                            OutlinedButton(onClick = { allocateTarget = adv }) {
                                Text(strings.allocateAdvanceBtn)
                            }
                        }
                    }
                }
            }
        }

        item {
            Text(strings.transactionHistory, style = MaterialTheme.typography.titleMedium, color = SlateInk)
        }

        items(payments, key = { it.id }) { entry ->
            val worker = workerLookup[entry.workerId]
            val workerName = when {
                worker == null -> entry.workerId
                language == AppLanguage.BENGALI -> worker.fullNameBn
                else -> worker.fullNameEn
            }
            val periodLocked = payrollPeriods.find { it.periodIso == entry.applicablePeriod }?.status == PayrollPeriodStatus.FINALIZED

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                border = BorderStroke(1.dp, SubtleBorderGrey)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    WorkerAvatar(name = workerName, photoPath = worker?.photoPath, size = 38.dp)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(workerName, style = MaterialTheme.typography.titleMedium, color = SlateInk)
                        Text("${entry.id} · ${strings.paymentDateLabel}: ${entry.dateIso} · ${strings.applicablePeriodLabel}: ${entry.applicablePeriod}", style = MaterialTheme.typography.bodySmall, color = EngineeringBlue)
                        Text("${entry.referenceNo} · ${if (language == AppLanguage.BENGALI) entry.noteBn else entry.noteEn}", style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (entry.isVoided) strings.voidedLabel else "৳${entry.paidAmount}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (entry.isVoided) StatusRed else StatusGreen
                        )
                        if (!entry.isVoided && canEditPayments && !periodLocked) {
                            TextButton(onClick = { voidTarget = entry }) {
                                Text(strings.voidTransaction, color = StatusRed)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEntryDialog && workers.isNotEmpty()) {
        var selectedWorkerId by remember { mutableStateOf(workers.first().id) }
        var paymentDateIso by remember { mutableStateOf("2026-11-15") }
        var applicablePeriod by remember { mutableStateOf("2026-11") }
        val bal = WageCalculator.computeWorkerOverallBalances(selectedWorkerId, attendance, allocations).third
        var paidAmount by remember { mutableStateOf(bal.coerceAtLeast(0).toString()) }
        var refNo by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }
        val isPeriodLocked = payrollPeriods.find { it.periodIso == applicablePeriod }?.status == PayrollPeriodStatus.FINALIZED

        AlertDialog(
            onDismissRequest = { showEntryDialog = false },
            title = { Text(strings.recordPayment) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        workers.take(4).forEach { w ->
                            FilterChip(
                                selected = selectedWorkerId == w.id,
                                onClick = {
                                    selectedWorkerId = w.id
                                    val nextBal = WageCalculator.computeWorkerOverallBalances(w.id, attendance, allocations).third
                                    paidAmount = nextBal.coerceAtLeast(0).toString()
                                },
                                label = { Text(w.id) }
                            )
                        }
                    }
                    Text(strings.applicablePeriodLabel, style = MaterialTheme.typography.labelMedium, color = SlateMuted)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("2026-09", "2026-10", "2026-11").forEach { p ->
                            FilterChip(selected = applicablePeriod == p, onClick = { applicablePeriod = p }, label = { Text(p) })
                        }
                    }
                    if (isPeriodLocked) {
                        Text(strings.payrollLockedWarning, style = MaterialTheme.typography.bodySmall, color = StatusRed)
                    }
                    OutlinedTextField(value = paymentDateIso, onValueChange = { paymentDateIso = it }, label = { Text(strings.paymentDateLabel) }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { paidAmount = bal.coerceAtLeast(0).toString() }) { Text(strings.fullPaymentBtn) }
                        OutlinedButton(onClick = { paidAmount = (bal.coerceAtLeast(0) / 2).toString() }) { Text(strings.partialPaymentBtn) }
                    }
                    OutlinedTextField(value = paidAmount, onValueChange = { paidAmount = it.filter(Char::isDigit) }, label = { Text(strings.paymentAmountLabel) }, singleLine = true)
                    OutlinedTextField(value = refNo, onValueChange = { refNo = it }, label = { Text(strings.referenceNoLabel) }, singleLine = true)
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text(strings.paymentNoteLabel) }, singleLine = true)
                }
            },
            confirmButton = {
                Button(
                    enabled = !isPeriodLocked,
                    onClick = {
                        val amt = paidAmount.toIntOrNull() ?: 0
                        if (amt > 0) {
                            onRecordPayment(
                                selectedWorkerId,
                                paymentDateIso.ifBlank { "2026-11-15" },
                                applicablePeriod,
                                amt,
                                refNo.ifBlank { "CASH" },
                                note.ifBlank { "Site payment" },
                                UUID.randomUUID().toString()
                            )
                            showEntryDialog = false
                        }
                    }
                ) { Text(strings.saveEntry) }
            },
            dismissButton = {
                TextButton(onClick = { showEntryDialog = false }) { Text(strings.cancel) }
            }
        )
    }

    if (showAdvanceDialog && workers.isNotEmpty()) {
        var selectedWorkerId by remember { mutableStateOf(workers.first().id) }
        var advDateIso by remember { mutableStateOf("2026-11-15") }
        var amount by remember { mutableStateOf("") }
        var refNo by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAdvanceDialog = false },
            title = { Text(strings.recordAdvanceBtn) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        workers.take(4).forEach { w ->
                            FilterChip(selected = selectedWorkerId == w.id, onClick = { selectedWorkerId = w.id }, label = { Text(w.id) })
                        }
                    }
                    OutlinedTextField(value = advDateIso, onValueChange = { advDateIso = it }, label = { Text(strings.paymentDateLabel) }, singleLine = true)
                    OutlinedTextField(value = amount, onValueChange = { amount = it.filter(Char::isDigit) }, label = { Text(strings.paymentAmountLabel) }, singleLine = true)
                    OutlinedTextField(value = refNo, onValueChange = { refNo = it }, label = { Text(strings.referenceNoLabel) }, singleLine = true)
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text(strings.notesLabel) }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    val amt = amount.toIntOrNull() ?: 0
                    if (amt > 0) {
                        onRecordAdvance(selectedWorkerId, advDateIso.ifBlank { "2026-11-15" }, amt, refNo.ifBlank { "ADV" }, note.ifBlank { "Site advance" }, UUID.randomUUID().toString())
                        showAdvanceDialog = false
                    }
                }) { Text(strings.saveEntry) }
            },
            dismissButton = {
                TextButton(onClick = { showAdvanceDialog = false }) { Text(strings.cancel) }
            }
        )
    }

    allocateTarget?.let { adv ->
        val remaining = WageCalculator.computeAdvanceRemaining(adv, allocations)
        var targetPeriod by remember { mutableStateOf("2026-11") }
        var amount by remember { mutableStateOf(remaining.toString()) }
        var note by remember { mutableStateOf("Advance applied") }
        val isLocked = payrollPeriods.find { it.periodIso == targetPeriod }?.status == PayrollPeriodStatus.FINALIZED

        AlertDialog(
            onDismissRequest = { allocateTarget = null },
            title = { Text("${strings.allocateAdvanceBtn} · ${adv.id}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("2026-09", "2026-10", "2026-11").forEach { p ->
                            FilterChip(selected = targetPeriod == p, onClick = { targetPeriod = p }, label = { Text(p) })
                        }
                    }
                    if (isLocked) {
                        Text(strings.payrollLockedWarning, style = MaterialTheme.typography.bodySmall, color = StatusRed)
                    }
                    OutlinedTextField(value = amount, onValueChange = { amount = it.filter(Char::isDigit) }, label = { Text(strings.paymentAmountLabel) }, singleLine = true)
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text(strings.notesLabel) }, singleLine = true)
                }
            },
            confirmButton = {
                Button(
                    enabled = !isLocked,
                    onClick = {
                        val amt = (amount.toIntOrNull() ?: 0).coerceIn(0, remaining)
                        if (amt > 0) {
                            onAllocateAdvance(adv.id, targetPeriod, amt, note)
                            allocateTarget = null
                        }
                    }
                ) { Text(strings.confirmAction) }
            },
            dismissButton = {
                TextButton(onClick = { allocateTarget = null }) { Text(strings.cancel) }
            }
        )
    }

    voidTarget?.let { tx ->
        AlertDialog(
            onDismissRequest = { voidTarget = null },
            title = { Text(strings.voidTransaction) },
            text = { Text(strings.confirmVoidPaymentMsg) },
            confirmButton = {
                Button(onClick = {
                    onVoidPayment(tx.id, "Voided from ledger")
                    voidTarget = null
                }) { Text(strings.confirmAction) }
            },
            dismissButton = {
                TextButton(onClick = { voidTarget = null }) { Text(strings.cancel) }
            }
        )
    }
}
