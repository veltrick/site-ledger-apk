package com.siteledger.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.siteledger.app.data.export.PayrollExporter
import com.siteledger.app.domain.model.AppLanguage
import com.siteledger.app.domain.model.DailyAttendanceRecord
import com.siteledger.app.domain.model.PaymentAllocation
import com.siteledger.app.domain.model.PayrollPeriodRecord
import com.siteledger.app.domain.model.PayrollPeriodStatus
import com.siteledger.app.domain.model.Site
import com.siteledger.app.domain.model.UserRole
import com.siteledger.app.domain.model.WorkCategory
import com.siteledger.app.domain.model.Worker
import com.siteledger.app.domain.service.WageCalculator
import com.siteledger.app.ui.components.WorkerAvatar
import com.siteledger.app.ui.i18n.AppStrings
import com.siteledger.app.ui.theme.CanvasGrey
import com.siteledger.app.ui.theme.CrispWhite
import com.siteledger.app.ui.theme.EngineeringBlue
import com.siteledger.app.ui.theme.SlateInk
import com.siteledger.app.ui.theme.SlateMuted
import com.siteledger.app.ui.theme.StatusAmber
import com.siteledger.app.ui.theme.StatusGreen
import com.siteledger.app.ui.theme.StatusRed
import com.siteledger.app.ui.theme.SubtleBorderGrey

enum class SpreadsheetSort { NAME, ID, EARNINGS, PAID, OUTSTANDING }

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PayrollSpreadsheetScreen(
    strings: AppStrings,
    language: AppLanguage,
    activeRole: UserRole,
    activeSite: Site,
    sites: List<Site>,
    workers: List<Worker>,
    attendance: List<DailyAttendanceRecord>,
    allocations: List<PaymentAllocation>,
    payrollPeriods: List<PayrollPeriodRecord>,
    onWorkerClick: (String) -> Unit,
    onFinalizePeriod: (String, String) -> Unit,
    onReopenPeriod: (String, String) -> Unit
) {
    val context = LocalContext.current
    var selectedYear by remember { mutableIntStateOf(2026) }
    var selectedMonth by remember { mutableIntStateOf(11) }
    var allSitesMode by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var categoryFilter by remember { mutableStateOf<WorkCategory?>(null) }
    var sortOption by remember { mutableStateOf(SpreadsheetSort.NAME) }
    var showLockDialog by remember { mutableStateOf(false) }
    var exportNotice by remember { mutableStateOf<String?>(null) }

    val periodIso = WageCalculator.formatPeriodIso(selectedYear, selectedMonth)
    val periodStatus = payrollPeriods.find { it.periodIso == periodIso && it.siteId == activeSite.id }?.status ?: PayrollPeriodStatus.OPEN
    val hScroll = rememberScrollState()
    val allowedSiteIds = remember(sites) { sites.map { it.id }.toSet() }
    val headerLabel = if (allSitesMode) strings.allSitesToggleLabel else activeSite.siteName

    val rows = remember(
        workers,
        sites,
        activeSite.id,
        allSitesMode,
        selectedYear,
        selectedMonth,
        searchQuery,
        categoryFilter,
        sortOption,
        attendance,
        allocations,
        payrollPeriods,
        language,
        allowedSiteIds
    ) {
        val q = searchQuery.trim()
        val summaries = WageCalculator.computeSpreadsheetRows(
            year = selectedYear,
            month = selectedMonth,
            selectedSiteId = activeSite.id,
            allSitesMode = allSitesMode,
            sites = sites,
            workers = workers,
            allAttendance = attendance,
            allAllocations = allocations,
            periodRecords = payrollPeriods,
            allowedSiteIds = allowedSiteIds
        ).filter { s ->
            (categoryFilter == null || s.worker.category == categoryFilter) &&
                (q.isBlank() || s.worker.fullNameEn.contains(q, true) || s.worker.fullNameBn.contains(q, true) || s.worker.localWorkerCode.contains(q, true) || s.siteName.contains(q, true))
        }

        when (sortOption) {
            SpreadsheetSort.NAME -> summaries.sortedBy { if (language == AppLanguage.BENGALI) it.worker.fullNameBn else it.worker.fullNameEn }
            SpreadsheetSort.ID -> summaries.sortedBy { it.worker.localWorkerCode }
            SpreadsheetSort.EARNINGS -> summaries.sortedByDescending { it.totalEarnedAmount }
            SpreadsheetSort.PAID -> summaries.sortedByDescending { it.totalPaidAmount }
            SpreadsheetSort.OUTSTANDING -> summaries.sortedByDescending { it.outstandingBalance }
        }
    }

    val totals = remember(rows) { WageCalculator.computeSpreadsheetTotals(rows) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(strings.payrollSpreadsheetTitle, style = MaterialTheme.typography.titleLarge, color = SlateInk)
                    Text(
                        text = "$headerLabel · $periodIso · ${if (periodStatus == PayrollPeriodStatus.FINALIZED) strings.payrollFinalizedBadge else strings.payrollOpenBadge}",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (periodStatus == PayrollPeriodStatus.FINALIZED) StatusAmber else StatusGreen
                    )
                }
                if (activeRole == UserRole.ADMIN && !allSitesMode) {
                    OutlinedButton(onClick = { showLockDialog = true }) {
                        Icon(
                            imageVector = if (periodStatus == PayrollPeriodStatus.FINALIZED) Icons.Outlined.LockOpen else Icons.Outlined.Lock,
                            contentDescription = null
                        )
                        Text(
                            text = if (periodStatus == PayrollPeriodStatus.FINALIZED) strings.reopenPayrollBtn else strings.finalizePayrollBtn,
                            modifier = Modifier.padding(start = 6.dp)
                        )
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = !allSitesMode,
                    onClick = { allSitesMode = false },
                    label = { Text("${strings.activeSiteToggleLabel}: ${activeSite.siteCode}") }
                )
                FilterChip(
                    selected = allSitesMode,
                    onClick = { allSitesMode = true },
                    label = { Text("${strings.allSitesToggleLabel} (${sites.size})") }
                )
            }
        }

        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(2025, 2026).forEach { y ->
                    FilterChip(selected = selectedYear == y, onClick = { selectedYear = y }, label = { Text(y.toString()) })
                }
                listOf(9, 10, 11, 12).forEach { m ->
                    FilterChip(selected = selectedMonth == m, onClick = { selectedMonth = m }, label = { Text("%02d".format(m)) })
                }
            }
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text(strings.searchWorkersPlaceholder) },
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                FilterChip(selected = categoryFilter == null, onClick = { categoryFilter = null }, label = { Text(strings.allFilter) })
                WorkCategory.entries.forEach { cat ->
                    FilterChip(
                        selected = categoryFilter == cat,
                        onClick = { categoryFilter = cat },
                        label = { Text(if (language == AppLanguage.BENGALI) cat.labelBn else cat.labelEn) }
                    )
                }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(
                    SpreadsheetSort.NAME to strings.sortByName,
                    SpreadsheetSort.ID to strings.sortById,
                    SpreadsheetSort.EARNINGS to strings.sortByEarnings,
                    SpreadsheetSort.PAID to strings.sortByPaid,
                    SpreadsheetSort.OUTSTANDING to strings.sortByOutstanding
                ).forEach { (s, label) ->
                    FilterChip(selected = sortOption == s, onClick = { sortOption = s }, label = { Text(label) })
                }
            }
        }

        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val file = PayrollExporter.exportSpreadsheetExcel(context, language, periodIso, rows, totals, headerLabel, includeSiteColumn = true)
                    exportNotice = "${strings.exportSuccessNotice} ${file.name}"
                }) { Text(strings.exportExcelBtn) }
                OutlinedButton(onClick = {
                    val file = PayrollExporter.exportAllWorkersPayrollPdf(context, language, periodIso, rows, totals, headerLabel, includeSiteColumn = true)
                    exportNotice = "${strings.exportSuccessNotice} ${file.name}"
                }) { Text(strings.exportAllPdfBtn) }
                OutlinedButton(onClick = {
                    PayrollExporter.printMonthlyAttendanceReport(context, language, periodIso, rows, headerLabel, includeSiteColumn = true)
                }) { Text(strings.printAttendanceBtn) }
            }
            exportNotice?.let { msg ->
                Text(msg, style = MaterialTheme.typography.bodySmall, color = StatusGreen, modifier = Modifier.padding(top = 4.dp))
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                border = BorderStroke(1.dp, SubtleBorderGrey)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFEFF6FF))
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(modifier = Modifier.width(178.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("ID", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.width(56.dp))
                        Text(strings.fullNameLabel, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.horizontalScroll(hScroll).padding(end = 8.dp)) {
                        if (allSitesMode) HeaderCell(strings.siteColumnLabel, 110)
                        HeaderCell(strings.categoryLabel, 90)
                        HeaderCell("H", 34)
                        HeaderCell("F", 34)
                        HeaderCell("1.5", 36)
                        HeaderCell("D", 34)
                        HeaderCell("2.5", 36)
                        HeaderCell("T", 34)
                        HeaderCell("A", 34)
                        HeaderCell("L", 34)
                        HeaderCell(strings.dutyUnitsLabel, 64)
                        HeaderCell(strings.totalEarnedAmount, 82)
                        HeaderCell(strings.totalPaidAmount, 82)
                        HeaderCell(strings.remainingBalance, 88)
                    }
                }
            }
        }

        items(rows, key = { "${it.siteId}_${it.worker.id}" }) { row ->
            val name = if (language == AppLanguage.BENGALI) row.worker.fullNameBn else row.worker.fullNameEn
            val cat = if (language == AppLanguage.BENGALI) row.worker.category.labelBn else row.worker.category.labelEn
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CrispWhite)
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier
                            .width(178.dp)
                            .clickable { onWorkerClick(row.worker.id) }
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        WorkerAvatar(name = name, photoPath = row.worker.photoPath, size = 28.dp)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(row.worker.localWorkerCode, style = MaterialTheme.typography.labelSmall, color = SlateMuted, maxLines = 1)
                            Text(name, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = EngineeringBlue, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Row(modifier = Modifier.horizontalScroll(hScroll).padding(end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (allSitesMode) DataCell(row.siteName.ifBlank { row.siteId }, 110, EngineeringBlue)
                        DataCell(cat, 90, SlateMuted)
                        DataCell(row.halfDutyCount.toString(), 34, StatusAmber)
                        DataCell(row.fullDutyCount.toString(), 34, StatusGreen)
                        DataCell(row.oneAndHalfDutyCount.toString(), 36, EngineeringBlue)
                        DataCell(row.doubleDutyCount.toString(), 34, EngineeringBlue)
                        DataCell(row.twoAndHalfDutyCount.toString(), 36, EngineeringBlue)
                        DataCell(row.tripleDutyCount.toString(), 34, EngineeringBlue)
                        DataCell(row.absentCount.toString(), 34, StatusRed)
                        DataCell(row.leaveCount.toString(), 34, SlateMuted)
                        DataCell(String.format("%.1f", row.totalDutyUnits), 64, SlateInk)
                        DataCell("৳${row.totalEarnedAmount}", 82, SlateInk)
                        DataCell("৳${row.totalPaidAmount}", 82, StatusGreen)
                        DataCell("৳${row.outstandingBalance}", 88, if (row.outstandingBalance > 0) EngineeringBlue else SlateInk)
                    }
                }
                HorizontalDivider(color = CanvasGrey)
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9)),
                border = BorderStroke(1.dp, EngineeringBlue)
            ) {
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.width(178.dp).padding(horizontal = 8.dp)) {
                        Text("${strings.totalsRowLabel} (${totals.totalWorkers})", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = EngineeringBlue)
                    }
                    Row(modifier = Modifier.horizontalScroll(hScroll).padding(end = 8.dp)) {
                        if (allSitesMode) DataCell("", 110, SlateInk)
                        DataCell("", 90, SlateInk)
                        DataCell("", 34, SlateInk)
                        DataCell("", 34, SlateInk)
                        DataCell("", 36, SlateInk)
                        DataCell("", 34, SlateInk)
                        DataCell("", 36, SlateInk)
                        DataCell("", 34, SlateInk)
                        DataCell("", 34, SlateInk)
                        DataCell("", 34, SlateInk)
                        DataCell(String.format("%.1f", totals.totalDutyUnits), 64, EngineeringBlue)
                        DataCell("৳${totals.totalEarnedSalary}", 82, SlateInk)
                        DataCell("৳${totals.totalPaidSalary}", 82, StatusGreen)
                        DataCell("৳${totals.totalOutstandingSalary}", 88, EngineeringBlue)
                    }
                }
            }
        }
    }

    if (showLockDialog) {
        val isFinalized = periodStatus == PayrollPeriodStatus.FINALIZED
        AlertDialog(
            onDismissRequest = { showLockDialog = false },
            title = { Text(if (isFinalized) strings.reopenPayrollBtn else strings.finalizePayrollBtn) },
            text = { Text(if (isFinalized) strings.confirmReopenMsg else strings.confirmFinalizeMsg) },
            confirmButton = {
                Button(onClick = {
                    if (isFinalized) onReopenPeriod(periodIso, "Reopened from Master Spreadsheet")
                    else onFinalizePeriod(periodIso, "Finalized from Master Spreadsheet")
                    showLockDialog = false
                }) { Text(strings.confirmAction) }
            },
            dismissButton = {
                TextButton(onClick = { showLockDialog = false }) { Text(strings.cancel) }
            }
        )
    }
}

@Composable
private fun HeaderCell(text: String, widthDp: Int) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = SlateInk,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.width(widthDp.dp).padding(horizontal = 4.dp)
    )
}

@Composable
private fun DataCell(text: String, widthDp: Int, color: Color) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        color = color,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.width(widthDp.dp).padding(horizontal = 4.dp)
    )
}
