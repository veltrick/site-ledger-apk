package com.siteledger.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.siteledger.app.data.export.PayrollExporter
import com.siteledger.app.domain.model.AppLanguage
import com.siteledger.app.domain.model.DailyAttendanceRecord
import com.siteledger.app.domain.model.DutyType
import com.siteledger.app.domain.model.PaymentAllocation
import com.siteledger.app.domain.model.PayrollPeriodRecord
import com.siteledger.app.domain.model.Site
import com.siteledger.app.domain.model.SiteExpense
import com.siteledger.app.domain.model.WorkCategory
import com.siteledger.app.domain.model.Worker
import com.siteledger.app.domain.service.WageCalculator
import com.siteledger.app.ui.components.SampleDataNoticeBanner
import com.siteledger.app.ui.components.SummaryMetricCard
import com.siteledger.app.ui.components.WorkerAvatar
import com.siteledger.app.ui.i18n.AppStrings
import com.siteledger.app.ui.theme.CrispWhite
import com.siteledger.app.ui.theme.EngineeringBlue
import com.siteledger.app.ui.theme.SlateInk
import com.siteledger.app.ui.theme.SlateMuted
import com.siteledger.app.ui.theme.StatusGreen
import com.siteledger.app.ui.theme.SubtleBorderGrey
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReportsScreen(
    strings: AppStrings,
    language: AppLanguage,
    activeSite: Site,
    sites: List<Site>,
    workers: List<Worker>,
    attendance: List<DailyAttendanceRecord>,
    allocations: List<PaymentAllocation>,
    payrollPeriods: List<PayrollPeriodRecord>,
    siteExpenses: List<SiteExpense>,
    allWorkers: List<Worker>,
    allAttendance: List<DailyAttendanceRecord>,
    allAllocations: List<PaymentAllocation>,
    allExpenses: List<SiteExpense>
) {
    val context = LocalContext.current
    var selectedYear by remember { mutableIntStateOf(2026) }
    var selectedMonth by remember { mutableIntStateOf(11) }
    var selectedCategory by remember { mutableStateOf<WorkCategory?>(null) }
    var selectedWorkerId by remember { mutableStateOf<String?>(null) }
    var exportNotice by remember { mutableStateOf<String?>(null) }

    val periodIso = WageCalculator.formatPeriodIso(selectedYear, selectedMonth)
    val monthPrefix = "$periodIso-"
    val filteredWorkers = remember(workers, selectedCategory, selectedWorkerId) {
        workers.filter { w ->
            (selectedCategory == null || w.category == selectedCategory) &&
                (selectedWorkerId == null || w.id == selectedWorkerId)
        }
    }

    val filteredWorkerIds = remember(filteredWorkers) { filteredWorkers.map { it.id }.toSet() }
    val todayAttendance = remember(attendance, filteredWorkerIds) {
        attendance.filter { it.dateIso == "2026-11-15" && it.workerId in filteredWorkerIds }
    }

    val sitesById = remember(sites) { sites.associateBy { it.id } }
    val workerSummaries = remember(filteredWorkers, selectedYear, selectedMonth, attendance, allocations, payrollPeriods, activeSite.id, sitesById) {
        filteredWorkers.map { w ->
            WageCalculator.computeWorkerMonthlySummary(
                worker = w,
                year = selectedYear,
                month = selectedMonth,
                allAttendance = attendance,
                allAllocations = allocations,
                periodRecords = payrollPeriods,
                siteIdFilter = activeSite.id,
                sitesById = sitesById
            )
        }
    }

    val totals = remember(workerSummaries) { WageCalculator.computeSpreadsheetTotals(workerSummaries) }
    val dailyDutyUnits = WageCalculator.sumDutyUnits(todayAttendance)
    val monthlyDutyUnits = totals.totalDutyUnits
    val monthlySiteExpenses = remember(siteExpenses, monthPrefix) {
        siteExpenses.filter { !it.isVoided && it.expenseDateIso.startsWith(monthPrefix) }.sumOf { it.amount }
    }

    val allSitesOverview = remember(sites, allWorkers, allAttendance, allAllocations, allExpenses, periodIso) {
        WageCalculator.computeAllSitesOverview(sites, allWorkers, allAttendance, allAllocations, allExpenses, periodIsoFilter = periodIso)
    }

    val yearlyStats = remember(filteredWorkers, selectedYear, attendance, allocations, activeSite.id) {
        var yearlyEarned = 0
        var yearlyPaid = 0
        var yearlyUnitsHundredths = 0
        (1..12).forEach { m ->
            filteredWorkers.forEach { w ->
                val s = WageCalculator.computeWorkerMonthlySummary(w, selectedYear, m, attendance, allocations, siteIdFilter = activeSite.id)
                yearlyEarned += s.totalEarnedAmount
                yearlyPaid += s.totalPaidAmount
                yearlyUnitsHundredths += WageCalculator.toMultiplierHundredths(s.totalDutyUnits)
            }
        }
        Triple(yearlyUnitsHundredths / 100.0, yearlyEarned, yearlyPaid)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { SampleDataNoticeBanner(noticeText = strings.sampleDataNotice) }

        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(2025, 2026).forEach { y ->
                    FilterChip(selected = selectedYear == y, onClick = { selectedYear = y }, label = { Text(y.toString()) })
                }
                listOf(9, 10, 11, 12).forEach { m ->
                    FilterChip(selected = selectedMonth == m, onClick = { selectedMonth = m }, label = { Text("%02d".format(m)) })
                }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = selectedCategory == null, onClick = { selectedCategory = null }, label = { Text(strings.allFilter) })
                WorkCategory.entries.forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(if (language == AppLanguage.BENGALI) cat.labelBn else cat.labelEn) }
                    )
                }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = selectedWorkerId == null, onClick = { selectedWorkerId = null }, label = { Text("${strings.navWorkers}: ${strings.allFilter}") })
                workers.take(4).forEach { w ->
                    FilterChip(selected = selectedWorkerId == w.id, onClick = { selectedWorkerId = w.id }, label = { Text(w.localWorkerCode) })
                }
            }
        }

        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val file = PayrollExporter.exportSpreadsheetExcel(context, language, periodIso, workerSummaries, totals, activeSite.siteName, includeSiteColumn = true)
                    exportNotice = "${strings.exportSuccessNotice} ${file.name}"
                }) { Text(strings.exportExcelBtn) }
                OutlinedButton(onClick = {
                    val file = PayrollExporter.exportAllWorkersPayrollPdf(context, language, periodIso, workerSummaries, totals, activeSite.siteName, includeSiteColumn = true)
                    exportNotice = "${strings.exportSuccessNotice} ${file.name}"
                }) { Text(strings.exportAllPdfBtn) }
                OutlinedButton(onClick = {
                    PayrollExporter.printMonthlyAttendanceReport(context, language, periodIso, workerSummaries, activeSite.siteName, includeSiteColumn = true)
                }) { Text(strings.printAttendanceBtn) }
            }
            exportNotice?.let { msg ->
                Text(msg, style = MaterialTheme.typography.bodySmall, color = StatusGreen, modifier = Modifier.padding(top = 4.dp))
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryMetricCard(strings.dailySiteAttendance, "${todayAttendance.count { it.dutyType != DutyType.ABSENT && it.dutyType != DutyType.LEAVE }}", modifier = Modifier.weight(1f))
                SummaryMetricCard(strings.dailyTotalDutyUnits, String.format(Locale.US, "%.1f", dailyDutyUnits), modifier = Modifier.weight(1f))
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                border = BorderStroke(1.dp, SubtleBorderGrey)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${strings.monthlySiteSummary} · ${activeSite.siteName} ($periodIso)", style = MaterialTheme.typography.titleMedium, color = SlateInk)
                    ReportLine(strings.totalDutyUnits, String.format(Locale.US, "%.1f", monthlyDutyUnits))
                    ReportLine(strings.monthlyTotalEarned, "৳${totals.totalEarnedSalary}")
                    ReportLine(strings.monthlyTotalPaid, "৳${totals.totalPaidSalary}")
                    ReportLine(strings.monthlyOutstanding, "৳${totals.totalOutstandingSalary}")
                    ReportLine(strings.generalExpensesCardLabel, "৳$monthlySiteExpenses")
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                border = BorderStroke(1.dp, SubtleBorderGrey)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${strings.allSitesToggleLabel} ($periodIso)", style = MaterialTheme.typography.titleMedium, color = EngineeringBlue)
                    ReportLine(strings.monthlyTotalEarned, "৳${allSitesOverview.combinedEarnedPayroll}")
                    ReportLine(strings.monthlyTotalPaid, "৳${allSitesOverview.combinedPaidPayroll}")
                    ReportLine(strings.monthlyOutstanding, "৳${allSitesOverview.combinedOutstandingPayroll}")
                    ReportLine(strings.generalExpensesCardLabel, "৳${allSitesOverview.combinedGeneralExpenses}")
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                border = BorderStroke(1.dp, SubtleBorderGrey)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${strings.yearlyPayrollSummary} ($selectedYear)", style = MaterialTheme.typography.titleMedium, color = EngineeringBlue)
                    ReportLine(strings.totalDutyUnits, String.format(Locale.US, "%.1f", yearlyStats.first))
                    ReportLine(strings.totalEarnedAmount, "৳${yearlyStats.second}")
                    ReportLine(strings.totalPaidAmount, "৳${yearlyStats.third}")
                    ReportLine(strings.remainingBalance, "৳${yearlyStats.second - yearlyStats.third}")
                }
            }
        }

        item {
            Text(strings.workerWiseReportTitle, style = MaterialTheme.typography.titleMedium, color = SlateInk)
        }

        items(workerSummaries, key = { it.worker.id }) { s ->
            val name = if (language == AppLanguage.BENGALI) s.worker.fullNameBn else s.worker.fullNameEn
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                border = BorderStroke(1.dp, SubtleBorderGrey)
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            WorkerAvatar(name = name, photoPath = s.worker.photoPath, size = 38.dp)
                            Column {
                                Text(name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = SlateInk)
                                Text("${s.worker.localWorkerCode} · ${String.format(Locale.US, "%.1f", s.totalDutyUnits)} units", style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                            }
                        }
                        Text("৳${s.outstandingBalance}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = EngineeringBlue)
                    }
                    Text(
                        text = "H:${s.halfDutyCount} F:${s.fullDutyCount} 1.5:${s.oneAndHalfDutyCount} D:${s.doubleDutyCount} 2.5:${s.twoAndHalfDutyCount} T:${s.tripleDutyCount} A:${s.absentCount} L:${s.leaveCount} · ${strings.totalEarnedAmount}: ৳${s.totalEarnedAmount} · ${strings.totalPaidAmount}: ৳${s.totalPaidAmount}",
                        style = MaterialTheme.typography.bodySmall,
                        color = StatusGreen
                    )
                }
            }
        }
    }
}

@Composable
private fun ReportLine(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = SlateMuted)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = SlateInk)
    }
    HorizontalDivider(color = SubtleBorderGrey)
}
