package com.siteledger.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.siteledger.app.domain.model.AppLanguage
import com.siteledger.app.domain.model.DailyAttendanceRecord
import com.siteledger.app.domain.model.PaymentAllocation
import com.siteledger.app.domain.model.Site
import com.siteledger.app.domain.model.SiteExpense
import com.siteledger.app.domain.model.SiteStatus
import com.siteledger.app.domain.model.UserRole
import com.siteledger.app.domain.model.UserSiteAccount
import com.siteledger.app.domain.model.Worker
import com.siteledger.app.domain.service.WageCalculator
import com.siteledger.app.ui.components.SummaryMetricCard
import com.siteledger.app.ui.i18n.AppStrings
import com.siteledger.app.ui.theme.CrispWhite
import com.siteledger.app.ui.theme.EngineeringBlue
import com.siteledger.app.ui.theme.SlateInk
import com.siteledger.app.ui.theme.SlateMuted
import com.siteledger.app.ui.theme.StatusAmber
import com.siteledger.app.ui.theme.StatusGreen
import com.siteledger.app.ui.theme.SubtleBorderGrey
import java.util.UUID

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SitesManagementScreen(
    strings: AppStrings,
    language: AppLanguage,
    activeRole: UserRole,
    sites: List<Site>,
    workers: List<Worker>,
    attendance: List<DailyAttendanceRecord>,
    allocations: List<PaymentAllocation>,
    expenses: List<SiteExpense>,
    userSiteAccounts: List<UserSiteAccount>,
    onSelectSite: (String) -> Unit,
    onSaveSite: (Site) -> Unit,
    onUpdateSiteStatus: (String, SiteStatus) -> Unit,
    onUpdateRoleSiteAccess: (UserRole, List<String>) -> Unit
) {
    var editingSite by remember { mutableStateOf<Site?>(null) }
    var showAddSiteDialog by remember { mutableStateOf(false) }

    val overview = remember(sites, workers, attendance, allocations, expenses) {
        WageCalculator.computeAllSitesOverview(sites, workers, attendance, allocations, expenses)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(strings.sitesOverviewTitle, style = MaterialTheme.typography.titleLarge, color = SlateInk)
                if (activeRole == UserRole.ADMIN) {
                    Button(onClick = { showAddSiteDialog = true }) {
                        Icon(Icons.Outlined.Add, contentDescription = null)
                        Text(" ${strings.addSiteBtn}")
                    }
                }
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryMetricCard(strings.monthlyExpenses, "৳${overview.combinedEarnedPayroll}", modifier = Modifier.weight(1f))
                SummaryMetricCard(strings.paidPayrollCardLabel, "৳${overview.combinedPaidPayroll}", modifier = Modifier.weight(1f))
            }
            Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryMetricCard(strings.generalExpensesCardLabel, "৳${overview.combinedGeneralExpenses}", modifier = Modifier.weight(1f))
                SummaryMetricCard(strings.outstandingPayrollCardLabel, "৳${overview.combinedOutstandingPayroll}", modifier = Modifier.weight(1f))
            }
        }

        items(overview.perSiteSummaries, key = { it.site.id }) { summary ->
            val site = summary.site
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectSite(site.id) },
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                border = BorderStroke(1.dp, SubtleBorderGrey)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${site.siteCode} — ${site.siteName}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = EngineeringBlue)
                            Text("${site.address} · ${site.siteManager}", style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                        }
                        if (activeRole == UserRole.ADMIN) {
                            IconButton(onClick = { editingSite = site }) {
                                Icon(Icons.Outlined.Edit, contentDescription = strings.editSiteBtn, tint = SlateMuted)
                            }
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${strings.navWorkers}: ${summary.activeWorkersCount}/${summary.totalWorkersCount}", style = MaterialTheme.typography.bodySmall, color = SlateInk)
                        Text(if (language == AppLanguage.BENGALI) site.status.labelBn else site.status.labelEn, style = MaterialTheme.typography.labelMedium, color = StatusGreen)
                    }
                    HorizontalDivider(color = SubtleBorderGrey)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Earned: ৳${summary.totalEarnedPayroll}", style = MaterialTheme.typography.bodySmall, color = SlateInk)
                        Text("Paid: ৳${summary.totalPaidPayroll}", style = MaterialTheme.typography.bodySmall, color = StatusGreen)
                        Text("Exp: ৳${summary.totalGeneralExpenses}", style = MaterialTheme.typography.bodySmall, color = StatusAmber)
                    }
                    Text("${strings.outstandingPayrollCardLabel}: ৳${summary.totalOutstandingPayroll}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = EngineeringBlue)

                    if (activeRole == UserRole.ADMIN && site.status == SiteStatus.ACTIVE && sites.size > 1) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { onUpdateSiteStatus(site.id, SiteStatus.ARCHIVED) }) {
                                Text(strings.archiveSiteBtn)
                            }
                        }
                    }
                }
            }
        }

        if (activeRole == UserRole.ADMIN) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CrispWhite),
                    border = BorderStroke(1.dp, SubtleBorderGrey)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(strings.sitePermissionsTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = SlateInk)
                        userSiteAccounts.filter { it.role != UserRole.ADMIN }.forEach { account ->
                            Text(if (language == AppLanguage.BENGALI) account.role.labelBn else account.role.labelEn, style = MaterialTheme.typography.labelMedium, color = EngineeringBlue)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                sites.forEach { s ->
                                    val assigned = s.id in account.assignedSiteIds
                                    FilterChip(
                                        selected = assigned,
                                        onClick = {
                                            val updated = if (assigned) {
                                                account.assignedSiteIds - s.id
                                            } else {
                                                account.assignedSiteIds + s.id
                                            }
                                            onUpdateRoleSiteAccess(account.role, updated)
                                        },
                                        label = { Text(s.siteCode) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddSiteDialog || editingSite != null) {
        val target = editingSite
        var siteName by remember { mutableStateOf(target?.siteName ?: "") }
        var siteCode by remember { mutableStateOf(target?.siteCode ?: "SITE-${sites.size + 1}") }
        var address by remember { mutableStateOf(target?.address ?: "") }
        var clientName by remember { mutableStateOf(target?.clientName ?: "") }
        var manager by remember { mutableStateOf(target?.siteManager ?: "") }
        var status by remember { mutableStateOf(target?.status ?: SiteStatus.ACTIVE) }

        AlertDialog(
            onDismissRequest = {
                showAddSiteDialog = false
                editingSite = null
            },
            title = { Text(if (target == null) strings.addSiteBtn else strings.editSiteBtn) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = siteName, onValueChange = { siteName = it }, label = { Text(strings.siteNameLabel) }, singleLine = true)
                    OutlinedTextField(value = siteCode, onValueChange = { siteCode = it }, label = { Text(strings.siteCodeLabel) }, singleLine = true)
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text(strings.siteAddressLabel) }, singleLine = true)
                    OutlinedTextField(value = clientName, onValueChange = { clientName = it }, label = { Text(strings.clientNameLabel) }, singleLine = true)
                    OutlinedTextField(value = manager, onValueChange = { manager = it }, label = { Text(strings.siteManagerLabel) }, singleLine = true)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SiteStatus.entries.forEach { st ->
                            FilterChip(
                                selected = status == st,
                                onClick = { status = st },
                                label = { Text(if (language == AppLanguage.BENGALI) st.labelBn else st.labelEn) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (siteName.isNotBlank() && siteCode.isNotBlank()) {
                        onSaveSite(
                            Site(
                                id = target?.id ?: "SITE-${UUID.randomUUID().toString().take(8).uppercase()}",
                                siteName = siteName.trim(),
                                siteCode = siteCode.trim().uppercase(),
                                description = target?.description ?: "",
                                address = address.trim(),
                                clientName = clientName.trim(),
                                siteManager = manager.trim(),
                                startDateIso = target?.startDateIso ?: "2026-11-15",
                                expectedCompletionDateIso = target?.expectedCompletionDateIso,
                                status = status,
                                notes = target?.notes ?: ""
                            )
                        )
                        showAddSiteDialog = false
                        editingSite = null
                    }
                }) { Text(strings.saveChanges) }
            },
            dismissButton = {
                TextButton(onClick = {
                    showAddSiteDialog = false
                    editingSite = null
                }) { Text(strings.cancel) }
            }
        )
    }
}
