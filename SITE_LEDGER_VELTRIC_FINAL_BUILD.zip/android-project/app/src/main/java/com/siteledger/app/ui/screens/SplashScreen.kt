package com.siteledger.app.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.siteledger.app.R
import kotlinx.coroutines.delay

/**
 * Full-screen startup Splash Screen displaying the official VELTRIC PNG logo
 * centered on a dark navy-black background without altering the original asset.
 */
@Composable
fun VeltricSplashScreen(
    onSplashComplete: () -> Unit
) {
    val currentOnSplashComplete by rememberUpdatedState(onSplashComplete)
    var visible by remember { mutableStateOf(false) }
    var exiting by remember { mutableStateOf(false) }

    val contentAlpha by animateFloatAsState(
        targetValue = if (visible && !exiting) 1f else 0f,
        animationSpec = tween(
            durationMillis = if (exiting) 320 else 500,
            easing = FastOutSlowInEasing
        ),
        label = "veltricSplashAlpha"
    )

    val logoScale by animateFloatAsState(
        targetValue = if (visible) 1f else 0.94f,
        animationSpec = tween(
            durationMillis = 550,
            easing = FastOutSlowInEasing
        ),
        label = "veltricSplashScale"
    )

    val glowTransition = rememberInfiniteTransition(label = "veltricGlowTransition")
    val glowAlpha by glowTransition.animateFloat(
        initialValue = 0.16f,
        targetValue = 0.34f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "veltricGlowAlpha"
    )
    val glowScale by glowTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.07f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "veltricGlowScale"
    )

    LaunchedEffect(Unit) {
        visible = true
        delay(1750L)
        exiting = true
        delay(320L)
        currentOnSplashComplete()
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF071329),
                        Color(0xFF030814),
                        Color(0xFF010308)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        val logoSize = (minOf(maxWidth, maxHeight) * 0.56f).coerceAtMost(280.dp)

        Box(contentAlignment = Alignment.Center) {
            // Subtle ambient glow strictly behind the unmodified PNG logo
            Canvas(
                modifier = Modifier
                    .size(logoSize * 1.48f)
                    .graphicsLayer {
                        alpha = contentAlpha * glowAlpha
                        scaleX = glowScale
                        scaleY = glowScale
                    }
            ) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF00D4FF),
                            Color(0x660066FF),
                            Color.Transparent
                        ),
                        center = center,
                        radius = size.minDimension / 2f
                    )
                )
            }

            // Exact official VELTRIC PNG logo (uncropped, untinted, aspect-locked)
            Image(
                painter = painterResource(id = R.drawable.veltric_logo),
                contentDescription = "VELTRIC",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(logoSize)
                    .graphicsLayer {
                        alpha = contentAlpha
                        scaleX = logoScale
                        scaleY = logoScale
                    }
            )
        }
    }
}
