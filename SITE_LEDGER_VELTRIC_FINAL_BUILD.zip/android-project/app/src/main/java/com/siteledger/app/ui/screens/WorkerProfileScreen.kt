package com.siteledger.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.siteledger.app.data.export.PayrollExporter
import com.siteledger.app.domain.model.AdvanceRecord
import com.siteledger.app.domain.model.AppLanguage
import com.siteledger.app.domain.model.AttendanceAuditEntry
import com.siteledger.app.domain.model.DailyAttendanceRecord
import com.siteledger.app.domain.model.DutyMultiplierConfig
import com.siteledger.app.domain.model.DutyType
import com.siteledger.app.domain.model.PaymentAllocation
import com.siteledger.app.domain.model.PaymentAuditEntry
import com.siteledger.app.domain.model.PaymentLedgerEntry
import com.siteledger.app.domain.model.PayrollPeriodRecord
import com.siteledger.app.domain.model.PayrollPeriodStatus
import com.siteledger.app.domain.model.Site
import com.siteledger.app.domain.model.SiteStatus
import com.siteledger.app.domain.model.UserRole
import com.siteledger.app.domain.model.Worker
import com.siteledger.app.domain.model.WorkerMonthlySummary
import com.siteledger.app.domain.model.WorkerSiteHistory
import com.siteledger.app.domain.service.WageCalculator
import com.siteledger.app.ui.components.WorkerAvatar
import com.siteledger.app.ui.i18n.AppStrings
import com.siteledger.app.ui.theme.CanvasGrey
import com.siteledger.app.ui.theme.CrispWhite
import com.siteledger.app.ui.theme.EngineeringBlue
import com.siteledger.app.ui.theme.SlateInk
import com.siteledger.app.ui.theme.SlateMuted
import com.siteledger.app.ui.theme.StatusAmber
import com.siteledger.app.ui.theme.StatusGreen
import com.siteledger.app.ui.theme.StatusRed
import com.siteledger.app.ui.theme.SubtleBorderGrey
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WorkerProfileScreen(
    strings: AppStrings,
    language: AppLanguage,
    worker: Worker,
    activeSite: Site,
    allSites: List<Site>,
    allWorkersAcrossSites: List<Worker>,
    workerTransfers: List<WorkerSiteHistory>,
    activeRole: UserRole,
    dutyConfig: DutyMultiplierConfig,
    allAttendance: List<DailyAttendanceRecord>,
    attendanceAudits: List<AttendanceAuditEntry>,
    allPayments: List<PaymentLedgerEntry>,
    advances: List<AdvanceRecord>,
    paymentAllocations: List<PaymentAllocation>,
    paymentAudits: List<PaymentAuditEntry>,
    payrollPeriods: List<PayrollPeriodRecord>,
    onBack: () -> Unit,
    onEditWorkerClick: () -> Unit,
    onTransferWorker: (workerId: String, toSiteId: String, newLocalCode: String, note: String) -> Unit,
    onSaveAttendance: (dateIso: String, dutyType: DutyType, note: String, reason: String) -> Unit,
    onRecordPayment: (paymentDateIso: String, applicablePeriod: String, amount: Int, referenceNo: String, note: String, token: String) -> Unit,
    onRecordAdvance: (advanceDateIso: String, amount: Int, referenceNo: String, note: String, token: String) -> Unit,
    onAllocateAdvance: (advanceId: String, targetPeriod: String, amountToAllocate: Int, note: String) -> Unit,
    onVoidPayment: (txId: String, reason: String) -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedYear by remember { mutableIntStateOf(2026) }
    var selectedMonth by remember { mutableIntStateOf(11) }
    var selectedCalendarDate by remember { mutableStateOf("2026-11-15") }
    var historyYearFilter by remember { mutableStateOf<Int?>(null) }
    var selectedBreakdownSummary by remember { mutableStateOf<WorkerMonthlySummary?>(null) }
    var exportNotice by remember { mutableStateOf<String?>(null) }
    var showTransferDialog by remember { mutableStateOf(false) }

    val displayName = if (language == AppLanguage.BENGALI) worker.fullNameBn else worker.fullNameEn
    val categoryLabel = if (language == AppLanguage.BENGALI) worker.category.labelBn else worker.category.labelEn
    val sitesById = remember(allSites) { allSites.associateBy { it.id } }

    val selectedPeriodIso = WageCalculator.formatPeriodIso(selectedYear, selectedMonth)
    val isSelectedPeriodFinalized = remember(payrollPeriods, selectedPeriodIso, worker.siteId) {
        payrollPeriods.find { it.periodIso == selectedPeriodIso && it.siteId == worker.siteId }?.status == PayrollPeriodStatus.FINALIZED
    }

    // Worker profile history aggregates safely across sites while respecting individual period locks
    val monthlySummary = remember(worker, selectedYear, selectedMonth, allAttendance, paymentAllocations, payrollPeriods, sitesById) {
        WageCalculator.computeWorkerMonthlySummary(
            worker = worker,
            year = selectedYear,
            month = selectedMonth,
            allAttendance = allAttendance,
            allAllocations = paymentAllocations,
            periodRecords = payrollPeriods,
            siteIdFilter = null,
            sitesById = sitesById
        )
    }

    val currentMonthSummary = remember(worker, allAttendance, paymentAllocations, payrollPeriods, sitesById) {
        WageCalculator.computeWorkerMonthlySummary(
            worker = worker,
            year = 2026,
            month = 11,
            allAttendance = allAttendance,
            allAllocations = paymentAllocations,
            periodRecords = payrollPeriods,
            siteIdFilter = null,
            sitesById = sitesById
        )
    }
    val currentMonthProjection = remember(currentMonthSummary) {
        WageCalculator.computeCurrentMonthProjection(currentMonthSummary, asOfDay = 15)
    }

    val chronologicalPeriods = remember(worker, allAttendance, paymentAllocations, allPayments, historyYearFilter) {
        WageCalculator.collectWorkerPayrollPeriods(worker, allAttendance, paymentAllocations, allPayments)
            .filter { (y, _) -> historyYearFilter == null || y == historyYearFilter }
    }
    val monthlyHistoryList = remember(chronologicalPeriods, worker, allAttendance, paymentAllocations, payrollPeriods, sitesById) {
        chronologicalPeriods.map { (y, m) ->
            WageCalculator.computeWorkerMonthlySummary(worker, y, m, allAttendance, paymentAllocations, payrollPeriods, siteIdFilter = null, sitesById = sitesById)
        }
    }

    val workerAttendanceMap = remember(worker.id, allAttendance) {
        allAttendance.filter { it.workerId == worker.id }.associateBy { it.dateIso }
    }
    val workerAudits = remember(worker.id, attendanceAudits) {
        attendanceAudits.filter { it.workerId == worker.id }
    }
    val workerPayments = remember(worker.id, allPayments) {
        allPayments.filter { it.workerId == worker.id }
    }
    val workerAdvances = remember(worker.id, advances) {
        advances.filter { it.workerId == worker.id }
    }
    val workerPayAudits = remember(worker.id, paymentAudits) {
        paymentAudits.filter { it.workerId == worker.id }
    }
    val transfersForWorker = remember(worker.id, workerTransfers) {
        workerTransfers.filter { it.workerId == worker.id }
    }
    val unallocatedAdvanceTotal = remember(worker.id, advances, paymentAllocations) {
        WageCalculator.computeUnallocatedAdvanceBalance(worker.id, advances, paymentAllocations)
    }

    val canEditAttendance = activeRole != UserRole.ACCOUNTANT
    val canEditPayments = activeRole != UserRole.MANAGER
    val isAdmin = activeRole == UserRole.ADMIN
    val otherActiveSites = remember(allSites, worker.siteId) {
        allSites.filter { it.id != worker.siteId && it.status == SiteStatus.ACTIVE }
    }

    var showAttendanceDialog by remember { mutableStateOf(false) }
    var showPaymentDialog by remember { mutableStateOf(false) }
    var showAdvanceDialog by remember { mutableStateOf(false) }
    var allocateTargetAdvance by remember { mutableStateOf<AdvanceRecord?>(null) }
    var voidConfirmTx by remember { mutableStateOf<PaymentLedgerEntry?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Profile Header
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = CrispWhite),
            border = BorderStroke(1.dp, SubtleBorderGrey)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = strings.close)
                }
                WorkerAvatar(name = displayName, photoPath = worker.photoPath, size = 54.dp)
                Column(modifier = Modifier.weight(1f)) {
                    Text(displayName, style = MaterialTheme.typography.titleMedium, color = SlateInk)
                    Text(
                        text = "${worker.localWorkerCode} · $categoryLabel · ৳${worker.dailyWage}/day",
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateMuted
                    )
                    Text(
                        text = "${activeSite.siteName} · ${if (worker.isActive) strings.activeStatus else strings.inactiveStatus}",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (worker.isActive) StatusGreen else StatusRed
                    )
                }
                if (isAdmin && otherActiveSites.isNotEmpty()) {
                    IconButton(onClick = { showTransferDialog = true }) {
                        Icon(Icons.Outlined.SwapHoriz, contentDescription = strings.transferWorkerBtn, tint = EngineeringBlue)
                    }
                }
                if (activeRole != UserRole.ACCOUNTANT) {
                    IconButton(onClick = onEditWorkerClick) {
                        Icon(Icons.Outlined.Edit, contentDescription = strings.editWorker, tint = EngineeringBlue)
                    }
                }
            }
        }

        val tabs = listOf(
            strings.profileTabOverview,
            strings.profileTabAttendance,
            strings.profileTabPayrollHistory,
            strings.profileTabPayments,
            strings.profileTabPersonal
        )
        ScrollableTabRow(selectedTabIndex = selectedTab, containerColor = CrispWhite, edgePadding = 8.dp) {
            tabs.forEachIndexed { idx, label ->
                Tab(
                    selected = selectedTab == idx,
                    onClick = { selectedTab = idx },
                    text = { Text(label, maxLines = 1) }
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (selectedTab == 0 || selectedTab == 1) {
                item {
                    MonthYearSelectorBar(
                        strings = strings,
                        selectedYear = selectedYear,
                        selectedMonth = selectedMonth,
                        onSelectYear = { selectedYear = it },
                        onSelectMonth = { m ->
                            selectedMonth = m
                            selectedCalendarDate = "%04d-%02d-01".format(selectedYear, m)
                        }
                    )
                }
                if (isSelectedPeriodFinalized) {
                    item { WarningBanner(strings.payrollLockedWarning) }
                }
            }

            when (selectedTab) {
                0 -> {
                    if (monthlySummary.outstandingBalance < 0) {
                        item { WarningBanner(strings.overpaymentWarning) }
                    } else if (worker.isActive &&
                        (monthlySummary.halfDutyCount +
                            monthlySummary.fullDutyCount +
                            monthlySummary.oneAndHalfDutyCount +
                            monthlySummary.doubleDutyCount +
                            monthlySummary.twoAndHalfDutyCount +
                            monthlySummary.tripleDutyCount) == 0
                    ) {
                        item { WarningBanner(strings.noMonthAttendanceWarning) }
                    }

                    item {
                        CurrentMonthPayrollCard(
                            strings = strings,
                            summary = currentMonthSummary,
                            projection = currentMonthProjection
                        )
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = CrispWhite),
                            border = BorderStroke(1.dp, SubtleBorderGrey)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "${strings.monthlyBreakdownTitle} ($selectedPeriodIso)",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = SlateInk
                                )
                                SummaryRow(strings.totalCalendarDays, monthlySummary.totalCalendarDays.toString())
                                SummaryRow(strings.halfDutyLabel, monthlySummary.halfDutyCount.toString(), StatusAmber)
                                SummaryRow(strings.fullDutyLabel, monthlySummary.fullDutyCount.toString(), StatusGreen)
                                SummaryRow(strings.oneAndHalfDutyLabel, monthlySummary.oneAndHalfDutyCount.toString(), EngineeringBlue)
                                SummaryRow(strings.doubleDutyLabel, monthlySummary.doubleDutyCount.toString(), EngineeringBlue)
                                SummaryRow(strings.twoAndHalfDutyLabel, monthlySummary.twoAndHalfDutyCount.toString(), EngineeringBlue)
                                SummaryRow(strings.tripleDutyLabel, monthlySummary.tripleDutyCount.toString(), EngineeringBlue)
                                SummaryRow(strings.absentLabel, monthlySummary.absentCount.toString(), StatusRed)
                                SummaryRow(strings.leaveLabel, monthlySummary.leaveCount.toString(), SlateMuted)
                                HorizontalDivider(color = SubtleBorderGrey)
                                SummaryRow(strings.totalDutyUnits, String.format(Locale.US, "%.1f", monthlySummary.totalDutyUnits), SlateInk)
                                SummaryRow(strings.totalEarnedAmount, "৳${monthlySummary.totalEarnedAmount}", SlateInk)
                                SummaryRow(strings.totalPaidAmount, "৳${monthlySummary.totalPaidAmount}", StatusGreen)
                                SummaryRow(strings.advanceAppliedLabel, "৳${monthlySummary.advanceAllocatedAmount}", SlateMuted)
                                SummaryRow(strings.remainingBalance, "৳${monthlySummary.outstandingBalance}", EngineeringBlue)
                                SummaryRow(
                                    strings.payrollStatusLabel,
                                    if (language == AppLanguage.BENGALI) monthlySummary.payrollStatus.labelBn else monthlySummary.payrollStatus.labelEn,
                                    if (monthlySummary.outstandingBalance == 0 && monthlySummary.totalEarnedAmount > 0) StatusGreen else EngineeringBlue
                                )
                            }
                        }
                    }
                }

                1 -> {
                    item {
                        MonthlyDutyCalendarCard(
                            year = selectedYear,
                            month = selectedMonth,
                            selectedDateIso = selectedCalendarDate,
                            recordsByDate = workerAttendanceMap,
                            onSelectDate = { dateIso -> selectedCalendarDate = dateIso }
                        )
                    }

                    item {
                        val dayRecord = workerAttendanceMap[selectedCalendarDate]
                        val dayPeriodFinalized = payrollPeriods.find { it.periodIso == selectedCalendarDate.take(7) && it.siteId == worker.siteId }?.status == PayrollPeriodStatus.FINALIZED
                        SelectedDateDetailCard(
                            strings = strings,
                            language = language,
                            dateIso = selectedCalendarDate,
                            record = dayRecord,
                            sitesById = sitesById,
                            canEdit = canEditAttendance && !dayPeriodFinalized,
                            onEditClick = { showAttendanceDialog = true }
                        )
                    }

                    if (workerAudits.isNotEmpty()) {
                        item {
                            Text(strings.auditHistoryTitle, style = MaterialTheme.typography.titleMedium, color = SlateInk)
                        }
                        items(workerAudits, key = { it.auditId }) { audit ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                                border = BorderStroke(1.dp, SubtleBorderGrey)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = "${audit.dateIso}: ${audit.previousDutyType?.name ?: "NONE"} -> ${audit.newDutyType.name}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = SlateInk
                                    )
                                    Text(
                                        text = "৳${audit.previousEarned ?: 0} -> ৳${audit.newEarned} · ${audit.changedByRole.name} · ${audit.changedAtIso}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SlateMuted
                                    )
                                }
                            }
                        }
                    }
                }

                2 -> {
                    item {
                        CurrentMonthPayrollCard(
                            strings = strings,
                            summary = currentMonthSummary,
                            projection = currentMonthProjection
                        )
                    }

                    item {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = historyYearFilter == null,
                                onClick = { historyYearFilter = null },
                                label = { Text("${strings.selectYear}: ${strings.allFilter}") }
                            )
                            listOf(2025, 2026).forEach { y ->
                                FilterChip(
                                    selected = historyYearFilter == y,
                                    onClick = { historyYearFilter = y },
                                    label = { Text(y.toString()) }
                                )
                            }
                        }
                    }

                    exportNotice?.let { notice ->
                        item {
                            Text(notice, style = MaterialTheme.typography.bodySmall, color = StatusGreen)
                        }
                    }

                    items(monthlyHistoryList, key = { it.periodIso }) { mSummary ->
                        val pStatusLabel = if (language == AppLanguage.BENGALI) mSummary.payrollStatus.labelBn else mSummary.payrollStatus.labelEn
                        val lockLabel = if (mSummary.periodLockStatus == PayrollPeriodStatus.FINALIZED) strings.payrollFinalizedBadge else strings.payrollOpenBadge
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedBreakdownSummary = mSummary },
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = CrispWhite),
                            border = BorderStroke(1.dp, SubtleBorderGrey)
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${mSummary.periodIso} · $lockLabel",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = SlateInk
                                    )
                                    Text(
                                        text = pStatusLabel,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (mSummary.outstandingBalance == 0 && mSummary.totalEarnedAmount > 0) StatusGreen else EngineeringBlue
                                    )
                                }
                                Text(
                                    text = "H:${mSummary.halfDutyCount}  F:${mSummary.fullDutyCount}  1.5:${mSummary.oneAndHalfDutyCount}  D:${mSummary.doubleDutyCount}  2.5:${mSummary.twoAndHalfDutyCount}  T:${mSummary.tripleDutyCount}  A:${mSummary.absentCount}  L:${mSummary.leaveCount}  ·  ${strings.totalDutyUnits}: ${String.format(Locale.US, "%.1f", mSummary.totalDutyUnits)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SlateMuted
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("${strings.totalEarnedAmount}: ৳${mSummary.totalEarnedAmount}", style = MaterialTheme.typography.bodySmall, color = SlateInk)
                                    Text("${strings.totalPaidAmount}: ৳${mSummary.totalPaidAmount}", style = MaterialTheme.typography.bodySmall, color = StatusGreen)
                                    Text("${strings.remainingBalance}: ৳${mSummary.outstandingBalance}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = EngineeringBlue)
                                }
                                if (mSummary.advanceAllocatedAmount > 0) {
                                    Text(
                                        text = "${strings.advanceAppliedLabel}: ৳${mSummary.advanceAllocatedAmount}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = StatusAmber
                                    )
                                }
                            }
                        }
                    }
                }

                3 -> {
                    val overall = WageCalculator.computeWorkerOverallBalances(worker.id, allAttendance, paymentAllocations)
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = CrispWhite),
                            border = BorderStroke(1.dp, SubtleBorderGrey)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                SummaryRow(strings.totalEarnedAmount, "৳${overall.first}", SlateInk)
                                SummaryRow(strings.totalPaidAmount, "৳${overall.second}", StatusGreen)
                                SummaryRow(strings.unallocatedAdvancesLabel, "৳$unallocatedAdvanceTotal", StatusAmber)
                                SummaryRow(strings.remainingBalance, "৳${overall.third}", EngineeringBlue)
                                Spacer(modifier = Modifier.height(4.dp))
                                if (canEditPayments) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                        Button(
                                            onClick = { showPaymentDialog = true },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(strings.recordPayment, maxLines = 1)
                                        }
                                        OutlinedButton(
                                            onClick = { showAdvanceDialog = true },
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(strings.recordAdvanceBtn, maxLines = 1)
                                        }
                                    }
                                } else {
                                    Text(strings.roleRestrictedAction, style = MaterialTheme.typography.bodySmall, color = StatusAmber)
                                }
                            }
                        }
                    }

                    if (workerAdvances.isNotEmpty()) {
                        item {
                            Text(strings.unallocatedAdvancesLabel, style = MaterialTheme.typography.titleMedium, color = SlateInk)
                        }
                        items(workerAdvances, key = { it.id }) { adv ->
                            val remaining = WageCalculator.computeAdvanceRemaining(adv, paymentAllocations)
                            val advSiteName = sitesById[adv.siteId]?.siteCode ?: adv.siteId
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                                border = BorderStroke(1.dp, SubtleBorderGrey)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("${adv.id} · $advSiteName · ${adv.advanceDateIso}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = SlateInk)
                                        Text("${adv.referenceNo} · ${adv.note}", style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                                        Text("Total: ৳${adv.amount} · Remaining: ৳$remaining", style = MaterialTheme.typography.bodySmall, color = StatusAmber)
                                    }
                                    if (remaining > 0 && canEditPayments) {
                                        OutlinedButton(onClick = { allocateTargetAdvance = adv }) {
                                            Text(strings.allocateAdvanceBtn)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Text(strings.transactionHistory, style = MaterialTheme.typography.titleMedium, color = SlateInk)
                    }

                    items(workerPayments, key = { it.id }) { tx ->
                        val txPeriodLocked = payrollPeriods.find { it.periodIso == tx.applicablePeriod && it.siteId == tx.siteId }?.status == PayrollPeriodStatus.FINALIZED
                        val txSiteCode = sitesById[tx.siteId]?.siteCode ?: tx.siteId
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = CrispWhite),
                            border = BorderStroke(1.dp, SubtleBorderGrey)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${tx.id} · $txSiteCode · ${tx.dateIso}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (tx.isVoided) SlateMuted else SlateInk
                                    )
                                    Text(
                                        text = "${strings.applicablePeriodLabel}: ${tx.applicablePeriod} · ${tx.referenceNo}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = EngineeringBlue
                                    )
                                    Text(
                                        text = if (language == AppLanguage.BENGALI) tx.noteBn else tx.noteEn,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SlateMuted
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = if (tx.isVoided) strings.voidedLabel else "৳${tx.paidAmount}",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = if (tx.isVoided) StatusRed else StatusGreen
                                    )
                                    if (!tx.isVoided && canEditPayments && !txPeriodLocked) {
                                        TextButton(onClick = { voidConfirmTx = tx }) {
                                            Text(strings.voidTransaction, color = StatusRed)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (workerPayAudits.isNotEmpty()) {
                        item {
                            Text(strings.auditHistoryTitle, style = MaterialTheme.typography.titleMedium, color = SlateInk)
                        }
                        items(workerPayAudits, key = { it.auditId }) { pa ->
                            Text(
                                text = "${pa.transactionId}: ${pa.action} (৳${pa.newAmount}) · ${pa.changedByRole.name} · ${pa.changedAtIso}",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateMuted
                            )
                        }
                    }
                }

                4 -> {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = CrispWhite),
                            border = BorderStroke(1.dp, SubtleBorderGrey)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                SummaryRow(strings.fullNameLabel, displayName)
                                SummaryRow(strings.activeSiteLabel, "${activeSite.siteCode} · ${activeSite.siteName}", EngineeringBlue)
                                SummaryRow(strings.workerIdLabel, worker.localWorkerCode)
                                SummaryRow(strings.phoneNumberLabel, worker.phoneNumber.ifBlank { "-" })
                                SummaryRow(strings.categoryLabel, categoryLabel)
                                SummaryRow(strings.joiningDateLabel, worker.joiningDateIso)
                                SummaryRow(strings.leavingDateLabel, worker.leavingDateIso ?: "-")
                                SummaryRow(strings.dailyWageLabel, "৳${worker.dailyWage}")
                                SummaryRow(strings.foodAllowanceLabel, "৳${worker.dailyFoodAllowance}")
                                SummaryRow(
                                    strings.statusLabel,
                                    if (worker.isActive) strings.activeStatus else strings.inactiveStatus,
                                    if (worker.isActive) StatusGreen else StatusRed
                                )
                                if (isAdmin && otherActiveSites.isNotEmpty()) {
                                    OutlinedButton(
                                        onClick = { showTransferDialog = true },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Outlined.SwapHoriz, contentDescription = null)
                                        Text(" ${strings.transferWorkerBtn}")
                                    }
                                }
                            }
                        }
                    }

                    if (transfersForWorker.isNotEmpty()) {
                        item {
                            Text(strings.siteTransferHistoryTitle, style = MaterialTheme.typography.titleMedium, color = SlateInk)
                        }
                        items(transfersForWorker, key = { it.transferId }) { tr ->
                            val fromName = sitesById[tr.previousSiteId]?.siteName ?: tr.previousSiteId
                            val toName = sitesById[tr.newSiteId]?.siteName ?: tr.newSiteId
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = CrispWhite),
                                border = BorderStroke(1.dp, SubtleBorderGrey)
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("$fromName -> $toName", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = EngineeringBlue)
                                    Text("${tr.transferDateIso} · ${tr.authorizedByRole.name}", style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                                    if (tr.notes.isNotBlank()) {
                                        Text(tr.notes, style = MaterialTheme.typography.bodySmall, color = SlateInk)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showTransferDialog && otherActiveSites.isNotEmpty()) {
        var targetSiteId by remember { mutableStateOf(otherActiveSites.first().id) }
        var newLocalCode by remember { mutableStateOf(worker.localWorkerCode) }
        var transferNote by remember { mutableStateOf("Project resource relocation") }
        val duplicateTargetCode = WageCalculator.isLocalWorkerCodeDuplicate(
            siteId = targetSiteId,
            localWorkerCode = newLocalCode,
            excludeWorkerId = worker.id,
            workers = allWorkersAcrossSites
        )

        AlertDialog(
            onDismissRequest = { showTransferDialog = false },
            title = { Text(strings.transferWorkerTitle) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(strings.targetSiteLabel, style = MaterialTheme.typography.labelMedium, color = SlateMuted)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        otherActiveSites.forEach { s ->
                            FilterChip(
                                selected = targetSiteId == s.id,
                                onClick = { targetSiteId = s.id },
                                label = { Text("${s.siteCode} · ${s.siteName}") }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = newLocalCode,
                        onValueChange = { newLocalCode = it },
                        label = { Text(strings.workerIdLabel) },
                        isError = duplicateTargetCode,
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (duplicateTargetCode) {
                        Text(strings.duplicateLocalCodeError, style = MaterialTheme.typography.bodySmall, color = StatusRed)
                    }
                    OutlinedTextField(
                        value = transferNote,
                        onValueChange = { transferNote = it },
                        label = { Text(strings.transferNoteLabel) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = newLocalCode.isNotBlank() && !duplicateTargetCode,
                    onClick = {
                        onTransferWorker(worker.id, targetSiteId, newLocalCode.trim(), transferNote.trim())
                        showTransferDialog = false
                    }
                ) { Text(strings.confirmAction) }
            },
            dismissButton = {
                TextButton(onClick = { showTransferDialog = false }) { Text(strings.cancel) }
            }
        )
    }

    selectedBreakdownSummary?.let { mSummary ->
        val dayRecords = remember(allAttendance, worker.id, mSummary.periodIso) {
            allAttendance.filter { it.workerId == worker.id && it.dateIso.startsWith("${mSummary.periodIso}-") }
        }
        AlertDialog(
            onDismissRequest = { selectedBreakdownSummary = null },
            title = { Text("${strings.monthlyBreakdownTitle} · ${mSummary.periodIso}") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    SummaryRow(strings.halfDutyLabel, mSummary.halfDutyCount.toString(), StatusAmber)
                    SummaryRow(strings.fullDutyLabel, mSummary.fullDutyCount.toString(), StatusGreen)
                    SummaryRow(strings.oneAndHalfDutyLabel, mSummary.oneAndHalfDutyCount.toString(), EngineeringBlue)
                    SummaryRow(strings.doubleDutyLabel, mSummary.doubleDutyCount.toString(), EngineeringBlue)
                    SummaryRow(strings.twoAndHalfDutyLabel, mSummary.twoAndHalfDutyCount.toString(), EngineeringBlue)
                    SummaryRow(strings.tripleDutyLabel, mSummary.tripleDutyCount.toString(), EngineeringBlue)
                    SummaryRow(strings.absentLabel, mSummary.absentCount.toString(), StatusRed)
                    SummaryRow(strings.leaveLabel, mSummary.leaveCount.toString(), SlateMuted)
                    SummaryRow(strings.totalDutyUnits, String.format(Locale.US, "%.1f", mSummary.totalDutyUnits))
                    SummaryRow(strings.totalEarnedAmount, "৳${mSummary.totalEarnedAmount}")
                    SummaryRow(strings.totalPaidAmount, "৳${mSummary.totalPaidAmount}", StatusGreen)
                    SummaryRow(strings.advanceAppliedLabel, "৳${mSummary.advanceAllocatedAmount}", StatusAmber)
                    SummaryRow(strings.remainingBalance, "৳${mSummary.outstandingBalance}", EngineeringBlue)
                    HorizontalDivider(color = SubtleBorderGrey)
                    dayRecords.sortedBy { it.dateIso }.take(10).forEach { rec ->
                        val dtLabel = if (language == AppLanguage.BENGALI) rec.dutyType.labelBn else rec.dutyType.labelEn
                        Text(
                            text = "${rec.dateIso}: $dtLabel (${rec.multiplierSnapshot}x) · ৳${rec.earnedAmount}",
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateInk
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val file = PayrollExporter.exportIndividualWorkerPdf(context, language, mSummary, dayRecords)
                    exportNotice = "${strings.exportSuccessNotice} ${file.name}"
                    selectedBreakdownSummary = null
                }) {
                    Text(strings.exportWorkerPdfBtn)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedBreakdownSummary = null }) { Text(strings.close) }
            }
        )
    }

    if (showAttendanceDialog) {
        val existing = workerAttendanceMap[selectedCalendarDate]
        AttendanceEditDialog(
            strings = strings,
            language = language,
            dateIso = selectedCalendarDate,
            worker = worker,
            dutyConfig = dutyConfig,
            existingRecord = existing,
            onDismiss = { showAttendanceDialog = false },
            onSave = { duty, note, reason ->
                onSaveAttendance(selectedCalendarDate, duty, note, reason)
                showAttendanceDialog = false
            }
        )
    }

    if (showPaymentDialog) {
        WorkerPaymentEntryDialog(
            strings = strings,
            defaultPeriod = selectedPeriodIso,
            outstandingBalance = monthlySummary.outstandingBalance,
            payrollPeriods = payrollPeriods.filter { it.siteId == worker.siteId },
            onDismiss = { showPaymentDialog = false },
            onConfirm = { payDate, periodIso, amount, ref, note ->
                onRecordPayment(payDate, periodIso, amount, ref, note, UUID.randomUUID().toString())
                showPaymentDialog = false
            }
        )
    }

    if (showAdvanceDialog) {
        AdvanceEntryDialog(
            strings = strings,
            onDismiss = { showAdvanceDialog = false },
            onConfirm = { dateIso, amount, ref, note ->
                onRecordAdvance(dateIso, amount, ref, note, UUID.randomUUID().toString())
                showAdvanceDialog = false
            }
        )
    }

    allocateTargetAdvance?.let { adv ->
        val remaining = WageCalculator.computeAdvanceRemaining(adv, paymentAllocations)
        AllocateAdvanceDialog(
            strings = strings,
            advance = adv,
            remainingAdvance = remaining,
            defaultPeriod = selectedPeriodIso,
            payrollPeriods = payrollPeriods.filter { it.siteId == adv.siteId },
            onDismiss = { allocateTargetAdvance = null },
            onConfirm = { targetPeriod, amountToApply, note ->
                onAllocateAdvance(adv.id, targetPeriod, amountToApply, note)
                allocateTargetAdvance = null
            }
        )
    }

    voidConfirmTx?.let { tx ->
        AlertDialog(
            onDismissRequest = { voidConfirmTx = null },
            title = { Text(strings.voidTransaction) },
            text = { Text(strings.confirmVoidPaymentMsg) },
            confirmButton = {
                Button(onClick = {
                    onVoidPayment(tx.id, "Voided from Worker Profile")
                    voidConfirmTx = null
                }) {
                    Text(strings.confirmAction)
                }
            },
            dismissButton = {
                TextButton(onClick = { voidConfirmTx = null }) {
                    Text(strings.cancel)
                }
            }
        )
    }
}

@Composable
private fun CurrentMonthPayrollCard(
    strings: AppStrings,
    summary: WorkerMonthlySummary,
    projection: com.siteledger.app.domain.model.CurrentMonthProjection
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
        border = BorderStroke(1.dp, EngineeringBlue)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "${strings.currentMonthPayrollTitle} (${summary.periodIso})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = EngineeringBlue
            )
            SummaryRow(strings.earnedUpToTodayLabel, "৳${projection.earnedToDate}", SlateInk)
            SummaryRow(strings.totalPaidAmount, "৳${projection.paidToDate}", StatusGreen)
            SummaryRow(strings.remainingBalance, "৳${projection.remainingBalance}", EngineeringBlue)
            SummaryRow(strings.totalDutyUnits, String.format(Locale.US, "%.1f", projection.dutyUnitsToDate), SlateInk)
            HorizontalDivider(color = SubtleBorderGrey)
            SummaryRow(strings.estimatedMonthEndLabel, "৳${projection.estimatedMonthEndSalary}", StatusAmber)
            Text(
                text = strings.estimateDisclaimer,
                style = MaterialTheme.typography.labelSmall,
                color = StatusAmber
            )
        }
    }
}

@Composable
private fun MonthYearSelectorBar(
    strings: AppStrings,
    selectedYear: Int,
    selectedMonth: Int,
    onSelectYear: (Int) -> Unit,
    onSelectMonth: (Int) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(2025, 2026).forEach { y ->
                FilterChip(
                    selected = selectedYear == y,
                    onClick = { onSelectYear(y) },
                    label = { Text("${strings.selectYear}: $y") }
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(9, 10, 11, 12).forEach { m ->
                FilterChip(
                    selected = selectedMonth == m,
                    onClick = { onSelectMonth(m) },
                    label = { Text("%02d".format(m)) }
                )
            }
        }
    }
}

@Composable
private fun MonthlyDutyCalendarCard(
    year: Int,
    month: Int,
    selectedDateIso: String,
    recordsByDate: Map<String, DailyAttendanceRecord>,
    onSelectDate: (String) -> Unit
) {
    val totalDays = WageCalculator.daysInMonth(year, month)
    val days = (1..totalDays).toList()

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CrispWhite),
        border = BorderStroke(1.dp, SubtleBorderGrey)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            days.chunked(7).forEach { week ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    week.forEach { day ->
                        val dateIso = "%04d-%02d-%02d".format(year, month, day)
                        val rec = recordsByDate[dateIso]
                        val bgColor = when (rec?.dutyType) {
                            DutyType.HALF_DUTY -> Color(0xFFFEF3C7)
                            DutyType.FULL_DUTY -> Color(0xFFDCFCE7)
                            DutyType.ONE_AND_HALF_DUTY -> Color(0xFFCCFBF1)
                            DutyType.DOUBLE_DUTY -> Color(0xFFE0E7FF)
                            DutyType.TWO_AND_HALF_DUTY -> Color(0xFFF3E8FF)
                            DutyType.TRIPLE_DUTY -> Color(0xFFDBEAFE)
                            DutyType.ABSENT -> Color(0xFFFEE2E2)
                            DutyType.LEAVE -> Color(0xFFE2E8F0)
                            null -> CanvasGrey
                        }
                        val textColor = when (rec?.dutyType) {
                            DutyType.HALF_DUTY -> StatusAmber
                            DutyType.FULL_DUTY -> StatusGreen
                            DutyType.ONE_AND_HALF_DUTY -> Color(0xFF0F766E)
                            DutyType.DOUBLE_DUTY -> Color(0xFF4338CA)
                            DutyType.TWO_AND_HALF_DUTY -> Color(0xFF7E22CE)
                            DutyType.TRIPLE_DUTY -> EngineeringBlue
                            DutyType.ABSENT -> StatusRed
                            DutyType.LEAVE -> SlateMuted
                            null -> SlateInk
                        }
                        val isSelected = dateIso == selectedDateIso

                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(bgColor)
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) EngineeringBlue else SubtleBorderGrey,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { onSelectDate(dateIso) }
                                .padding(2.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = day.toString(),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = textColor,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = rec?.dutyType?.shortCode ?: "-",
                                style = MaterialTheme.typography.bodySmall,
                                color = textColor
                            )
                        }
                    }
                    repeat(7 - week.size) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun SelectedDateDetailCard(
    strings: AppStrings,
    language: AppLanguage,
    dateIso: String,
    record: DailyAttendanceRecord?,
    sitesById: Map<String, Site>,
    canEdit: Boolean,
    onEditClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CrispWhite),
        border = BorderStroke(1.dp, SubtleBorderGrey)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${strings.selectedDateDetails}: $dateIso", style = MaterialTheme.typography.titleMedium, color = SlateInk)
            if (record == null) {
                Text(strings.notRecordedLabel, style = MaterialTheme.typography.bodyMedium, color = SlateMuted)
            } else {
                val dutyLabel = if (language == AppLanguage.BENGALI) record.dutyType.labelBn else record.dutyType.labelEn
                val recSite = sitesById[record.siteId]?.siteName ?: record.siteId
                SummaryRow(strings.siteColumnLabel, recSite)
                SummaryRow(strings.dutyTypeLabel, dutyLabel)
                SummaryRow(strings.dutyUnitsLabel, record.multiplierSnapshot.toString())
                SummaryRow(strings.dailyWageLabel, "৳${record.dailyWageSnapshot}")
                SummaryRow(strings.earnedAmountLabel, "৳${record.earnedAmount}", EngineeringBlue)
                SummaryRow(strings.notesLabel, record.note.ifBlank { "-" })
                SummaryRow(strings.lastUpdatedLabel, "${record.updatedAtIso} (${record.updatedByRole.name})")
            }
            if (canEdit) {
                OutlinedButton(onClick = onEditClick, modifier = Modifier.fillMaxWidth()) {
                    Text(strings.recordOrEditAttendance)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AttendanceEditDialog(
    strings: AppStrings,
    language: AppLanguage,
    dateIso: String,
    worker: Worker,
    dutyConfig: DutyMultiplierConfig,
    existingRecord: DailyAttendanceRecord?,
    onDismiss: () -> Unit,
    onSave: (DutyType, String, String) -> Unit
) {
    var selectedDuty by remember { mutableStateOf(existingRecord?.dutyType ?: DutyType.FULL_DUTY) }
    var note by remember { mutableStateOf(existingRecord?.note ?: "") }
    var needsConfirm by remember { mutableStateOf(false) }

    val wageBase = existingRecord?.dailyWageSnapshot ?: worker.dailyWage
    val mult = dutyConfig.multiplierFor(selectedDuty)
    val previewEarned = WageCalculator.calculateDailyEarnedTaka(wageBase, mult)
    val selectedDutyLabel = if (language == AppLanguage.BENGALI) selectedDuty.labelBn else selectedDuty.labelEn

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${strings.recordOrEditAttendance} · $dateIso") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DutyType.entries.forEach { dt ->
                        val label = if (language == AppLanguage.BENGALI) dt.labelBn else dt.labelEn
                        FilterChip(
                            selected = selectedDuty == dt,
                            onClick = { selectedDuty = dt },
                            label = { Text("$label (${dutyConfig.multiplierFor(dt)}x)") }
                        )
                    }
                }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                    border = BorderStroke(1.dp, EngineeringBlue)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("${strings.dutyTypeLabel}: $selectedDutyLabel", style = MaterialTheme.typography.bodySmall, color = SlateInk)
                        Text("${strings.dutyMultiplierLabel}: ${mult}x", style = MaterialTheme.typography.bodySmall, color = SlateInk)
                        Text("${strings.savedDailyWageLabel}: ৳$wageBase", style = MaterialTheme.typography.bodySmall, color = SlateInk)
                        Text(
                            text = "${strings.earnedAmountLabel}: ৳$wageBase × $mult = ৳$previewEarned",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = EngineeringBlue
                        )
                    }
                }
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text(strings.notesLabel) }, singleLine = true)
                if (needsConfirm) {
                    Text(strings.confirmEditAttendanceMsg, style = MaterialTheme.typography.bodySmall, color = StatusAmber)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (existingRecord != null && !needsConfirm) {
                    needsConfirm = true
                } else {
                    onSave(selectedDuty, note, if (existingRecord != null) "Edited from profile" else "Initial")
                }
            }) { Text(if (needsConfirm) strings.confirmAction else strings.saveChanges) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun WorkerPaymentEntryDialog(
    strings: AppStrings,
    defaultPeriod: String,
    outstandingBalance: Int,
    payrollPeriods: List<PayrollPeriodRecord>,
    onDismiss: () -> Unit,
    onConfirm: (paymentDateIso: String, applicablePeriod: String, amount: Int, ref: String, note: String) -> Unit
) {
    var paymentDate by remember { mutableStateOf("2026-11-15") }
    var applicablePeriod by remember { mutableStateOf(defaultPeriod) }
    var amount by remember { mutableStateOf(outstandingBalance.coerceAtLeast(0).toString()) }
    var ref by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val isLocked = payrollPeriods.find { it.periodIso == applicablePeriod }?.status == PayrollPeriodStatus.FINALIZED

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.recordPayment) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(strings.applicablePeriodLabel, style = MaterialTheme.typography.labelMedium, color = SlateMuted)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("2026-09", "2026-10", "2026-11").forEach { p ->
                        FilterChip(selected = applicablePeriod == p, onClick = { applicablePeriod = p }, label = { Text(p) })
                    }
                }
                if (isLocked) {
                    Text(strings.payrollLockedWarning, style = MaterialTheme.typography.bodySmall, color = StatusRed)
                }
                OutlinedTextField(value = paymentDate, onValueChange = { paymentDate = it }, label = { Text(strings.paymentDateLabel) }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { amount = outstandingBalance.coerceAtLeast(0).toString() }) {
                        Text(strings.fullPaymentBtn)
                    }
                    OutlinedButton(onClick = { amount = (outstandingBalance.coerceAtLeast(0) / 2).toString() }) {
                        Text(strings.partialPaymentBtn)
                    }
                }
                OutlinedTextField(value = amount, onValueChange = { amount = it.filter(Char::isDigit) }, label = { Text(strings.paymentAmountLabel) }, singleLine = true)
                OutlinedTextField(value = ref, onValueChange = { ref = it }, label = { Text(strings.referenceNoLabel) }, singleLine = true)
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text(strings.paymentNoteLabel) }, singleLine = true)
            }
        },
        confirmButton = {
            Button(
                enabled = !isLocked,
                onClick = {
                    val amt = amount.toIntOrNull() ?: 0
                    if (amt > 0) onConfirm(paymentDate.ifBlank { "2026-11-15" }, applicablePeriod, amt, ref.ifBlank { "CASH" }, note.ifBlank { "Payment recorded" })
                }
            ) { Text(strings.saveEntry) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}

@Composable
private fun AdvanceEntryDialog(
    strings: AppStrings,
    onDismiss: () -> Unit,
    onConfirm: (dateIso: String, amount: Int, ref: String, note: String) -> Unit
) {
    var dateIso by remember { mutableStateOf("2026-11-15") }
    var amount by remember { mutableStateOf("") }
    var ref by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(strings.recordAdvanceBtn) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = dateIso, onValueChange = { dateIso = it }, label = { Text(strings.paymentDateLabel) }, singleLine = true)
                OutlinedTextField(value = amount, onValueChange = { amount = it.filter(Char::isDigit) }, label = { Text(strings.paymentAmountLabel) }, singleLine = true)
                OutlinedTextField(value = ref, onValueChange = { ref = it }, label = { Text(strings.referenceNoLabel) }, singleLine = true)
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text(strings.notesLabel) }, singleLine = true)
            }
        },
        confirmButton = {
            Button(onClick = {
                val amt = amount.toIntOrNull() ?: 0
                if (amt > 0) onConfirm(dateIso.ifBlank { "2026-11-15" }, amt, ref.ifBlank { "ADV" }, note.ifBlank { "Site advance" })
            }) { Text(strings.saveEntry) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AllocateAdvanceDialog(
    strings: AppStrings,
    advance: AdvanceRecord,
    remainingAdvance: Int,
    defaultPeriod: String,
    payrollPeriods: List<PayrollPeriodRecord>,
    onDismiss: () -> Unit,
    onConfirm: (targetPeriod: String, amountToApply: Int, note: String) -> Unit
) {
    var targetPeriod by remember { mutableStateOf(defaultPeriod) }
    var amount by remember { mutableStateOf(remainingAdvance.toString()) }
    var note by remember { mutableStateOf("Applied advance ${advance.id}") }
    val isLocked = payrollPeriods.find { it.periodIso == targetPeriod }?.status == PayrollPeriodStatus.FINALIZED

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${strings.allocateAdvanceBtn} (${advance.id})") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${strings.applicablePeriodLabel}:", style = MaterialTheme.typography.labelMedium, color = SlateMuted)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("2026-09", "2026-10", "2026-11").forEach { p ->
                        FilterChip(selected = targetPeriod == p, onClick = { targetPeriod = p }, label = { Text(p) })
                    }
                }
                if (isLocked) {
                    Text(strings.payrollLockedWarning, style = MaterialTheme.typography.bodySmall, color = StatusRed)
                }
                OutlinedTextField(value = amount, onValueChange = { amount = it.filter(Char::isDigit) }, label = { Text(strings.paymentAmountLabel) }, singleLine = true)
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text(strings.notesLabel) }, singleLine = true)
            }
        },
        confirmButton = {
            Button(
                enabled = !isLocked,
                onClick = {
                    val amt = (amount.toIntOrNull() ?: 0).coerceIn(0, remainingAdvance)
                    if (amt > 0) onConfirm(targetPeriod, amt, note)
                }
            ) { Text(strings.confirmAction) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}

@Composable
private fun WarningBanner(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFFFEF3C7))
            .border(1.dp, StatusAmber, RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Text(text, style = MaterialTheme.typography.bodySmall, color = StatusAmber)
    }
}

@Composable
private fun SummaryRow(label: String, value: String, valueColor: Color = SlateInk) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = SlateMuted)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = valueColor)
    }
}
