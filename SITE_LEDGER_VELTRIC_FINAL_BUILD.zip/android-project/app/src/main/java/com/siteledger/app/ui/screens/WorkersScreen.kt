package com.siteledger.app.ui.screens

import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.siteledger.app.domain.model.AdvanceRecord
import com.siteledger.app.domain.model.AppLanguage
import com.siteledger.app.domain.model.AttendanceAuditEntry
import com.siteledger.app.domain.model.DailyAttendanceRecord
import com.siteledger.app.domain.model.DutyMultiplierConfig
import com.siteledger.app.domain.model.DutyType
import com.siteledger.app.domain.model.PaymentAllocation
import com.siteledger.app.domain.model.PaymentAuditEntry
import com.siteledger.app.domain.model.PaymentLedgerEntry
import com.siteledger.app.domain.model.PayrollPeriodRecord
import com.siteledger.app.domain.model.Site
import com.siteledger.app.domain.model.UserRole
import com.siteledger.app.domain.model.WorkCategory
import com.siteledger.app.domain.model.Worker
import com.siteledger.app.domain.model.WorkerSiteHistory
import com.siteledger.app.domain.service.WageCalculator
import com.siteledger.app.ui.components.SampleDataNoticeBanner
import com.siteledger.app.ui.components.WorkerAvatar
import com.siteledger.app.ui.components.WorkerPhotoPickerSection
import com.siteledger.app.ui.i18n.AppStrings
import com.siteledger.app.ui.theme.CrispWhite
import com.siteledger.app.ui.theme.SlateInk
import com.siteledger.app.ui.theme.SlateMuted
import com.siteledger.app.ui.theme.StatusGreen
import com.siteledger.app.ui.theme.StatusRed
import com.siteledger.app.ui.theme.SubtleBorderGrey

@Composable
fun WorkersScreen(
    strings: AppStrings,
    language: AppLanguage,
    activeSite: Site,
    allSites: List<Site>,
    workers: List<Worker>,
    allWorkersAcrossSites: List<Worker>,
    workerTransfers: List<WorkerSiteHistory>,
    activeRole: UserRole,
    dutyConfig: DutyMultiplierConfig,
    allAttendance: List<DailyAttendanceRecord>,
    attendanceAudits: List<AttendanceAuditEntry>,
    allPayments: List<PaymentLedgerEntry>,
    advances: List<AdvanceRecord>,
    paymentAllocations: List<PaymentAllocation>,
    paymentAudits: List<PaymentAuditEntry>,
    payrollPeriods: List<PayrollPeriodRecord>,
    initialProfileWorkerId: String? = null,
    onConsumeInitialProfileWorker: () -> Unit = {},
    onAddWorker: (
        fullName: String,
        workerId: String,
        phoneNumber: String,
        category: WorkCategory,
        joiningDateIso: String,
        dailyWage: Int,
        foodAllowance: Int,
        pendingPhotoUri: Uri?
    ) -> Unit,
    onEditWorker: (
        updatedWorker: Worker,
        pendingPhotoUri: Uri?,
        removeExistingPhoto: Boolean
    ) -> Unit,
    onTransferWorker: (workerId: String, toSiteId: String, newLocalCode: String, note: String) -> Unit,
    onSaveAttendance: (worker: Worker, dateIso: String, dutyType: DutyType, note: String, reason: String) -> Unit,
    onRecordPayment: (workerId: String, paymentDateIso: String, applicablePeriod: String, amount: Int, ref: String, note: String, token: String) -> Unit,
    onRecordAdvance: (workerId: String, advanceDateIso: String, amount: Int, ref: String, note: String, token: String) -> Unit,
    onAllocateAdvance: (advanceId: String, targetPeriod: String, amountToAllocate: Int, note: String) -> Unit,
    onVoidPayment: (txId: String, reason: String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf("ALL") }
    var sortBy by remember { mutableStateOf("NAME") }
    var showAddDialog by remember { mutableStateOf(false) }
    var profileWorkerId by remember { mutableStateOf<String?>(initialProfileWorkerId) }
    var editingWorker by remember { mutableStateOf<Worker?>(null) }

    LaunchedEffect(initialProfileWorkerId) {
        if (initialProfileWorkerId != null) {
            profileWorkerId = initialProfileWorkerId
            onConsumeInitialProfileWorker()
        }
    }

    val selectedProfileWorker = remember(profileWorkerId, allWorkersAcrossSites) {
        allWorkersAcrossSites.find { it.id == profileWorkerId }
    }

    if (selectedProfileWorker != null) {
        WorkerProfileScreen(
            strings = strings,
            language = language,
            worker = selectedProfileWorker,
            activeSite = allSites.find { it.id == selectedProfileWorker.siteId } ?: activeSite,
            allSites = allSites,
            allWorkersAcrossSites = allWorkersAcrossSites,
            workerTransfers = workerTransfers,
            activeRole = activeRole,
            dutyConfig = dutyConfig,
            allAttendance = allAttendance,
            attendanceAudits = attendanceAudits,
            allPayments = allPayments,
            advances = advances,
            paymentAllocations = paymentAllocations,
            paymentAudits = paymentAudits,
            payrollPeriods = payrollPeriods,
            onBack = { profileWorkerId = null },
            onEditWorkerClick = { editingWorker = selectedProfileWorker },
            onTransferWorker = onTransferWorker,
            onSaveAttendance = { dateIso, duty, note, reason ->
                onSaveAttendance(selectedProfileWorker, dateIso, duty, note, reason)
            },
            onRecordPayment = { payDate, periodIso, amount, ref, note, token ->
                onRecordPayment(selectedProfileWorker.id, payDate, periodIso, amount, ref, note, token)
            },
            onRecordAdvance = { advDate, amount, ref, note, token ->
                onRecordAdvance(selectedProfileWorker.id, advDate, amount, ref, note, token)
            },
            onAllocateAdvance = onAllocateAdvance,
            onVoidPayment = onVoidPayment
        )
    } else {
        val filteredWorkers = remember(workers, searchQuery, statusFilter, sortBy) {
            workers.filter { worker ->
                val matchesQuery = searchQuery.isBlank() ||
                    worker.fullNameEn.contains(searchQuery, ignoreCase = true) ||
                    worker.fullNameBn.contains(searchQuery, ignoreCase = true) ||
                    worker.localWorkerCode.contains(searchQuery, ignoreCase = true) ||
                    worker.id.contains(searchQuery, ignoreCase = true) ||
                    worker.phoneNumber.contains(searchQuery, ignoreCase = true)
                val matchesStatus = when (statusFilter) {
                    "ACTIVE" -> worker.isActive
                    "INACTIVE" -> !worker.isActive
                    else -> true
                }
                matchesQuery && matchesStatus
            }.let { list ->
                when (sortBy) {
                    "ID" -> list.sortedBy { it.localWorkerCode }
                    "CATEGORY" -> list.sortedBy { it.category.name }
                    else -> list.sortedBy { it.fullNameEn }
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { SampleDataNoticeBanner(noticeText = strings.sampleDataNotice) }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${strings.navWorkers} (${filteredWorkers.size})",
                            style = MaterialTheme.typography.titleLarge,
                            color = SlateInk
                        )
                        Text(
                            text = "${activeSite.siteCode} · ${activeSite.siteName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateMuted
                        )
                    }
                    if (activeRole != UserRole.ACCOUNTANT) {
                        Button(onClick = { showAddDialog = true }) {
                            Icon(Icons.Outlined.Add, contentDescription = null)
                            Text(text = " ${strings.addWorker}")
                        }
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(strings.searchWorkersPlaceholder) },
                    leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = statusFilter == "ALL", onClick = { statusFilter = "ALL" }, label = { Text(strings.allFilter) })
                    FilterChip(selected = statusFilter == "ACTIVE", onClick = { statusFilter = "ACTIVE" }, label = { Text(strings.activeStatus) })
                    FilterChip(selected = statusFilter == "INACTIVE", onClick = { statusFilter = "INACTIVE" }, label = { Text(strings.inactiveStatus) })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = sortBy == "NAME", onClick = { sortBy = "NAME" }, label = { Text("${strings.sortLabel}: ${strings.sortByName}") })
                    FilterChip(selected = sortBy == "ID", onClick = { sortBy = "ID" }, label = { Text(strings.sortById) })
                    FilterChip(selected = sortBy == "CATEGORY", onClick = { sortBy = "CATEGORY" }, label = { Text(strings.sortByCategory) })
                }
            }

            items(filteredWorkers, key = { it.id }) { worker ->
                val displayName = if (language == AppLanguage.BENGALI) worker.fullNameBn else worker.fullNameEn
                val categoryLabel = if (language == AppLanguage.BENGALI) worker.category.labelBn else worker.category.labelEn
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { profileWorkerId = worker.id },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CrispWhite),
                    border = BorderStroke(1.dp, SubtleBorderGrey)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        WorkerAvatar(name = displayName, photoPath = worker.photoPath, size = 48.dp)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(displayName, style = MaterialTheme.typography.titleMedium, color = SlateInk)
                            Text("${worker.localWorkerCode} · $categoryLabel", style = MaterialTheme.typography.bodySmall, color = SlateMuted)
                            Text(
                                text = "${strings.dailyWageLabel}: ৳${worker.dailyWage}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium,
                                color = SlateInk
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = if (worker.isActive) strings.activeStatus else strings.inactiveStatus,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = if (worker.isActive) StatusGreen else StatusRed
                            )
                            if (activeRole != UserRole.ACCOUNTANT) {
                                IconButton(onClick = { editingWorker = worker }) {
                                    Icon(Icons.Outlined.Edit, contentDescription = strings.editWorker, tint = SlateMuted)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        WorkerFormDialog(
            strings = strings,
            language = language,
            activeSite = activeSite,
            allWorkersInSite = workers,
            title = strings.addWorker,
            confirmLabel = strings.saveWorker,
            initialWorker = null,
            suggestedLocalCode = "SL-${101 + workers.size}",
            onDismiss = { showAddDialog = false },
            onConfirm = { name, localCode, phone, category, joinDate, _, wage, food, _, pickedUri, _ ->
                onAddWorker(name, localCode, phone, category, joinDate, wage, food, pickedUri)
                showAddDialog = false
            }
        )
    }

    editingWorker?.let { target ->
        WorkerFormDialog(
            strings = strings,
            language = language,
            activeSite = activeSite,
            allWorkersInSite = workers,
            title = strings.editWorker,
            confirmLabel = strings.saveChanges,
            initialWorker = target,
            suggestedLocalCode = target.localWorkerCode,
            onDismiss = { editingWorker = null },
            onConfirm = { name, localCode, phone, category, joinDate, leaveDate, wage, food, isActive, pickedUri, removePhoto ->
                val updated = target.copy(
                    localWorkerCode = localCode,
                    fullNameEn = name,
                    fullNameBn = if (language == AppLanguage.BENGALI) name else target.fullNameBn,
                    phoneNumber = phone,
                    category = category,
                    joiningDateIso = joinDate,
                    leavingDateIso = leaveDate?.ifBlank { null },
                    dailyWage = wage,
                    dailyFoodAllowance = food,
                    isActive = isActive
                )
                onEditWorker(updated, pickedUri, removePhoto)
                editingWorker = null
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun WorkerFormDialog(
    strings: AppStrings,
    language: AppLanguage,
    activeSite: Site,
    allWorkersInSite: List<Worker>,
    title: String,
    confirmLabel: String,
    initialWorker: Worker?,
    suggestedLocalCode: String,
    onDismiss: () -> Unit,
    onConfirm: (
        name: String,
        localWorkerCode: String,
        phone: String,
        category: WorkCategory,
        joiningDate: String,
        leavingDate: String?,
        wage: Int,
        food: Int,
        isActive: Boolean,
        pendingPhotoUri: Uri?,
        removeExistingPhoto: Boolean
    ) -> Unit
) {
    val isEdit = initialWorker != null
    var name by remember {
        mutableStateOf(
            when {
                initialWorker == null -> ""
                language == AppLanguage.BENGALI -> initialWorker.fullNameBn
                else -> initialWorker.fullNameEn
            }
        )
    }
    var localCode by remember { mutableStateOf(initialWorker?.localWorkerCode ?: suggestedLocalCode) }
    var phone by remember { mutableStateOf(initialWorker?.phoneNumber ?: "") }
    var selectedCategory by remember { mutableStateOf(initialWorker?.category ?: WorkCategory.MASON) }
    var joiningDate by remember { mutableStateOf(initialWorker?.joiningDateIso ?: "2026-11-15") }
    var leavingDate by remember { mutableStateOf(initialWorker?.leavingDateIso ?: "") }
    var dailyWage by remember { mutableStateOf((initialWorker?.dailyWage ?: 300).toString()) }
    var foodAllowance by remember { mutableStateOf((initialWorker?.dailyFoodAllowance ?: 0).toString()) }
    var isActive by remember { mutableStateOf(initialWorker?.isActive ?: true) }
    var pendingPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var photoRemoved by remember { mutableStateOf(false) }

    val duplicateCode = WageCalculator.isLocalWorkerCodeDuplicate(
        siteId = activeSite.id,
        localWorkerCode = localCode,
        excludeWorkerId = initialWorker?.id,
        workers = allWorkersInSite
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                WorkerPhotoPickerSection(
                    strings = strings,
                    existingPhotoPath = initialWorker?.photoPath,
                    pendingPhotoUri = pendingPhotoUri,
                    photoRemoved = photoRemoved,
                    onPhotoPicked = { uri ->
                        pendingPhotoUri = uri
                        photoRemoved = false
                    },
                    onRemovePhoto = {
                        pendingPhotoUri = null
                        photoRemoved = true
                    }
                )

                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(strings.fullNameLabel) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = localCode,
                    onValueChange = { localCode = it },
                    label = { Text("${strings.workerIdLabel} (${activeSite.siteCode})") },
                    isError = duplicateCode,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (duplicateCode) {
                    Text(strings.duplicateLocalCodeError, style = MaterialTheme.typography.bodySmall, color = StatusRed)
                }
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text(strings.phoneNumberLabel) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = joiningDate, onValueChange = { joiningDate = it }, label = { Text(strings.joiningDateLabel) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (isEdit) {
                    OutlinedTextField(value = leavingDate, onValueChange = { leavingDate = it }, label = { Text(strings.leavingDateLabel) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
                Text(strings.categoryLabel, style = MaterialTheme.typography.labelMedium, color = SlateMuted)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    WorkCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(if (language == AppLanguage.BENGALI) cat.labelBn else cat.labelEn) }
                        )
                    }
                }
                OutlinedTextField(value = dailyWage, onValueChange = { dailyWage = it.filter(Char::isDigit) }, label = { Text(strings.dailyWageLabel) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = foodAllowance, onValueChange = { foodAllowance = it.filter(Char::isDigit) }, label = { Text(strings.foodAllowanceLabel) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (isEdit) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (isActive) strings.activeStatus else strings.inactiveStatus, style = MaterialTheme.typography.bodyMedium, color = SlateInk)
                        Switch(checked = isActive, onCheckedChange = { isActive = it })
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
            }
        },
        confirmButton = {
            Button(
                enabled = name.isNotBlank() && localCode.isNotBlank() && !duplicateCode,
                onClick = {
                    onConfirm(
                        name.trim(),
                        localCode.trim(),
                        phone.trim(),
                        selectedCategory,
                        joiningDate.ifBlank { "2026-11-15" },
                        leavingDate.trim(),
                        dailyWage.toIntOrNull() ?: 300,
                        foodAllowance.toIntOrNull() ?: 0,
                        isActive,
                        pendingPhotoUri,
                        photoRemoved
                    )
                }
            ) { Text(confirmLabel) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(strings.cancel) }
        }
    )
}
