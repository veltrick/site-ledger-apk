package com.siteledger.app.ui.theme

import androidx.compose.ui.graphics.Color

val EngineeringBlue = Color(0xFF155EEF)
val DeepNavyBlue = Color(0xFF0A2E7A)
val SoftBlueTint = Color(0xFFEFF4FF)
val CrispWhite = Color(0xFFFFFFFF)
val CanvasGrey = Color(0xFFF4F6F9)
val SubtleBorderGrey = Color(0xFFE2E8F0)
val SlateInk = Color(0xFF0F172A)
val SlateMuted = Color(0xFF475569)
val SlateSubtle = Color(0xFF64748B)

val StatusGreen = Color(0xFF15803D)
val StatusGreenBg = Color(0xFFDCFCE7)
val StatusAmber = Color(0xFFB45309)
val StatusAmberBg = Color(0xFFFEF3C7)
val StatusRed = Color(0xFFB91C1C)
val StatusRedBg = Color(0xFFFEE2E2)
