package com.siteledger.app

import com.siteledger.app.data.backup.BackupRestoreException
import com.siteledger.app.data.backup.BackupSecurityEngine
import com.siteledger.app.data.backup.BackupSqliteBridge
import com.siteledger.app.data.backup.MiniJson
import com.siteledger.app.data.backup.RestoreFaultHooks
import com.siteledger.app.data.backup.SimulatedProcessCrashException
import com.siteledger.app.data.backup.SqliteInspectionResult
import com.siteledger.app.data.backup.WalCheckpointResult
import com.siteledger.app.data.local.SiteLedgerDatabaseContract
import com.siteledger.app.domain.model.BackupProgress
import com.siteledger.app.domain.model.BackupRecordCounts
import com.siteledger.app.domain.model.RestoreJournalStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

class BackupRestoreHardeningTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private data class SnapshotPayload(
        val schemaVersion: Int = 6,
        val tag: String = "LIVE",
        val sites: Int = 2,
        val workers: Int = 3,
        val attendanceRecords: Int = 10,
        val payments: Int = 2,
        val advances: Int = 1,
        val allocations: Int = 2,
        val expenses: Int = 2,
        val payrollPeriods: Int = 1,
        val workerPhotos: List<String> = emptyList(),
        val receiptImages: List<String> = emptyList(),
        val tables: List<String> = BackupSecurityEngine.requiredTablesForSchema(6)
    ) {
        fun encode(): ByteArray {
            val map = linkedMapOf<String, Any?>(
                "magic" to DB_MAGIC,
                "schemaVersion" to schemaVersion,
                "tag" to tag,
                "sites" to sites,
                "workers" to workers,
                "attendanceRecords" to attendanceRecords,
                "payments" to payments,
                "advances" to advances,
                "allocations" to allocations,
                "expenses" to expenses,
                "payrollPeriods" to payrollPeriods,
                "workerPhotos" to workerPhotos,
                "receiptImages" to receiptImages,
                "tables" to tables
            )
            return MiniJson.stringify(map).toByteArray(Charsets.UTF_8)
        }

        companion object {
            const val DB_MAGIC = "SITE_LEDGER_TEST_DB_V1"

            @Suppress("UNCHECKED_CAST")
            fun decode(bytes: ByteArray): SnapshotPayload? = runCatching {
                val parsed = MiniJson.parse(bytes.toString(Charsets.UTF_8)) as? Map<String, Any?> ?: return@runCatching null
                if (parsed["magic"] != DB_MAGIC) return@runCatching null
                SnapshotPayload(
                    schemaVersion = (parsed["schemaVersion"] as Number).toInt(),
                    tag = parsed["tag"] as String,
                    sites = (parsed["sites"] as Number).toInt(),
                    workers = (parsed["workers"] as Number).toInt(),
                    attendanceRecords = (parsed["attendanceRecords"] as Number).toInt(),
                    payments = (parsed["payments"] as Number).toInt(),
                    advances = (parsed["advances"] as Number).toInt(),
                    allocations = (parsed["allocations"] as Number).toInt(),
                    expenses = (parsed["expenses"] as Number).toInt(),
                    payrollPeriods = (parsed["payrollPeriods"] as Number).toInt(),
                    workerPhotos = (parsed["workerPhotos"] as? List<Any?>)?.map { it.toString() } ?: emptyList(),
                    receiptImages = (parsed["receiptImages"] as? List<Any?>)?.map { it.toString() } ?: emptyList(),
                    tables = (parsed["tables"] as? List<Any?>)?.map { it.toString() } ?: emptyList()
                )
            }.getOrNull()
        }
    }

    private class FakeBackupSqliteBridge(
        private val liveDbFile: File
    ) : BackupSqliteBridge {
        var walResult = WalCheckpointResult(success = true, busy = 0, logPages = 2, checkpointedPages = 2)
        var latestHistoryIso: String? = null
        var dbClosed = false

        override fun checkpointLiveDatabase(): WalCheckpointResult = walResult

        override fun copyLiveDatabaseTo(destFile: File): Boolean {
            if (!liveDbFile.exists()) return false
            liveDbFile.copyTo(destFile, overwrite = true)
            return true
        }

        override fun closeDatabaseBeforeSwap() {
            dbClosed = true
        }

        override fun reopenAndVerifyDatabase(expectedSchemaVersion: Int): SqliteInspectionResult {
            dbClosed = false
            val current = SnapshotPayload.decode(liveDbFile.readBytes())
                ?: return SqliteInspectionResult(
                    integrityOk = false,
                    missingTables = BackupSecurityEngine.requiredTablesForSchema(expectedSchemaVersion),
                    counts = BackupRecordCounts(),
                    referencedWorkerPhotos = emptyList(),
                    referencedReceiptImages = emptyList(),
                    errorMessage = "Corrupted SQLite database on reopen"
                )
            // Simulate SQLiteOpenHelper.onUpgrade automatically upgrading older restored DB schemas
            val upgraded = if (current.schemaVersion < expectedSchemaVersion) {
                val upgradedPayload = current.copy(
                    schemaVersion = expectedSchemaVersion,
                    sites = maxOf(1, current.sites),
                    tables = BackupSecurityEngine.requiredTablesForSchema(expectedSchemaVersion)
                )
                liveDbFile.writeBytes(upgradedPayload.encode())
                upgradedPayload
            } else {
                current
            }
            return toInspection(upgraded, expectedSchemaVersion)
        }

        override fun inspectDatabaseFile(dbFile: File, expectedSchemaVersion: Int): SqliteInspectionResult {
            if (!dbFile.exists()) {
                return SqliteInspectionResult(false, BackupSecurityEngine.requiredTablesForSchema(expectedSchemaVersion), BackupRecordCounts(), emptyList(), emptyList(), "DB missing")
            }
            val parsed = SnapshotPayload.decode(dbFile.readBytes())
                ?: return SqliteInspectionResult(
                    integrityOk = false,
                    missingTables = BackupSecurityEngine.requiredTablesForSchema(expectedSchemaVersion),
                    counts = BackupRecordCounts(),
                    referencedWorkerPhotos = emptyList(),
                    referencedReceiptImages = emptyList(),
                    errorMessage = "SQLite PRAGMA integrity_check failed (corrupted payload)"
                )
            return toInspection(parsed, expectedSchemaVersion)
        }

        override fun readLatestBackupTimestamp(): String? = latestHistoryIso

        private fun toInspection(p: SnapshotPayload, expectedSchemaVersion: Int): SqliteInspectionResult {
            val req = BackupSecurityEngine.requiredTablesForSchema(expectedSchemaVersion)
            val missing = req.filterNot { it in p.tables }
            return SqliteInspectionResult(
                integrityOk = true,
                missingTables = missing,
                counts = BackupRecordCounts(
                    sites = p.sites,
                    workers = p.workers,
                    attendanceRecords = p.attendanceRecords,
                    payments = p.payments,
                    advances = p.advances,
                    allocations = p.allocations,
                    expenses = p.expenses,
                    payrollPeriods = p.payrollPeriods,
                    workerPhotos = p.workerPhotos.size,
                    receiptImages = p.receiptImages.size
                ),
                referencedWorkerPhotos = p.workerPhotos,
                referencedReceiptImages = p.receiptImages
            )
        }
    }

    private data class Harness(
        val root: File,
        val liveDbFile: File,
        val photosDir: File,
        val receiptsDir: File,
        val safetyDir: File,
        val bridge: FakeBackupSqliteBridge,
        val engine: BackupSecurityEngine
    ) {
        fun recreateEngineAfterRestart(): BackupSecurityEngine =
            BackupSecurityEngine(
                workspaceRootDir = File(root, "backup_engine"),
                liveDbFile = liveDbFile,
                livePhotosDir = photosDir,
                liveReceiptsDir = receiptsDir,
                safetyBackupsDir = safetyDir,
                sqliteBridge = bridge
            )
    }

    private fun createHarness(
        initialPayload: SnapshotPayload = SnapshotPayload(
            tag = "ORIGINAL_LIVE",
            workerPhotos = listOf("worker_photos/w1.jpg"),
            receiptImages = listOf("receipt_images/r1.jpg")
        )
    ): Harness {
        val root = tempFolder.newFolder("env_${System.nanoTime()}")
        val liveDb = File(root, "databases/site_ledger_offline.db").apply {
            parentFile?.mkdirs()
            writeBytes(initialPayload.encode())
        }
        val photosDir = File(root, "files/worker_photos").apply { mkdirs() }
        val receiptsDir = File(root, "files/receipt_images").apply { mkdirs() }
        val safetyDir = File(root, "files/safety_backups").apply { mkdirs() }

        initialPayload.workerPhotos.forEach { rel ->
            File(photosDir, File(rel).name).writeText("JPEG_PHOTO_${initialPayload.tag}_$rel")
        }
        initialPayload.receiptImages.forEach { rel ->
            File(receiptsDir, File(rel).name).writeText("JPEG_RECEIPT_${initialPayload.tag}_$rel")
        }

        val bridge = FakeBackupSqliteBridge(liveDb)
        val engine = BackupSecurityEngine(
            workspaceRootDir = File(root, "backup_engine").apply { mkdirs() },
            liveDbFile = liveDb,
            livePhotosDir = photosDir,
            liveReceiptsDir = receiptsDir,
            safetyBackupsDir = safetyDir,
            sqliteBridge = bridge
        )
        return Harness(root, liveDb, photosDir, receiptsDir, safetyDir, bridge, engine)
    }

    private fun rewriteZipWithout(srcZip: File, dstZip: File, removeEntryNames: Set<String> = emptySet(), transformEntry: (String, ByteArray) -> ByteArray = { _, b -> b }) {
        ZipFile(srcZip).use { zf ->
            ZipOutputStream(FileOutputStream(dstZip)).use { zos ->
                val en = zf.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    if (e.isDirectory || e.name in removeEntryNames) continue
                    val raw = zf.getInputStream(e).readBytes()
                    val outBytes = transformEntry(e.name, raw)
                    zos.putNextEntry(ZipEntry(e.name))
                    zos.write(outBytes)
                    zos.closeEntry()
                }
            }
        }
    }

    @Test
    fun test01_validBackupCreationAndVerification() {
        val h = createHarness()
        val outZip = File(h.root, "valid_backup.zip")
        val stages = mutableListOf<BackupProgress>()
        val rec = h.engine.createBackupArchiveToFile(outZip, onProgress = { stages.add(it) }).getOrThrow()

        assertTrue(outZip.exists())
        assertEquals(BackupSecurityEngine.CURRENT_BACKUP_FORMAT_VERSION, rec.formatVersion)
        assertEquals(6, rec.schemaVersion)
        assertEquals(3, rec.counts.workers)
        assertEquals(1, rec.counts.workerPhotos)
        assertEquals(1, rec.counts.receiptImages)
        assertEquals(BackupSecurityEngine.sha256File(outZip), rec.checksumSha256)
        assertTrue(stages.any { it.stageLabel.contains("Backup creation started") })

        val valRes = h.engine.validateArchiveFile(outZip)
        assertTrue(valRes.errors.joinToString(), valRes.isValid)
        assertTrue(valRes.checksumVerified)
        assertTrue(valRes.sqliteIntegrityOk)
        assertTrue(valRes.countsMatched)
        assertTrue(valRes.mediaIntegrityOk)
        assertEquals(0, valRes.missingMediaCount)
    }

    @Test
    fun test02_missingMandatoryZipEntriesRejected() {
        val h = createHarness()
        val baseZip = File(h.root, "base.zip")
        h.engine.createBackupArchiveToFile(baseZip).getOrThrow()

        val noManifest = File(h.root, "no_manifest.zip")
        rewriteZipWithout(baseZip, noManifest, setOf("backup_manifest.json"))
        val res1 = h.engine.validateArchiveFile(noManifest)
        assertFalse(res1.isValid)
        assertTrue(res1.errors.any { it.contains("backup_manifest.json") })

        val noDb = File(h.root, "no_db.zip")
        rewriteZipWithout(baseZip, noDb, setOf("database/${SiteLedgerDatabaseContract.DATABASE_NAME}"))
        val res2 = h.engine.validateArchiveFile(noDb)
        assertFalse(res2.isValid)
        assertFalse(res2.sqliteIntegrityOk)

        val noSummary = File(h.root, "no_summary.zip")
        rewriteZipWithout(baseZip, noSummary, setOf("metadata/schema_summary.json"))
        val res3 = h.engine.validateArchiveFile(noSummary)
        assertFalse(res3.isValid)
        assertTrue(res3.errors.any { it.contains("schema_summary.json") })
    }

    @Test
    fun test03_invalidOrMalformedManifestRejected() {
        val h = createHarness()
        val baseZip = File(h.root, "base.zip")
        h.engine.createBackupArchiveToFile(baseZip).getOrThrow()

        val brokenJson = File(h.root, "broken_json.zip")
        rewriteZipWithout(baseZip, brokenJson) { name, bytes ->
            if (name == "backup_manifest.json") "{ not valid json".toByteArray() else bytes
        }
        val res1 = h.engine.validateArchiveFile(brokenJson)
        assertFalse(res1.isValid)
        assertTrue(res1.errors.any { it.contains("Invalid backup_manifest.json") })

        val wrongApp = File(h.root, "wrong_app.zip")
        rewriteZipWithout(baseZip, wrongApp) { name, bytes ->
            if (name == "backup_manifest.json") {
                bytes.toString(Charsets.UTF_8).replace("\"SITE LEDGER\"", "\"OTHER APP\"").toByteArray()
            } else bytes
        }
        val res2 = h.engine.validateArchiveFile(wrongApp)
        assertFalse(res2.isValid)
        assertTrue(res2.errors.any { it.contains("application signature") })
    }

    @Test
    fun test04_unsupportedBackupFormatAndSchemaRejected() {
        val h = createHarness()
        val baseZip = File(h.root, "base.zip")
        h.engine.createBackupArchiveToFile(baseZip).getOrThrow()

        val futureFmt = File(h.root, "future_format.zip")
        rewriteZipWithout(baseZip, futureFmt) { name, bytes ->
            if (name == "backup_manifest.json") {
                bytes.toString(Charsets.UTF_8).replace("\"formatVersion\": 3", "\"formatVersion\": 99").toByteArray()
            } else bytes
        }
        val resFmt = h.engine.validateArchiveFile(futureFmt)
        assertFalse(resFmt.isValid)
        assertTrue(resFmt.errors.any { it.contains("Unsupported backup format version") })

        val futureSchema = File(h.root, "future_schema.zip")
        rewriteZipWithout(baseZip, futureSchema) { name, bytes ->
            if (name == "backup_manifest.json") {
                bytes.toString(Charsets.UTF_8).replace("\"schemaVersion\": 6", "\"schemaVersion\": 42").toByteArray()
            } else bytes
        }
        val resSch = h.engine.validateArchiveFile(futureSchema)
        assertFalse(resSch.isValid)
        assertTrue(resSch.errors.any { it.contains("Unsupported SQLite schema version") })
    }

    @Test
    fun test05_incorrectSha256ChecksumRejected() {
        val h = createHarness()
        val baseZip = File(h.root, "base.zip")
        h.engine.createBackupArchiveToFile(baseZip).getOrThrow()

        val tamperedPhoto = File(h.root, "tampered_photo.zip")
        rewriteZipWithout(baseZip, tamperedPhoto) { name, bytes ->
            if (name == "worker_photos/w1.jpg") "TAMPERED_BYTES".toByteArray() else bytes
        }
        val res = h.engine.validateArchiveFile(tamperedPhoto)
        assertFalse(res.isValid)
        assertFalse(res.checksumVerified)
        assertTrue(res.errors.any { it.contains("SHA-256 checksum mismatch: worker_photos/w1.jpg") })
    }

    @Test
    fun test06_corruptedSqliteDatabaseRejected() {
        val h = createHarness()
        val baseZip = File(h.root, "base.zip")
        h.engine.createBackupArchiveToFile(baseZip).getOrThrow()

        val corruptDbBytes = "CORRUPT_SQLITE_GARBAGE".toByteArray()
        val corruptSha = BackupSecurityEngine.sha256Bytes(corruptDbBytes)
        val corruptedZip = File(h.root, "corrupted_db.zip")

        // Even if an attacker updates manifest checksum for corrupted DB, SQLite PRAGMA check rejects it!
        val dbKey = "database/${SiteLedgerDatabaseContract.DATABASE_NAME}"
        var originalDbSha = ""
        ZipFile(baseZip).use { zf ->
            originalDbSha = BackupSecurityEngine.sha256Stream(zf.getInputStream(zf.getEntry(dbKey)))
        }
        rewriteZipWithout(baseZip, corruptedZip) { name, bytes ->
            when (name) {
                dbKey -> corruptDbBytes
                "backup_manifest.json" -> bytes.toString(Charsets.UTF_8).replace(originalDbSha, corruptSha).toByteArray()
                else -> bytes
            }
        }
        val res = h.engine.validateArchiveFile(corruptedZip)
        assertFalse(res.isValid)
        assertFalse(res.sqliteIntegrityOk)
        assertTrue(res.errors.any { it.contains("integrity_check") })
    }

    @Test
    fun test07_missingWorkerPhotoRejectedClearly() {
        val h = createHarness()
        val baseZip = File(h.root, "base.zip")
        h.engine.createBackupArchiveToFile(baseZip).getOrThrow()

        val missingPhotoZip = File(h.root, "missing_worker_photo.zip")
        rewriteZipWithout(baseZip, missingPhotoZip, setOf("worker_photos/w1.jpg"))

        val res = h.engine.validateArchiveFile(missingPhotoZip)
        assertFalse(res.isValid)
        assertFalse(res.mediaIntegrityOk)
        assertEquals(1, res.missingMediaCount)
        assertTrue(res.missingMediaFiles.contains("worker_photos/w1.jpg"))
        assertTrue(res.errors.any { it.contains("worker_photos/w1.jpg") })
    }

    @Test
    fun test08_missingExpenseReceiptRejectedClearly() {
        val h = createHarness()
        val baseZip = File(h.root, "base.zip")
        h.engine.createBackupArchiveToFile(baseZip).getOrThrow()

        val missingReceiptZip = File(h.root, "missing_receipt.zip")
        rewriteZipWithout(baseZip, missingReceiptZip, setOf("receipt_images/r1.jpg"))

        val res = h.engine.validateArchiveFile(missingReceiptZip)
        assertFalse(res.isValid)
        assertFalse(res.mediaIntegrityOk)
        assertEquals(1, res.missingMediaCount)
        assertTrue(res.missingMediaFiles.contains("receipt_images/r1.jpg"))
    }

    @Test
    fun test09_incorrectRecordCountsRejected() {
        val h = createHarness()
        val baseZip = File(h.root, "base.zip")
        h.engine.createBackupArchiveToFile(baseZip).getOrThrow()

        val badCountsZip = File(h.root, "bad_counts.zip")
        rewriteZipWithout(baseZip, badCountsZip) { name, bytes ->
            if (name == "backup_manifest.json") {
                bytes.toString(Charsets.UTF_8).replace("\"workers\": 3", "\"workers\": 99").toByteArray()
            } else bytes
        }
        val res = h.engine.validateArchiveFile(badCountsZip)
        assertFalse(res.isValid)
        assertFalse(res.countsMatched)
        assertTrue(res.errors.any { it.contains("Record count mismatch for workers") })
    }

    @Test
    fun test10_failedWalCheckpointAbortsBackupCreation() {
        val h = createHarness()
        h.bridge.walResult = WalCheckpointResult(
            success = false,
            busy = 1,
            logPages = 14,
            checkpointedPages = 6,
            errorMessage = "WAL checkpoint blocked (busy=1)"
        )
        val outZip = File(h.root, "blocked_wal.zip")
        val res = h.engine.createBackupArchiveToFile(outZip)
        assertTrue(res.isFailure)
        assertFalse(outZip.exists())
        assertTrue(res.exceptionOrNull()?.message?.contains("WAL") == true)
    }

    @Test
    fun test11_restoreValidationFailurePreservesLiveDataAndSkipsSafetyBackup() {
        val h = createHarness()
        val badZip = File(h.root, "invalid.zip").apply { writeText("NOT A ZIP") }
        val beforeLiveTag = SnapshotPayload.decode(h.liveDbFile.readBytes())!!.tag

        var caught: BackupRestoreException? = null
        try {
            h.engine.executeStagedRestoreFromFile(badZip)
        } catch (ex: BackupRestoreException) {
            caught = ex
        }
        assertNotNull(caught)
        assertEquals(BackupSecurityEngine.STAGE_2_VALIDATION, caught!!.failedStage)
        assertEquals(beforeLiveTag, SnapshotPayload.decode(h.liveDbFile.readBytes())!!.tag)
        assertEquals(0, h.safetyDir.listFiles()?.size ?: 0)
    }

    @Test
    fun test12_restoreRollbackRestoresOriginalDbMediaAndKeepsSafetyBackup() {
        // Create valid restore source from a separate environment
        val sourceHarness = createHarness(
            SnapshotPayload(
                tag = "INCOMING_NEW",
                workers = 8,
                workerPhotos = listOf("worker_photos/new_w.jpg"),
                receiptImages = listOf("receipt_images/new_r.jpg")
            )
        )
        val restoreZip = File(sourceHarness.root, "incoming.zip")
        sourceHarness.engine.createBackupArchiveToFile(restoreZip).getOrThrow()

        // Target harness holds ORIGINAL_LIVE data
        val liveHarness = createHarness(
            SnapshotPayload(
                tag = "ORIGINAL_LIVE",
                workers = 3,
                workerPhotos = listOf("worker_photos/orig_w.jpg"),
                receiptImages = listOf("receipt_images/orig_r.jpg")
            )
        )

        var caught: BackupRestoreException? = null
        try {
            liveHarness.engine.executeStagedRestoreFromFile(
                zipFile = restoreZip,
                faultHooks = RestoreFaultHooks(failAtStage = BackupSecurityEngine.STAGE_7_LIVE_REPLACEMENT)
            )
        } catch (ex: BackupRestoreException) {
            caught = ex
        }

        assertNotNull(caught)
        assertEquals(BackupSecurityEngine.STAGE_7_LIVE_REPLACEMENT, caught!!.failedStage)
        assertTrue(caught.recoveryAttempted)
        assertTrue(caught.recoverySucceeded)
        assertNotNull(caught.safetyBackupPath)
        assertTrue(File(caught.safetyBackupPath!!).exists())

        // Original live DB and media preserved identically!
        assertEquals("ORIGINAL_LIVE", SnapshotPayload.decode(liveHarness.liveDbFile.readBytes())!!.tag)
        assertTrue(File(liveHarness.photosDir, "orig_w.jpg").exists())
        assertTrue(File(liveHarness.receiptsDir, "orig_r.jpg").exists())
        assertFalse(File(liveHarness.photosDir, "new_w.jpg").exists())
    }

    @Test
    fun test13_and_test14_interruptedRestoreCrashRecoveryAndIdempotentReExecution() {
        val sourceHarness = createHarness(
            SnapshotPayload(
                tag = "INCOMING_NEW",
                workers = 9,
                workerPhotos = listOf("worker_photos/new_w.jpg"),
                receiptImages = listOf("receipt_images/new_r.jpg")
            )
        )
        val restoreZip = File(sourceHarness.root, "incoming.zip")
        sourceHarness.engine.createBackupArchiveToFile(restoreZip).getOrThrow()

        val liveHarness = createHarness(
            SnapshotPayload(
                tag = "ORIGINAL_LIVE",
                workers = 3,
                workerPhotos = listOf("worker_photos/orig_w.jpg"),
                receiptImages = listOf("receipt_images/orig_r.jpg")
            )
        )

        var crashed = false
        try {
            liveHarness.engine.executeStagedRestoreFromFile(
                zipFile = restoreZip,
                faultHooks = RestoreFaultHooks(simulateCrashAtJournalStatus = RestoreJournalStatus.SWAPPING)
            )
        } catch (_: SimulatedProcessCrashException) {
            crashed = true
        }
        assertTrue(crashed)
        // Confirm mid-swap partial corruption happened before simulated crash:
        assertEquals("INCOMING_NEW", SnapshotPayload.decode(liveHarness.liveDbFile.readBytes())!!.tag)
        assertFalse(File(liveHarness.photosDir, "orig_w.jpg").exists())

        // Simulate app cold-restart -> run startup crash recovery
        val restartedEngine1 = liveHarness.recreateEngineAfterRestart()
        val report1 = restartedEngine1.recoverInterruptedRestoreIfNeeded()
        assertTrue(report1.recoveryNeeded)
        assertTrue(report1.recoveryAttempted)
        assertTrue(report1.recoverySucceeded)
        assertFalse(report1.stillRequiresManualRecovery)
        assertNotNull(report1.safetyBackupPath)
        assertTrue(File(report1.safetyBackupPath!!).exists())

        // Verify original valid live database and original photos are restored
        assertEquals("ORIGINAL_LIVE", SnapshotPayload.decode(liveHarness.liveDbFile.readBytes())!!.tag)
        assertTrue(File(liveHarness.photosDir, "orig_w.jpg").exists())
        assertTrue(File(liveHarness.receiptsDir, "orig_r.jpg").exists())

        // Test 14: Repeated recovery execution is 100% idempotent and preserves data
        val restartedEngine2 = liveHarness.recreateEngineAfterRestart()
        val report2 = restartedEngine2.recoverInterruptedRestoreIfNeeded()
        assertFalse(report2.recoveryNeeded)
        assertFalse(report2.recoveryAttempted)
        assertTrue(report2.recoverySucceeded)
        assertEquals("ORIGINAL_LIVE", SnapshotPayload.decode(liveHarness.liveDbFile.readBytes())!!.tag)
        assertTrue(File(report1.safetyBackupPath!!).exists())
    }

    @Test
    fun test15_olderSupportedBackupFormatV1AndV2CompatibilityRestoreSafely() {
        // Build an older Format v1 (schema v4) backup archive
        val v1SourceDir = tempFolder.newFolder("old_v1_src")
        val v1Payload = SnapshotPayload(
            schemaVersion = 4,
            tag = "LEGACY_V1_SCHEMA4",
            sites = 0,
            workers = 4,
            attendanceRecords = 12,
            payments = 5,
            advances = 1,
            allocations = 5,
            expenses = 0,
            payrollPeriods = 1,
            workerPhotos = listOf("worker_photos/legacy_w.jpg"),
            receiptImages = emptyList(),
            tables = BackupSecurityEngine.requiredTablesForSchema(4)
        )
        val dbBytes = v1Payload.encode()
        val photoBytes = "LEGACY_V1_JPEG".toByteArray()
        val dbKey = "database/${SiteLedgerDatabaseContract.DATABASE_NAME}"
        val photoKey = "worker_photos/legacy_w.jpg"

        val v1Manifest = MiniJson.stringify(
            linkedMapOf(
                "appName" to "SITE LEDGER",
                "appVersion" to "2.0.0",
                "formatVersion" to 1,
                "schemaVersion" to 4,
                "createdAtIso" to "2026-09-01T10:00:00",
                "counts" to linkedMapOf(
                    "workers" to 4,
                    "attendanceRecords" to 12,
                    "payments" to 5,
                    "advances" to 1,
                    "allocations" to 5,
                    "payrollPeriods" to 1,
                    "workerPhotos" to 1
                ),
                "checksums" to linkedMapOf(
                    dbKey to BackupSecurityEngine.sha256Bytes(dbBytes),
                    photoKey to BackupSecurityEngine.sha256Bytes(photoBytes)
                )
            )
        ).toByteArray(Charsets.UTF_8)

        val v1Zip = File(v1SourceDir, "legacy_v1.zip")
        ZipOutputStream(FileOutputStream(v1Zip)).use { zos ->
            zos.putNextEntry(ZipEntry("backup_manifest.json"))
            zos.write(v1Manifest)
            zos.closeEntry()
            zos.putNextEntry(ZipEntry(dbKey))
            zos.write(dbBytes)
            zos.closeEntry()
            zos.putNextEntry(ZipEntry(photoKey))
            zos.write(photoBytes)
            zos.closeEntry()
        }

        val targetHarness = createHarness()
        targetHarness.bridge.latestHistoryIso = "2026-11-15T12:00:00"

        val validation = targetHarness.engine.validateArchiveFile(v1Zip)
        assertTrue(validation.errors.joinToString(), validation.isValid)
        assertEquals(1, validation.formatVersion)
        assertEquals(4, validation.schemaVersion)
        assertTrue(validation.isOlderThanCurrentData)

        val restored = targetHarness.engine.executeStagedRestoreFromFile(v1Zip)
        assertTrue(restored.isValid)
        val liveAfter = SnapshotPayload.decode(targetHarness.liveDbFile.readBytes())!!
        assertEquals("LEGACY_V1_SCHEMA4", liveAfter.tag)
        assertEquals(6, liveAfter.schemaVersion) // Upgraded on reopen cleanly!
        assertTrue(liveAfter.sites >= 1)
        assertTrue(File(targetHarness.photosDir, "legacy_w.jpg").exists())
    }
}
