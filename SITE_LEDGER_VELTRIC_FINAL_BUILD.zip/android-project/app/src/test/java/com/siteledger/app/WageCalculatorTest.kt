package com.siteledger.app

import com.siteledger.app.data.repository.InMemorySampleSiteLedgerRepository
import com.siteledger.app.domain.model.AdvanceRecord
import com.siteledger.app.domain.model.DailyAttendanceRecord
import com.siteledger.app.domain.model.DutyMultiplierConfig
import com.siteledger.app.domain.model.DutyType
import com.siteledger.app.domain.model.PaymentAllocation
import com.siteledger.app.domain.model.PaymentLedgerEntry
import com.siteledger.app.domain.model.PayrollPeriodRecord
import com.siteledger.app.domain.model.PayrollPeriodStatus
import com.siteledger.app.domain.model.UserRole
import com.siteledger.app.domain.model.WorkCategory
import com.siteledger.app.domain.model.Worker
import com.siteledger.app.domain.service.WageCalculator
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class WageCalculatorTest {

    private val worker300 = Worker(
        id = "SL-201",
        fullNameEn = "Test Worker",
        fullNameBn = "টেস্ট কর্মী",
        category = WorkCategory.HELPER,
        dailyWage = 300,
        photoPath = "worker_photos/sl_201.jpg"
    )

    private val worker650 = Worker(
        id = "SL-202",
        fullNameEn = "Mason Two",
        fullNameBn = "মিস্ত্রি দুই",
        category = WorkCategory.MASON,
        dailyWage = 650
    )

    private val defaultConfig = DutyMultiplierConfig()

    @Test
    fun scenario01_singleWorkerMonthlyAttendanceCountsAndUnits() {
        val attendance = listOf(
            DailyAttendanceRecord("2026-11-01", worker300.id, DutyType.HALF_DUTY, 300, 0.5, 150),
            DailyAttendanceRecord("2026-11-02", worker300.id, DutyType.FULL_DUTY, 300, 1.0, 300),
            DailyAttendanceRecord("2026-11-03", worker300.id, DutyType.ONE_AND_HALF_DUTY, 300, 1.5, 450),
            DailyAttendanceRecord("2026-11-04", worker300.id, DutyType.DOUBLE_DUTY, 300, 2.0, 600),
            DailyAttendanceRecord("2026-11-05", worker300.id, DutyType.TWO_AND_HALF_DUTY, 300, 2.5, 750),
            DailyAttendanceRecord("2026-11-06", worker300.id, DutyType.TRIPLE_DUTY, 300, 3.0, 900),
            DailyAttendanceRecord("2026-11-07", worker300.id, DutyType.ABSENT, 300, 0.0, 0),
            DailyAttendanceRecord("2026-11-08", worker300.id, DutyType.LEAVE, 300, 0.0, 0)
        )
        val summary = WageCalculator.computeWorkerMonthlySummary(
            worker = worker300,
            year = 2026,
            month = 11,
            allAttendance = attendance,
            allAllocations = emptyList()
        )
        assertEquals(1, summary.halfDutyCount)
        assertEquals(1, summary.fullDutyCount)
        assertEquals(1, summary.oneAndHalfDutyCount)
        assertEquals(1, summary.doubleDutyCount)
        assertEquals(1, summary.twoAndHalfDutyCount)
        assertEquals(1, summary.tripleDutyCount)
        assertEquals(1, summary.absentCount)
        assertEquals(1, summary.leaveCount)
        assertEquals(10.5, summary.totalDutyUnits, 0.0001)
        assertEquals(3150, summary.totalEarnedAmount)
    }

    @Test
    fun scenario02_multiMonthPayrollHistoryCollectsChronologicalPeriods() {
        val attendance = listOf(
            DailyAttendanceRecord("2026-09-10", worker300.id, DutyType.FULL_DUTY, 300, 1.0, 300),
            DailyAttendanceRecord("2026-10-12", worker300.id, DutyType.FULL_DUTY, 300, 1.0, 300),
            DailyAttendanceRecord("2026-11-04", worker300.id, DutyType.FULL_DUTY, 300, 1.0, 300)
        )
        val periods = WageCalculator.collectWorkerPayrollPeriods(
            worker = worker300,
            allAttendance = attendance,
            allAllocations = emptyList(),
            allPayments = emptyList()
        )
        assertEquals(listOf(2026 to 11, 2026 to 10, 2026 to 9), periods)
    }

    @Test
    fun scenario03_allEightDutyTypesExactIntegerTakaAndLabels() {
        assertEquals(0.5, defaultConfig.multiplierFor(DutyType.HALF_DUTY), 0.0001)
        assertEquals(1.0, defaultConfig.multiplierFor(DutyType.FULL_DUTY), 0.0001)
        assertEquals(1.5, defaultConfig.multiplierFor(DutyType.ONE_AND_HALF_DUTY), 0.0001)
        assertEquals(2.0, defaultConfig.multiplierFor(DutyType.DOUBLE_DUTY), 0.0001)
        assertEquals(2.5, defaultConfig.multiplierFor(DutyType.TWO_AND_HALF_DUTY), 0.0001)
        assertEquals(3.0, defaultConfig.multiplierFor(DutyType.TRIPLE_DUTY), 0.0001)
        assertEquals(0.0, defaultConfig.multiplierFor(DutyType.ABSENT), 0.0001)
        assertEquals(0.0, defaultConfig.multiplierFor(DutyType.LEAVE), 0.0001)

        assertEquals(150, WageCalculator.calculateDailyEarnedTaka(300, defaultConfig.multiplierFor(DutyType.HALF_DUTY)))
        assertEquals(300, WageCalculator.calculateDailyEarnedTaka(300, defaultConfig.multiplierFor(DutyType.FULL_DUTY)))
        assertEquals(450, WageCalculator.calculateDailyEarnedTaka(300, defaultConfig.multiplierFor(DutyType.ONE_AND_HALF_DUTY)))
        assertEquals(600, WageCalculator.calculateDailyEarnedTaka(300, defaultConfig.multiplierFor(DutyType.DOUBLE_DUTY)))
        assertEquals(750, WageCalculator.calculateDailyEarnedTaka(300, defaultConfig.multiplierFor(DutyType.TWO_AND_HALF_DUTY)))
        assertEquals(900, WageCalculator.calculateDailyEarnedTaka(300, defaultConfig.multiplierFor(DutyType.TRIPLE_DUTY)))
        assertEquals(0, WageCalculator.calculateDailyEarnedTaka(300, defaultConfig.multiplierFor(DutyType.ABSENT)))
        assertEquals(0, WageCalculator.calculateDailyEarnedTaka(300, defaultConfig.multiplierFor(DutyType.LEAVE)))

        assertEquals("হাফ হাজিরা", DutyType.HALF_DUTY.labelBn)
        assertEquals("এক হাজিরা", DutyType.FULL_DUTY.labelBn)
        assertEquals("দেড় হাজিরা", DutyType.ONE_AND_HALF_DUTY.labelBn)
        assertEquals("দুই হাজিরা", DutyType.DOUBLE_DUTY.labelBn)
        assertEquals("আড়াই হাজিরা", DutyType.TWO_AND_HALF_DUTY.labelBn)
        assertEquals("তিন হাজিরা", DutyType.TRIPLE_DUTY.labelBn)
        assertEquals("অনুপস্থিত", DutyType.ABSENT.labelBn)
        assertEquals("ছুটি", DutyType.LEAVE.labelBn)
    }

    @Test
    fun scenario04_partialAndMultiplePaymentsAllocatedInOneMonth() {
        val attendance = listOf(
            DailyAttendanceRecord("2026-11-01", worker300.id, DutyType.FULL_DUTY, 300, 1.0, 300),
            DailyAttendanceRecord("2026-11-02", worker300.id, DutyType.TRIPLE_DUTY, 300, 3.0, 900)
        )
        val allocations = listOf(
            PaymentAllocation("AL-1", "PAYMENT", "TXN-1", worker300.id, "2026-11", 400, "2026-11-05", UserRole.ADMIN),
            PaymentAllocation("AL-2", "PAYMENT", "TXN-2", worker300.id, "2026-11", 350, "2026-11-10", UserRole.ADMIN)
        )
        val summary = WageCalculator.computeWorkerMonthlySummary(worker300, 2026, 11, attendance, allocations)
        assertEquals(1200, summary.totalEarnedAmount)
        assertEquals(750, summary.totalPaidAmount)
        assertEquals(450, summary.outstandingBalance)
    }

    @Test
    fun scenario05_advancePaymentNotSilentlyDeductedUntilExplicitlyAllocated() {
        val attendance = listOf(
            DailyAttendanceRecord("2026-11-01", worker300.id, DutyType.FULL_DUTY, 300, 1.0, 300),
            DailyAttendanceRecord("2026-11-02", worker300.id, DutyType.FULL_DUTY, 300, 1.0, 300)
        )
        val advance = AdvanceRecord("ADV-1", worker300.id, "2026-11-03", 500, "CASH", "Advance")
        val beforeAlloc = WageCalculator.computeWorkerMonthlySummary(worker300, 2026, 11, attendance, emptyList())
        assertEquals(0, beforeAlloc.totalPaidAmount)
        assertEquals(500, WageCalculator.computeUnallocatedAdvanceBalance(worker300.id, listOf(advance), emptyList()))

        val explicitAlloc = PaymentAllocation("AL-ADV-1", "ADVANCE", "ADV-1", worker300.id, "2026-11", 200, "2026-11-06", UserRole.ADMIN)
        val afterAlloc = WageCalculator.computeWorkerMonthlySummary(worker300, 2026, 11, attendance, listOf(explicitAlloc))
        assertEquals(200, afterAlloc.totalPaidAmount)
        assertEquals(200, afterAlloc.advanceAllocatedAmount)
        assertEquals(400, afterAlloc.outstandingBalance)
        assertEquals(300, WageCalculator.computeUnallocatedAdvanceBalance(worker300.id, listOf(advance), listOf(explicitAlloc)))
    }

    @Test
    fun scenario06_and_07_previousVsCurrentMonthIsolationAndProjection() {
        val attendance = listOf(
            DailyAttendanceRecord("2026-10-05", worker300.id, DutyType.FULL_DUTY, 300, 1.0, 300),
            DailyAttendanceRecord("2026-11-01", worker300.id, DutyType.FULL_DUTY, 300, 1.0, 300)
        )
        val oct = WageCalculator.computeWorkerMonthlySummary(worker300, 2026, 10, attendance, emptyList())
        val nov = WageCalculator.computeWorkerMonthlySummary(worker300, 2026, 11, attendance, emptyList())
        assertEquals(300, oct.totalEarnedAmount)
        assertEquals(300, nov.totalEarnedAmount)

        val projection = WageCalculator.computeCurrentMonthProjection(nov, asOfDay = 15)
        assertEquals(300, projection.earnedToDate)
        assertTrue(projection.estimatedMonthEndSalary >= projection.earnedToDate)
    }

    @Test
    fun scenario08_historicalWageChangeDoesNotMutatePastMonths() {
        val historical = listOf(
            DailyAttendanceRecord("2026-09-12", worker300.id, DutyType.FULL_DUTY, 300, 1.0, 300)
        )
        val updatedWorker = worker300.copy(dailyWage = 900)
        val septSummary = WageCalculator.computeWorkerMonthlySummary(updatedWorker, 2026, 9, historical, emptyList())
        assertEquals(300, septSummary.totalEarnedAmount)
    }

    @Test
    fun scenario09_masterSpreadsheet500WorkersMatchesSumOfIndividualProfiles() {
        val workers = (1..500).map { idx ->
            Worker(
                id = "SL-${1000 + idx}",
                fullNameEn = "Worker $idx",
                fullNameBn = "কর্মী $idx",
                category = WorkCategory.HELPER,
                dailyWage = 400
            )
        }
        val attendance = workers.map { w ->
            DailyAttendanceRecord("2026-11-10", w.id, DutyType.FULL_DUTY, 400, 1.0, 400)
        }
        val allocations = workers.take(100).map { w ->
            PaymentAllocation("AL-${w.id}", "PAYMENT", "TX-${w.id}", w.id, "2026-11", 250, "2026-11-12", UserRole.ADMIN)
        }
        val summaries = workers.map { w ->
            WageCalculator.computeWorkerMonthlySummary(w, 2026, 11, attendance, allocations)
        }
        val totals = WageCalculator.computeSpreadsheetTotals(summaries)
        assertEquals(500, totals.totalWorkers)
        assertEquals(200000, totals.totalEarnedSalary)
        assertEquals(25000, totals.totalPaidSalary)
        assertEquals(175000, totals.totalOutstandingSalary)
        assertEquals(summaries.sumOf { it.totalEarnedAmount }, totals.totalEarnedSalary)
        assertEquals(summaries.sumOf { it.totalPaidAmount }, totals.totalPaidSalary)
        assertEquals(summaries.sumOf { it.outstandingBalance }, totals.totalOutstandingSalary)
    }

    @Test
    fun scenario10_payrollPeriodFinalizationBlocksEditsUntilAdminReopens() = runBlocking {
        val repo = InMemorySampleSiteLedgerRepository()
        val targetWorker = repo.workers.value.first()
        val beforeEarned = repo.attendanceRecords.value
            .find { it.workerId == targetWorker.id && it.dateIso == "2026-09-25" }?.earnedAmount

        assertEquals(PayrollPeriodStatus.FINALIZED, repo.payrollPeriods.value.find { it.siteId == "SITE-MAIN" && it.periodIso == "2026-09" }?.status)
        assertTrue(repo.isPeriodFinalized("SITE-MAIN", "2026-09"))

        // Ordinary edit to finalized 2026-09 is blocked
        repo.recordAttendance("SITE-MAIN", "2026-09-25", targetWorker, DutyType.TRIPLE_DUTY, "Should fail", UserRole.ADMIN, "Blocked")
        val afterBlockedEdit = repo.attendanceRecords.value
            .find { it.workerId == targetWorker.id && it.dateIso == "2026-09-25" }?.earnedAmount
        assertEquals(beforeEarned, afterBlockedEdit)

        // Admin reopens period -> edit succeeds
        repo.reopenPayrollPeriod("SITE-MAIN", "2026-09", UserRole.ADMIN, "Correction required")
        assertFalse(repo.isPeriodFinalized("SITE-MAIN", "2026-09"))
        repo.recordAttendance("SITE-MAIN", "2026-09-25", targetWorker, DutyType.TRIPLE_DUTY, "Corrected", UserRole.ADMIN, "Correction")
        val afterReopenEdit = repo.attendanceRecords.value
            .find { it.workerId == targetWorker.id && it.dateIso == "2026-09-25" }?.earnedAmount
        assertNotEquals(beforeEarned, afterReopenEdit)
    }

    @Test
    fun scenario11_12_and_13_nonDestructivePhotoPreservedAndVoidReversal() {
        assertEquals("worker_photos/sl_201.jpg", worker300.photoPath)
        val voidedAlloc = PaymentAllocation("AL-V", "PAYMENT", "TX-V", worker650.id, "2026-11", 650, "2026-11-12", UserRole.ADMIN, isVoided = true)
        val summary = WageCalculator.computeWorkerMonthlySummary(worker650, 2026, 11, emptyList(), listOf(voidedAlloc))
        assertEquals(0, summary.totalPaidAmount)
        assertEquals(0, summary.outstandingBalance)
    }
}
