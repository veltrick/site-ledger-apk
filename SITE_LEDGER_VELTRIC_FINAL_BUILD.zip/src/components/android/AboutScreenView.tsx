import { Building2, CheckCircle2, HardHat, User } from 'lucide-react';
import { BilingualUiStrings } from '../../data/bilingualStrings';

interface AboutScreenViewProps {
  strings: BilingualUiStrings;
}

export function AboutScreenView({ strings }: AboutScreenViewProps) {
  return (
    <div
      className="min-h-full space-y-3.5 p-4 text-slate-100"
      style={{
        background:
          'linear-gradient(180deg, #040A18 0%, #08142B 52%, #040A18 100%)',
      }}
    >
      {/* Official Brand & Product Hero Card */}
      <div className="rounded-2xl border border-sky-400/25 bg-[#0B1933] px-5 py-6 text-center shadow-sm">
        <div className="relative mx-auto flex h-36 w-36 items-center justify-center">
          {/* Subtle ambient halo strictly behind the unmodified official PNG */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 rounded-full"
            style={{
              background:
                'radial-gradient(circle, rgba(0, 212, 255, 0.24) 0%, rgba(0, 102, 255, 0.12) 48%, rgba(0, 0, 0, 0) 72%)',
              filter: 'blur(12px)',
            }}
          />
          <img
            src="/assets/aistudio/InShot_20261120_132804721_7eb17f11.png"
            alt={strings.aboutCompanyName}
            draggable={false}
            className="relative z-10 aspect-square w-32 object-contain select-none"
          />
        </div>

        <div className="mt-3 text-xs font-bold tracking-[0.22em] text-sky-400">
          {strings.aboutCompanyName}
        </div>
        <h2 className="mt-1 text-xl font-bold tracking-tight text-white">
          {strings.aboutProductName}
        </h2>

        <div className="mt-2 inline-block rounded-lg border border-sky-400/30 bg-[#071124] px-3 py-1 text-xs font-semibold text-blue-300">
          {strings.aboutAttribution}
        </div>

        <div className="mt-4 border-t border-blue-500/20 pt-3.5 text-left">
          <div className="flex items-center gap-3 rounded-xl border border-blue-500/20 bg-[#071124] px-3.5 py-2.5">
            <User className="h-4 w-4 shrink-0 text-sky-400" />
            <div className="min-w-0">
              <div className="text-[11px] text-slate-400">
                {strings.aboutFounderLabel}
              </div>
              <div className="text-xs font-bold tracking-wide text-white">
                {strings.aboutFounderName}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* About VELTRIC */}
      <div className="rounded-2xl border border-blue-500/20 bg-[#0B1933] p-4">
        <div className="flex items-center gap-2 text-sm font-bold text-white">
          <Building2 className="h-4 w-4 shrink-0 text-sky-400" />
          <span>{strings.aboutVeltricHeading}</span>
        </div>
        <p className="mt-2 text-xs leading-relaxed text-slate-300">
          {strings.aboutVeltricBody}
        </p>
      </div>

      {/* About SITE LEDGER */}
      <div className="rounded-2xl border border-blue-500/20 bg-[#0B1933] p-4">
        <div className="flex items-center gap-2 text-sm font-bold text-white">
          <HardHat className="h-4 w-4 shrink-0 text-sky-400" />
          <span>{strings.aboutSiteLedgerHeading}</span>
        </div>
        <p className="mt-2 text-xs leading-relaxed text-slate-300">
          {strings.aboutSiteLedgerIntro}
        </p>
        <div className="mt-3 text-xs font-semibold text-blue-300">
          {strings.aboutHelpsManageTitle}
        </div>
        <ul className="mt-2 space-y-2">
          {strings.aboutCapabilities.map((item) => (
            <li
              key={item}
              className="flex items-start gap-2 text-xs leading-snug text-slate-200"
            >
              <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sky-400" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
