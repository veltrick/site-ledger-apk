import { useState } from 'react';
import {
  AlertTriangle,
  BarChart3,
  Building2,
  CalendarCheck2,
  CreditCard,
  Info,
  LayoutDashboard,
  MapPin,
  Menu,
  Receipt,
  Settings,
  Table2,
  Users,
  X,
} from 'lucide-react';
import { BilingualUiStrings, USER_ROLE_LABELS } from '../../data/bilingualStrings';
import {
  AdvanceRecord,
  AppLanguage,
  AttendanceAuditEntry,
  BackupHistoryRecord,
  BackupProgress,
  BackupValidationResult,
  DailyAttendanceRecord,
  DutyMultiplierConfig,
  DutyType,
  ExpenseCategory,
  NavDestination,
  PaymentAllocation,
  PaymentAuditEntry,
  PaymentLedgerEntry,
  PayrollPeriodRecord,
  Site,
  SiteExpense,
  UserRole,
  UserSiteAccount,
  WorkCategory,
  Worker,
  WorkerSiteHistory,
} from '../../types/siteLedger';
import { computeSiteFinancialSummary } from '../../utils/wageCalculator';
import { AboutScreenView } from './AboutScreenView';
import { AttendanceScreenView } from './AttendanceScreenView';
import { DashboardScreenView } from './DashboardScreenView';
import { ExpensesScreenView } from './ExpensesScreenView';
import { PaymentsScreenView } from './PaymentsScreenView';
import { PayrollSpreadsheetView } from './PayrollSpreadsheetView';
import { ReportsScreenView } from './ReportsScreenView';
import { SettingsScreenView } from './SettingsScreenView';
import { SitesOverviewScreenView } from './SitesOverviewScreenView';
import { VeltricSplashScreenView } from './VeltricSplashScreenView';
import { WorkersScreenView } from './WorkersScreenView';

interface AndroidAppPreviewProps {
  showSplash: boolean;
  onSplashComplete: () => void;
  strings: BilingualUiStrings;
  language: AppLanguage;
  destination: NavDestination;
  activeRole: UserRole;
  activeSite: Site;
  sites: Site[];
  allowedSiteIds: Set<string>;
  dutyConfig: DutyMultiplierConfig;
  onNavigate: (dest: NavDestination) => void;
  onSelectSite: (siteId: string) => void;
  onSelectLanguage: (lang: AppLanguage) => void;
  onSelectRole: (role: UserRole) => void;
  onSaveDutyConfig: (config: DutyMultiplierConfig) => void;
  workers: Worker[];
  workerTransfers: WorkerSiteHistory[];
  attendanceRecords: DailyAttendanceRecord[];
  attendanceAudits: AttendanceAuditEntry[];
  payments: PaymentLedgerEntry[];
  advances: AdvanceRecord[];
  allocations: PaymentAllocation[];
  paymentAudits: PaymentAuditEntry[];
  payrollPeriods: PayrollPeriodRecord[];
  expenseCategories: ExpenseCategory[];
  expenses: SiteExpense[];
  userSiteAccounts: UserSiteAccount[];
  backupHistory: BackupHistoryRecord[];
  backupProgress: BackupProgress;
  pendingRestore: BackupValidationResult | null;
  backupFeedback: { type: 'success' | 'error'; message: string } | null;
  selectedDate: string;
  onSelectDate: (dateIso: string) => void;
  onAddWorker: (input: {
    fullName: string;
    localWorkerCode: string;
    phoneNumber: string;
    category: WorkCategory;
    joiningDateIso: string;
    dailyWage: number;
    foodAllowance: number;
    isActive: boolean;
    avatarUrl: string | null;
    photoPath: string | null;
  }) => void;
  onEditWorker: (updated: Worker) => void;
  onTransferWorker: (input: {
    workerId: string;
    toSiteId: string;
    newLocalCode: string;
    transferDateIso: string;
    note: string;
  }) => void;
  onRecordAttendance: (input: {
    dateIso: string;
    worker: Worker;
    dutyType: DutyType;
    note: string;
    editReason?: string;
  }) => void;
  onRecordPayment: (input: {
    workerId: string;
    dateIso: string;
    applicablePeriod: string;
    paidAmount: number;
    referenceNo: string;
    note: string;
    submissionToken: string;
  }) => void;
  onRecordAdvance: (input: {
    workerId: string;
    advanceDateIso: string;
    amount: number;
    referenceNo: string;
    note: string;
    submissionToken: string;
  }) => void;
  onAllocateAdvance: (input: {
    advanceId: string;
    targetPeriod: string;
    amountToAllocate: number;
    note: string;
  }) => void;
  onVoidPayment: (transactionId: string, reason: string) => void;
  onFinalizePeriod: (periodIso: string, reason: string) => void;
  onReopenPeriod: (periodIso: string, reason: string) => void;
  onSaveExpense: (expense: SiteExpense) => void;
  onVoidExpense: (expenseId: string, reason: string) => void;
  onAddCategory: (nameEn: string, nameBn: string) => void;
  onSaveSite: (site: Site) => void;
  onArchiveSite: (siteId: string) => void;
  onUpdateRoleSiteAssignments: (role: UserRole, assignedSiteIds: string[]) => void;
  onCreateFullBackup: () => void;
  onInspectBackupFile: (file: File, openRestorePrompt: boolean) => void;
  onConfirmRestore: () => void;
  onDismissPendingRestore: () => void;
  onClearBackupFeedback: () => void;
  onResetSampleData: () => void;
}

export function AndroidAppPreview({
  showSplash,
  onSplashComplete,
  strings,
  language,
  destination,
  activeRole,
  activeSite,
  sites,
  allowedSiteIds,
  dutyConfig,
  onNavigate,
  onSelectSite,
  onSelectLanguage,
  onSelectRole,
  onSaveDutyConfig,
  workers,
  workerTransfers,
  attendanceRecords,
  attendanceAudits,
  payments,
  advances,
  allocations,
  paymentAudits,
  payrollPeriods,
  expenseCategories,
  expenses,
  userSiteAccounts,
  backupHistory,
  backupProgress,
  pendingRestore,
  backupFeedback,
  selectedDate,
  onSelectDate,
  onAddWorker,
  onEditWorker,
  onTransferWorker,
  onRecordAttendance,
  onRecordPayment,
  onRecordAdvance,
  onAllocateAdvance,
  onVoidPayment,
  onFinalizePeriod,
  onReopenPeriod,
  onSaveExpense,
  onVoidExpense,
  onAddCategory,
  onSaveSite,
  onArchiveSite,
  onUpdateRoleSiteAssignments,
  onCreateFullBackup,
  onInspectBackupFile,
  onConfirmRestore,
  onDismissPendingRestore,
  onClearBackupFeedback,
  onResetSampleData,
}: AndroidAppPreviewProps) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [pendingProfileWorkerId, setPendingProfileWorkerId] = useState<string | null>(null);

  const hasAccessToActiveSite = activeRole === 'ADMIN' || allowedSiteIds.has(activeSite.id);
  const accessibleSites = sites.filter((s) => activeRole === 'ADMIN' || allowedSiteIds.has(s.id));

  // Strict per-site filtering for operational screens
  const siteWorkers = workers.filter((w) => w.siteId === activeSite.id);
  const siteAttendance = attendanceRecords.filter((a) => a.siteId === activeSite.id);
  const siteAttendanceAudits = attendanceAudits.filter((a) => a.siteId === activeSite.id);
  const sitePayments = payments.filter((p) => p.siteId === activeSite.id);
  const siteAdvances = advances.filter((a) => a.siteId === activeSite.id);
  const siteAllocations = allocations.filter((a) => a.siteId === activeSite.id);
  const sitePaymentAudits = paymentAudits.filter((a) => a.siteId === activeSite.id);
  const sitePayrollPeriods = payrollPeriods.filter((p) => p.siteId === activeSite.id);
  const siteExpenses = expenses.filter((e) => e.siteId === activeSite.id);

  // Dashboard metrics for active site
  const todayIso = '2026-11-15';
  const todayAttendance = siteAttendance.filter((a) => a.dateIso === todayIso);
  const presentToday = todayAttendance.filter(
    (a) => a.dutyType !== 'ABSENT' && a.dutyType !== 'LEAVE'
  ).length;
  const absentToday = todayAttendance.filter((a) => a.dutyType === 'ABSENT').length;
  const todaysPaymentsTotal = sitePayments
    .filter((p) => !p.isVoided && p.dateIso === todayIso)
    .reduce((sum, p) => sum + p.paidAmount, 0);

  const siteFinance = computeSiteFinancialSummary(
    activeSite,
    workers,
    attendanceRecords,
    allocations,
    expenses,
    null
  );

  const navItems: {
    dest: NavDestination;
    label: string;
    icon: typeof LayoutDashboard;
  }[] = [
    { dest: 'dashboard', label: strings.navDashboard, icon: LayoutDashboard },
    { dest: 'workers', label: strings.navWorkers, icon: Users },
    { dest: 'attendance', label: strings.navAttendance, icon: CalendarCheck2 },
    { dest: 'spreadsheet', label: strings.navSpreadsheet, icon: Table2 },
    { dest: 'payments', label: strings.navPayments, icon: CreditCard },
    { dest: 'expenses', label: strings.navExpenses, icon: Receipt },
    { dest: 'reports', label: strings.navReports, icon: BarChart3 },
    { dest: 'sites', label: strings.navSites, icon: Building2 },
    { dest: 'settings', label: strings.navSettings, icon: Settings },
    { dest: 'about', label: strings.navAbout, icon: Info },
  ];

  // Primary 5 Material 3 bottom tabs; remaining routes accessible via Drawer & Quick Links
  const bottomTabs = [
    navItems[0], // Dashboard
    navItems[1], // Workers
    navItems[2], // Attendance
    navItems[4], // Payments
    navItems[5], // Expenses
  ];

  const roleLabel =
    language === 'bn' ? USER_ROLE_LABELS[activeRole].bn : USER_ROLE_LABELS[activeRole].en;

  return (
    <div className="relative flex h-[740px] w-full flex-col overflow-hidden rounded-[28px] border border-slate-300 bg-[#F4F6F9] shadow-lg md:max-w-[412px]">
      {/* Material 3 TopAppBar */}
      <div className="flex h-14 shrink-0 items-center justify-between border-b border-slate-200 bg-white px-2">
        <div className="flex min-w-0 items-center gap-1">
          <button
            type="button"
            onClick={() => setDrawerOpen(true)}
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-slate-700 hover:bg-slate-100"
            aria-label="Open navigation drawer"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="min-w-0">
            <div className="truncate text-sm font-bold tracking-tight text-slate-900">
              {strings.appName}
            </div>
            <div className="truncate text-[11px] text-slate-500">
              {roleLabel} · {activeSite.siteCode}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-0.5">
          <button
            type="button"
            onClick={() => onNavigate('sites')}
            className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition-colors ${
              destination === 'sites'
                ? 'bg-blue-50 text-blue-700'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
            aria-label={strings.navSites}
            title={strings.navSites}
          >
            <Building2 className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => onNavigate('settings')}
            className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition-colors ${
              destination === 'settings'
                ? 'bg-blue-50 text-blue-700'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
            aria-label={strings.navSettings}
            title={strings.navSettings}
          >
            <Settings className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Persistent Active Site Switcher Bar */}
      <div className="flex shrink-0 items-center justify-between gap-2 border-b border-slate-200 bg-slate-50 px-3 py-2">
        <div className="flex min-w-0 flex-1 items-center gap-1.5">
          <MapPin className="h-3.5 w-3.5 shrink-0 text-blue-700" />
          <select
            value={activeSite.id}
            onChange={(e) => onSelectSite(e.target.value)}
            aria-label={strings.activeSiteLabel}
            className="w-full min-w-0 truncate rounded-lg border border-slate-200 bg-white px-2 py-1 text-xs font-semibold text-slate-800 outline-none focus:border-blue-600"
          >
            {accessibleSites.map((site) => (
              <option key={site.id} value={site.id}>
                {site.siteName} ({site.siteCode})
              </option>
            ))}
            {!hasAccessToActiveSite && (
              <option value={activeSite.id}>
                {activeSite.siteName} ({activeSite.siteCode}) — Restricted
              </option>
            )}
          </select>
        </div>
        <button
          type="button"
          onClick={() => onNavigate('sites')}
          className="shrink-0 rounded-lg border border-slate-200 bg-white px-2 py-1 text-[10px] font-semibold text-blue-700 hover:bg-blue-50"
        >
          {sites.length} {strings.navSites}
        </button>
      </div>

      {/* Scrollable Screen Body */}
      <div className="thin-scroll flex-1 overflow-y-auto">
        {!hasAccessToActiveSite &&
        destination !== 'sites' &&
        destination !== 'settings' &&
        destination !== 'about' ? (
          <div className="p-4">
            <div className="rounded-2xl border border-amber-300 bg-amber-50 p-4 text-xs text-amber-900">
              <div className="flex items-center gap-2 font-bold">
                <AlertTriangle className="h-4 w-4 shrink-0 text-amber-700" />
                <span>{strings.sitePermissionsTitle}</span>
              </div>
              <p className="mt-2 leading-relaxed">{strings.siteAccessDeniedWarning}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {accessibleSites.length > 0 && (
                  <button
                    type="button"
                    onClick={() => onSelectSite(accessibleSites[0].id)}
                    className="rounded-lg bg-amber-800 px-3 py-1.5 text-[11px] font-semibold text-white"
                  >
                    Switch to {accessibleSites[0].siteCode}
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => onNavigate('sites')}
                  className="rounded-lg border border-amber-300 bg-white px-3 py-1.5 text-[11px] font-semibold text-amber-900"
                >
                  {strings.navSites}
                </button>
              </div>
            </div>
          </div>
        ) : (
          <>
            {destination === 'dashboard' && (
              <DashboardScreenView
                strings={strings}
                activeSite={activeSite}
                totalWorkers={siteWorkers.length}
                presentToday={presentToday}
                absentToday={absentToday}
                todaysPaymentsTotal={todaysPaymentsTotal}
                earnedPayrollTotal={siteFinance.totalEarnedPayroll}
                paidPayrollTotal={siteFinance.totalPaidPayroll}
                generalExpensesTotal={siteFinance.totalGeneralExpenses}
                outstandingPayrollTotal={siteFinance.totalOutstandingPayroll}
                onNavigate={onNavigate}
              />
            )}

            {destination === 'workers' && (
              <WorkersScreenView
                strings={strings}
                language={language}
                activeSite={activeSite}
                allSites={sites}
                workers={siteWorkers}
                allWorkersAcrossSites={workers}
                workerTransfers={workerTransfers}
                activeRole={activeRole}
                dutyConfig={dutyConfig}
                attendanceRecords={siteAttendance}
                allAttendanceRecords={attendanceRecords}
                attendanceAudits={siteAttendanceAudits}
                payments={sitePayments}
                allPayments={payments}
                advances={siteAdvances}
                allAdvances={advances}
                allocations={siteAllocations}
                allAllocations={allocations}
                paymentAudits={sitePaymentAudits}
                payrollPeriods={sitePayrollPeriods}
                initialProfileWorkerId={pendingProfileWorkerId}
                onConsumeInitialProfileWorker={() => setPendingProfileWorkerId(null)}
                onAddWorker={onAddWorker}
                onEditWorker={onEditWorker}
                onTransferWorker={onTransferWorker}
                onRecordAttendance={onRecordAttendance}
                onRecordPayment={onRecordPayment}
                onRecordAdvance={onRecordAdvance}
                onAllocateAdvance={onAllocateAdvance}
                onVoidPayment={onVoidPayment}
              />
            )}

            {destination === 'attendance' && (
              <AttendanceScreenView
                strings={strings}
                language={language}
                activeSite={activeSite}
                selectedDate={selectedDate}
                onSelectDate={onSelectDate}
                workers={siteWorkers}
                activeRole={activeRole}
                dutyConfig={dutyConfig}
                attendanceRecords={siteAttendance}
                payrollPeriods={sitePayrollPeriods}
                onRecordAttendance={onRecordAttendance}
              />
            )}

            {destination === 'spreadsheet' && (
              <PayrollSpreadsheetView
                strings={strings}
                language={language}
                activeRole={activeRole}
                activeSite={activeSite}
                sites={sites}
                allowedSiteIds={allowedSiteIds}
                workers={workers}
                attendanceRecords={attendanceRecords}
                allocations={allocations}
                payrollPeriods={payrollPeriods}
                onWorkerClick={(workerId) => {
                  const target = workers.find((w) => w.id === workerId);
                  if (target && target.siteId !== activeSite.id) {
                    onSelectSite(target.siteId);
                  }
                  setPendingProfileWorkerId(workerId);
                  onNavigate('workers');
                }}
                onFinalizePeriod={onFinalizePeriod}
                onReopenPeriod={onReopenPeriod}
              />
            )}

            {destination === 'payments' && (
              <PaymentsScreenView
                strings={strings}
                language={language}
                activeSite={activeSite}
                workers={siteWorkers}
                activeRole={activeRole}
                attendanceRecords={siteAttendance}
                payments={sitePayments}
                advances={siteAdvances}
                allocations={siteAllocations}
                payrollPeriods={sitePayrollPeriods}
                onRecordPayment={onRecordPayment}
                onRecordAdvance={onRecordAdvance}
                onAllocateAdvance={onAllocateAdvance}
                onVoidPayment={onVoidPayment}
              />
            )}

            {destination === 'expenses' && (
              <ExpensesScreenView
                strings={strings}
                language={language}
                activeRole={activeRole}
                activeSite={activeSite}
                categories={expenseCategories}
                expenses={siteExpenses}
                onSaveExpense={onSaveExpense}
                onVoidExpense={onVoidExpense}
                onAddCategory={onAddCategory}
              />
            )}

            {destination === 'reports' && (
              <ReportsScreenView
                strings={strings}
                language={language}
                activeSite={activeSite}
                sites={sites}
                allowedSiteIds={allowedSiteIds}
                workers={siteWorkers}
                allWorkers={workers}
                attendanceRecords={siteAttendance}
                allAttendanceRecords={attendanceRecords}
                allocations={siteAllocations}
                allAllocations={allocations}
                payrollPeriods={sitePayrollPeriods}
                expenses={siteExpenses}
                allExpenses={expenses}
              />
            )}

            {destination === 'sites' && (
              <SitesOverviewScreenView
                strings={strings}
                language={language}
                activeRole={activeRole}
                activeSiteId={activeSite.id}
                sites={sites}
                allowedSiteIds={allowedSiteIds}
                workers={workers}
                attendanceRecords={attendanceRecords}
                allocations={allocations}
                expenses={expenses}
                userSiteAccounts={userSiteAccounts}
                onSelectSite={(siteId) => {
                  onSelectSite(siteId);
                  onNavigate('dashboard');
                }}
                onSaveSite={onSaveSite}
                onArchiveSite={onArchiveSite}
                onUpdateRoleSiteAssignments={onUpdateRoleSiteAssignments}
              />
            )}

            {destination === 'settings' && (
              <SettingsScreenView
                strings={strings}
                language={language}
                activeRole={activeRole}
                activeSite={activeSite}
                userSiteAccounts={userSiteAccounts}
                dutyConfig={dutyConfig}
                backupHistory={backupHistory}
                backupProgress={backupProgress}
                pendingRestore={pendingRestore}
                backupFeedback={backupFeedback}
                onSelectLanguage={onSelectLanguage}
                onSelectRole={onSelectRole}
                onSaveDutyConfig={onSaveDutyConfig}
                onCreateFullBackup={onCreateFullBackup}
                onInspectBackupFile={onInspectBackupFile}
                onConfirmRestore={onConfirmRestore}
                onDismissPendingRestore={onDismissPendingRestore}
                onClearBackupFeedback={onClearBackupFeedback}
                onOpenAbout={() => onNavigate('about')}
                onResetSampleData={onResetSampleData}
              />
            )}

            {destination === 'about' && <AboutScreenView strings={strings} />}
          </>
        )}
      </div>

      {/* Material 3 NavigationBar */}
      <nav
        aria-label="Primary Android Navigation"
        className="grid h-16 shrink-0 grid-cols-5 border-t border-slate-200 bg-white px-1"
      >
        {bottomTabs.map(({ dest, label, icon: Icon }) => {
          const active = destination === dest;
          return (
            <button
              key={dest}
              type="button"
              onClick={() => onNavigate(dest)}
              className="flex flex-col items-center justify-center gap-1 py-1 text-center"
            >
              <span
                className={`flex h-7 w-12 items-center justify-center rounded-full transition-colors ${
                  active ? 'bg-blue-100 text-blue-800' : 'text-slate-600'
                }`}
              >
                <Icon className="h-[18px] w-[18px]" />
              </span>
              <span
                className={`max-w-full truncate px-0.5 text-[10px] font-semibold ${
                  active ? 'text-blue-800' : 'text-slate-600'
                }`}
              >
                {label}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Material 3 ModalNavigationDrawer Overlay */}
      {drawerOpen && (
        <div className="absolute inset-0 z-40 flex bg-slate-950/40">
          <div className="flex h-full w-64 flex-col bg-white p-4 shadow-xl">
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div>
                <div className="text-base font-bold text-blue-900">{strings.appName}</div>
                <div className="mt-0.5 text-[11px] text-slate-500">{activeSite.siteName}</div>
              </div>
              <button
                type="button"
                onClick={() => setDrawerOpen(false)}
                className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
                aria-label="Close menu"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="thin-scroll mt-3 flex-1 space-y-1 overflow-y-auto">
              {navItems.map(({ dest, label, icon: Icon }) => {
                const active = destination === dest;
                return (
                  <button
                    key={dest}
                    type="button"
                    onClick={() => {
                      onNavigate(dest);
                      setDrawerOpen(false);
                    }}
                    className={`flex min-h-[42px] w-full items-center gap-3 rounded-xl px-3 py-2 text-sm font-semibold transition-colors ${
                      active
                        ? 'bg-blue-50 text-blue-800'
                        : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span className="truncate">{label}</span>
                  </button>
                );
              })}
            </div>
          </div>
          <div className="flex-1" onClick={() => setDrawerOpen(false)} />
        </div>
      )}

      {/* Official Startup Splash Screen */}
      {showSplash && (
        <VeltricSplashScreenView onComplete={onSplashComplete} />
      )}
    </div>
  );
}
