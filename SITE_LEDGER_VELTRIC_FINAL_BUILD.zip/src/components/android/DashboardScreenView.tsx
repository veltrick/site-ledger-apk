import {
  ArrowRight,
  Building2,
  CalendarCheck2,
  ClipboardList,
  CreditCard,
  Info,
  Receipt,
  Settings,
  Table2,
  Users,
} from 'lucide-react';
import { BilingualUiStrings } from '../../data/bilingualStrings';
import { NavDestination, Site } from '../../types/siteLedger';

interface DashboardScreenViewProps {
  strings: BilingualUiStrings;
  activeSite: Site;
  totalWorkers: number;
  presentToday: number;
  absentToday: number;
  todaysPaymentsTotal: number;
  earnedPayrollTotal: number;
  paidPayrollTotal: number;
  generalExpensesTotal: number;
  outstandingPayrollTotal: number;
  onNavigate: (dest: NavDestination) => void;
}

export function DashboardScreenView({
  strings,
  activeSite,
  totalWorkers,
  presentToday,
  absentToday,
  todaysPaymentsTotal,
  earnedPayrollTotal,
  paidPayrollTotal,
  generalExpensesTotal,
  outstandingPayrollTotal,
  onNavigate,
}: DashboardScreenViewProps) {
  const quickLinks: { dest: NavDestination; label: string; icon: typeof Users }[] = [
    { dest: 'workers', label: strings.navWorkers, icon: Users },
    { dest: 'attendance', label: strings.navAttendance, icon: CalendarCheck2 },
    { dest: 'spreadsheet', label: strings.navSpreadsheet, icon: Table2 },
    { dest: 'payments', label: strings.navPayments, icon: CreditCard },
    { dest: 'expenses', label: strings.navExpenses, icon: Receipt },
    { dest: 'reports', label: strings.navReports, icon: ClipboardList },
    { dest: 'sites', label: strings.navSites, icon: Building2 },
    { dest: 'settings', label: strings.navSettings, icon: Settings },
  ];

  return (
    <div className="space-y-4 p-4">
      <div className="flex items-start gap-2.5 rounded-xl border border-blue-200 bg-blue-50/70 px-3 py-2.5 text-xs text-blue-950">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-blue-700" />
        <span>{strings.sampleDataNotice}</span>
      </div>

      {/* Active Site Context Header */}
      <div className="flex items-center justify-between gap-2 rounded-2xl border border-slate-200 bg-white px-3.5 py-2.5">
        <div className="min-w-0">
          <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-500">
            {strings.activeSiteLabel} · {activeSite.siteCode}
          </div>
          <div className="truncate text-sm font-bold text-slate-900">
            {activeSite.siteName}
          </div>
        </div>
        <button
          type="button"
          onClick={() => onNavigate('sites')}
          className="shrink-0 rounded-lg border border-blue-200 bg-blue-50 px-2.5 py-1 text-[11px] font-semibold text-blue-800 hover:bg-blue-100"
        >
          {strings.navSites}
        </button>
      </div>

      <div>
        <h2 className="text-base font-bold text-slate-900">{strings.siteOverviewTitle}</h2>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-2xl border border-slate-200 bg-white p-3.5">
          <div className="text-xs font-medium text-slate-500">{strings.totalWorkers}</div>
          <div className="mt-1.5 text-2xl font-bold text-slate-900 tabular-nums">
            {totalWorkers}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-3.5">
          <div className="text-xs font-medium text-slate-500">{strings.presentToday}</div>
          <div className="mt-1.5 text-2xl font-bold text-emerald-700 tabular-nums">
            {presentToday}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-3.5">
          <div className="text-xs font-medium text-slate-500">{strings.absentToday}</div>
          <div className="mt-1.5 text-2xl font-bold text-rose-700 tabular-nums">
            {absentToday}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-3.5">
          <div className="text-xs font-medium text-slate-500">{strings.todaysPayments}</div>
          <div className="mt-1.5 text-2xl font-bold text-blue-700 tabular-nums">
            ৳{todaysPaymentsTotal.toLocaleString('en-US')}
          </div>
        </div>
      </div>

      {/* 4-Way Financial Separation Card: Earned Payroll, Paid Payroll, General Site Expenses, Outstanding Payroll */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <div className="text-[11px] font-medium text-slate-500">
              {strings.monthlyExpenses}
            </div>
            <div className="mt-1 text-lg font-bold text-slate-900 tabular-nums">
              ৳{earnedPayrollTotal.toLocaleString('en-US')}
            </div>
          </div>
          <div>
            <div className="text-[11px] font-medium text-slate-500">
              {strings.paidPayrollCardLabel}
            </div>
            <div className="mt-1 text-lg font-bold text-emerald-700 tabular-nums">
              ৳{paidPayrollTotal.toLocaleString('en-US')}
            </div>
          </div>
          <div>
            <div className="text-[11px] font-medium text-slate-500">
              {strings.generalExpensesCardLabel}
            </div>
            <div className="mt-1 text-lg font-bold text-amber-700 tabular-nums">
              ৳{generalExpensesTotal.toLocaleString('en-US')}
            </div>
          </div>
          <div>
            <div className="text-[11px] font-medium text-slate-500">
              {strings.outstandingPayrollCardLabel}
            </div>
            <div className="mt-1 text-lg font-bold text-blue-800 tabular-nums">
              ৳{outstandingPayrollTotal.toLocaleString('en-US')}
            </div>
          </div>
        </div>

        <div className="mt-3 flex gap-2 border-t border-slate-100 pt-3">
          <button
            type="button"
            onClick={() => onNavigate('expenses')}
            className="flex flex-1 min-h-[38px] items-center justify-center gap-1 rounded-xl border border-amber-200 bg-amber-50 px-2.5 py-1.5 text-xs font-semibold text-amber-900 hover:bg-amber-100"
          >
            <span>{strings.navExpenses}</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => onNavigate('reports')}
            className="flex flex-1 min-h-[38px] items-center justify-center gap-1 rounded-xl bg-blue-50 px-2.5 py-1.5 text-xs font-semibold text-blue-700 hover:bg-blue-100"
          >
            <span>{strings.navReports}</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      <div className="pt-1">
        <h3 className="mb-2.5 text-sm font-semibold text-slate-800">{strings.quickActionsTitle}</h3>
        <div className="grid grid-cols-2 gap-2.5">
          {quickLinks.map(({ dest, label, icon: Icon }) => (
            <button
              key={dest}
              type="button"
              onClick={() => onNavigate(dest)}
              className="flex min-h-[48px] items-center justify-between rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-left transition-colors hover:border-blue-300 hover:bg-blue-50/40"
            >
              <span className="flex min-w-0 items-center gap-2 text-xs font-semibold text-slate-900">
                <Icon className="h-4 w-4 shrink-0 text-blue-700" />
                <span className="truncate">{label}</span>
              </span>
              <ArrowRight className="h-3.5 w-3.5 shrink-0 text-slate-400" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
