import { useMemo, useState } from 'react';
import { Info, Plus, X } from 'lucide-react';
import { BilingualUiStrings } from '../../data/bilingualStrings';
import {
  AdvanceRecord,
  AppLanguage,
  DailyAttendanceRecord,
  PaymentAllocation,
  PaymentLedgerEntry,
  PayrollPeriodRecord,
  Site,
  UserRole,
  Worker,
} from '../../types/siteLedger';
import {
  computeAdvanceRemaining,
  computeUnallocatedAdvanceBalance,
  computeWorkerOverallBalances,
  isPeriodFinalized,
} from '../../utils/wageCalculator';
import { WorkerAvatarView } from './WorkerAvatarView';

interface PaymentsScreenViewProps {
  strings: BilingualUiStrings;
  language: AppLanguage;
  activeSite: Site;
  workers: Worker[];
  activeRole: UserRole;
  attendanceRecords: DailyAttendanceRecord[];
  payments: PaymentLedgerEntry[];
  advances: AdvanceRecord[];
  allocations: PaymentAllocation[];
  payrollPeriods: PayrollPeriodRecord[];
  onRecordPayment: (input: {
    workerId: string;
    dateIso: string;
    applicablePeriod: string;
    paidAmount: number;
    referenceNo: string;
    note: string;
    submissionToken: string;
  }) => void;
  onRecordAdvance: (input: {
    workerId: string;
    advanceDateIso: string;
    amount: number;
    referenceNo: string;
    note: string;
    submissionToken: string;
  }) => void;
  onAllocateAdvance: (input: {
    advanceId: string;
    targetPeriod: string;
    amountToAllocate: number;
    note: string;
  }) => void;
  onVoidPayment: (transactionId: string, reason: string) => void;
}

export function PaymentsScreenView({
  strings,
  language,
  activeSite,
  workers,
  activeRole,
  attendanceRecords,
  payments,
  advances,
  allocations,
  payrollPeriods,
  onRecordPayment,
  onRecordAdvance,
  onAllocateAdvance,
  onVoidPayment,
}: PaymentsScreenViewProps) {
  const [showEntryModal, setShowEntryModal] = useState(false);
  const [showAdvanceModal, setShowAdvanceModal] = useState(false);
  const [allocateTarget, setAllocateTarget] = useState<AdvanceRecord | null>(null);

  const [selectedWorkerId, setSelectedWorkerId] = useState(workers[0]?.id ?? '');
  const [paymentDateIso, setPaymentDateIso] = useState('2026-11-15');
  const [applicablePeriod, setApplicablePeriod] = useState('2026-11');
  const [paidAmount, setPaidAmount] = useState('0');
  const [referenceNo, setReferenceNo] = useState('');
  const [note, setNote] = useState('');
  const [submissionToken, setSubmissionToken] = useState('');
  const [voidTarget, setVoidTarget] = useState<PaymentLedgerEntry | null>(null);

  const [advWorkerId, setAdvWorkerId] = useState(workers[0]?.id ?? '');
  const [advDateIso, setAdvDateIso] = useState('2026-11-15');
  const [advAmount, setAdvAmount] = useState('');
  const [advRef, setAdvRef] = useState('');
  const [advNote, setAdvNote] = useState('');
  const [advToken, setAdvToken] = useState('');

  const [allocPeriod, setAllocPeriod] = useState('2026-11');
  const [allocAmount, setAllocAmount] = useState('');
  const [allocNote, setAllocNote] = useState('');

  const canEditPayments = activeRole !== 'MANAGER';

  const workerMap = useMemo(() => {
    const map = new Map<string, Worker>();
    for (const w of workers) map.set(w.id, w);
    return map;
  }, [workers]);

  const workerBalances = useMemo(() => {
    return workers.map((w) => ({
      worker: w,
      unallocatedAdvance: computeUnallocatedAdvanceBalance(
        w.id,
        advances,
        allocations,
        activeSite.id
      ),
      ...computeWorkerOverallBalances(w.id, attendanceRecords, allocations, activeSite.id),
    }));
  }, [workers, attendanceRecords, allocations, advances, activeSite.id]);

  const openNewPaymentModal = (workerId?: string) => {
    const targetId = workerId ?? workers[0]?.id ?? '';
    const bal = computeWorkerOverallBalances(
      targetId,
      attendanceRecords,
      allocations,
      activeSite.id
    );
    setSelectedWorkerId(targetId);
    setPaymentDateIso('2026-11-15');
    setApplicablePeriod('2026-11');
    setPaidAmount(String(Math.max(0, bal.outstanding)));
    setReferenceNo('');
    setNote('');
    setSubmissionToken(`pay_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`);
    setShowEntryModal(true);
  };

  const openAdvanceModal = () => {
    setAdvWorkerId(workers[0]?.id ?? '');
    setAdvDateIso('2026-11-15');
    setAdvAmount('');
    setAdvRef('');
    setAdvNote('');
    setAdvToken(`adv_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`);
    setShowAdvanceModal(true);
  };

  const handleWorkerChange = (id: string) => {
    setSelectedWorkerId(id);
    const bal = computeWorkerOverallBalances(
      id,
      attendanceRecords,
      allocations,
      activeSite.id
    );
    setPaidAmount(String(Math.max(0, bal.outstanding)));
  };

  const selectedBalance = useMemo(
    () =>
      computeWorkerOverallBalances(
        selectedWorkerId,
        attendanceRecords,
        allocations,
        activeSite.id
      ),
    [selectedWorkerId, attendanceRecords, allocations, activeSite.id]
  );

  const selectedPeriodLocked = isPeriodFinalized(
    applicablePeriod,
    payrollPeriods,
    activeSite.id
  );
  const allocPeriodLocked = isPeriodFinalized(allocPeriod, payrollPeriods, activeSite.id);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedPeriodLocked || !selectedWorkerId) return;
    const numericAmount = Math.trunc(Number(paidAmount));
    if (!Number.isFinite(numericAmount) || numericAmount <= 0) return;

    onRecordPayment({
      workerId: selectedWorkerId,
      dateIso: paymentDateIso || '2026-11-15',
      applicablePeriod,
      paidAmount: numericAmount,
      referenceNo: referenceNo.trim() || 'CASH',
      note: note.trim() || 'Manual site payment',
      submissionToken,
    });
    setShowEntryModal(false);
  };

  return (
    <div className="space-y-4 p-4">
      <div className="flex items-start gap-2.5 rounded-xl border border-blue-200 bg-blue-50/70 px-3 py-2 text-xs text-blue-950">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-blue-700" />
        <span>
          {activeSite.siteCode} · {activeSite.siteName} — {strings.paymentLedgerTitle}
        </span>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-base font-bold text-slate-900">{strings.paymentLedgerTitle}</h2>
        {canEditPayments && workers.length > 0 && (
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={openAdvanceModal}
              className="flex min-h-[38px] items-center gap-1 rounded-xl border border-blue-200 bg-blue-50 px-2.5 py-1.5 text-xs font-semibold text-blue-800 hover:bg-blue-100 whitespace-nowrap"
            >
              <span>{strings.recordAdvanceBtn}</span>
            </button>
            <button
              type="button"
              onClick={() => openNewPaymentModal()}
              className="flex min-h-[38px] items-center gap-1 rounded-xl bg-blue-700 px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-blue-800 whitespace-nowrap"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>{strings.recordPayment}</span>
            </button>
          </div>
        )}
      </div>

      {!canEditPayments && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-medium text-amber-900">
          {strings.roleRestrictedAction}
        </div>
      )}

      {/* Worker-Wise Allocation-Based Balances */}
      <div className="space-y-2">
        {workerBalances.map(
          ({ worker, totalEarned, totalPaid, outstanding, unallocatedAdvance }) => {
            const name = language === 'bn' ? worker.fullNameBn : worker.fullNameEn;
            return (
              <div
                key={worker.id}
                className="rounded-2xl border border-slate-200 bg-white p-3.5"
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-2.5">
                    <WorkerAvatarView
                      name={name}
                      avatarUrl={worker.avatarUrl}
                      sizeClass="h-10 w-10"
                      iconSizeClass="h-4 w-4"
                    />
                    <div className="min-w-0">
                      <div className="truncate text-sm font-semibold text-slate-900">{name}</div>
                      <div className="font-mono text-[11px] text-slate-500">
                        {worker.localWorkerCode || worker.id}
                        {unallocatedAdvance > 0 && (
                          <span className="ml-2 font-sans font-semibold text-amber-700">
                            · {strings.unallocatedAdvancesLabel}: ৳{unallocatedAdvance}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {canEditPayments && (
                    <button
                      type="button"
                      onClick={() => openNewPaymentModal(worker.id)}
                      className="rounded-lg border border-blue-200 bg-blue-50 px-2.5 py-1.5 text-[11px] font-semibold text-blue-800 hover:bg-blue-100 whitespace-nowrap"
                    >
                      {strings.recordPayment}
                    </button>
                  )}
                </div>

                <div className="mt-2.5 grid grid-cols-3 gap-2 border-t border-slate-100 pt-2.5 text-xs">
                  <div>
                    <div className="text-[10px] text-slate-500">{strings.totalEarnedAmount}</div>
                    <div className="font-semibold text-slate-900 tabular-nums">
                      ৳{totalEarned.toLocaleString('en-US')}
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500">{strings.totalPaidAmount}</div>
                    <div className="font-semibold text-emerald-700 tabular-nums">
                      ৳{totalPaid.toLocaleString('en-US')}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] text-slate-500">{strings.remainingBalance}</div>
                    <div
                      className={`font-bold tabular-nums ${
                        outstanding < 0
                          ? 'text-rose-700'
                          : outstanding > 0
                            ? 'text-blue-800'
                            : 'text-emerald-700'
                      }`}
                    >
                      ৳{outstanding.toLocaleString('en-US')}
                    </div>
                  </div>
                </div>
              </div>
            );
          }
        )}
      </div>

      {/* Advance Records Section */}
      {advances.length > 0 && (
        <div className="pt-1">
          <h3 className="mb-2.5 text-sm font-semibold text-slate-800">
            {strings.unallocatedAdvancesLabel} ({advances.length})
          </h3>
          <div className="space-y-2">
            {advances.map((adv) => {
              const w = workerMap.get(adv.workerId);
              const name = w ? (language === 'bn' ? w.fullNameBn : w.fullNameEn) : adv.workerId;
              const remaining = computeAdvanceRemaining(adv, allocations);
              return (
                <div
                  key={adv.id}
                  className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-3.5"
                >
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-xs font-semibold text-slate-900">
                      {name} ({adv.id})
                    </div>
                    <div className="mt-0.5 truncate text-[11px] text-slate-500">
                      {adv.advanceDateIso} · {adv.referenceNo} · {adv.note}
                    </div>
                    <div className="mt-0.5 text-[11px] font-semibold text-amber-700 tabular-nums">
                      ৳{adv.amount} (Remaining: ৳{remaining})
                    </div>
                  </div>
                  {remaining > 0 && canEditPayments && (
                    <button
                      type="button"
                      onClick={() => {
                        setAllocateTarget(adv);
                        setAllocPeriod('2026-11');
                        setAllocAmount(String(remaining));
                        setAllocNote(`Applied ${adv.id}`);
                      }}
                      className="shrink-0 rounded-xl border border-blue-200 bg-blue-50 px-2.5 py-1.5 text-[11px] font-semibold text-blue-800 hover:bg-blue-100"
                    >
                      {strings.allocateAdvanceBtn}
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Transaction History */}
      <div className="pt-1">
        <h3 className="mb-2.5 text-sm font-semibold text-slate-800">
          {strings.transactionHistory} ({payments.length})
        </h3>
        <div className="space-y-2">
          {payments.map((entry) => {
            const w = workerMap.get(entry.workerId);
            const name = w ? (language === 'bn' ? w.fullNameBn : w.fullNameEn) : entry.workerId;
            const entryLocked = isPeriodFinalized(
              entry.applicablePeriod,
              payrollPeriods,
              entry.siteId
            );
            return (
              <div
                key={entry.id}
                className="flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-3.5"
              >
                <div className="flex min-w-0 flex-1 items-center gap-3">
                  <WorkerAvatarView
                    name={name}
                    avatarUrl={w?.avatarUrl ?? null}
                    sizeClass="h-9 w-9"
                    iconSizeClass="h-4 w-4"
                  />
                  <div className="min-w-0 flex-1">
                    <div
                      className={`truncate text-xs font-semibold ${
                        entry.isVoided ? 'text-slate-400 line-through' : 'text-slate-900'
                      }`}
                    >
                      {name} · {entry.id}
                    </div>
                    <div className="mt-0.5 text-[11px] font-semibold text-blue-800">
                      {strings.paymentDateLabel}: {entry.dateIso} ·{' '}
                      {strings.applicablePeriodLabel}: {entry.applicablePeriod}
                    </div>
                    <div className="mt-0.5 truncate text-[11px] text-slate-500">
                      {entry.referenceNo} · {language === 'bn' ? entry.noteBn : entry.noteEn}
                    </div>
                  </div>
                </div>

                <div className="shrink-0 text-right">
                  <div
                    className={`text-sm font-bold tabular-nums ${
                      entry.isVoided ? 'text-rose-700' : 'text-emerald-700'
                    }`}
                  >
                    {entry.isVoided ? strings.voidedLabel : `৳${entry.paidAmount}`}
                  </div>
                  {!entry.isVoided && canEditPayments && !entryLocked && (
                    <button
                      type="button"
                      onClick={() => setVoidTarget(entry)}
                      className="mt-0.5 text-[11px] font-semibold text-rose-700 hover:underline"
                    >
                      {strings.voidTransaction}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Payment Entry Modal */}
      {showEntryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">{strings.recordPayment}</h3>
              <button
                type="button"
                onClick={() => setShowEntryModal(false)}
                className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-3 space-y-2.5">
              <select
                value={selectedWorkerId}
                onChange={(e) => handleWorkerChange(e.target.value)}
                className="h-10 w-full rounded-xl border border-slate-300 bg-white px-3 text-sm"
              >
                {workers.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.localWorkerCode || w.id} ·{' '}
                    {language === 'bn' ? w.fullNameBn : w.fullNameEn}
                  </option>
                ))}
              </select>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-medium text-slate-600">
                    {strings.paymentDateLabel}
                  </label>
                  <input
                    type="date"
                    value={paymentDateIso}
                    onChange={(e) => setPaymentDateIso(e.target.value)}
                    className="mt-1 h-9 w-full rounded-xl border border-slate-300 px-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-600">
                    {strings.applicablePeriodLabel}
                  </label>
                  <select
                    value={applicablePeriod}
                    onChange={(e) => setApplicablePeriod(e.target.value)}
                    className="mt-1 h-9 w-full rounded-xl border border-slate-300 bg-white px-2 text-xs font-semibold"
                  >
                    {['2026-09', '2026-10', '2026-11', '2026-12'].map((p) => (
                      <option key={p} value={p}>
                        {p}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {selectedPeriodLocked && (
                <div className="rounded-xl border border-rose-200 bg-rose-50 px-2.5 py-2 text-[11px] text-rose-800">
                  {strings.payrollLockedWarning}
                </div>
              )}

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() =>
                    setPaidAmount(String(Math.max(0, selectedBalance.outstanding)))
                  }
                  className="rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2 text-xs font-semibold text-slate-700"
                >
                  {strings.fullPaymentBtn} (৳{Math.max(0, selectedBalance.outstanding)})
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setPaidAmount(
                      String(Math.floor(Math.max(0, selectedBalance.outstanding) / 2))
                    )
                  }
                  className="rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-2 text-xs font-semibold text-slate-700"
                >
                  {strings.partialPaymentBtn} (৳
                  {Math.floor(Math.max(0, selectedBalance.outstanding) / 2)})
                </button>
              </div>

              <input
                type="number"
                min={1}
                required
                value={paidAmount}
                onChange={(e) => setPaidAmount(e.target.value)}
                placeholder={strings.paymentAmountLabel}
                className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm tabular-nums"
              />
              <input
                type="text"
                value={referenceNo}
                onChange={(e) => setReferenceNo(e.target.value)}
                placeholder={strings.referenceNoLabel}
                className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm"
              />
              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder={strings.paymentNoteLabel}
                className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm"
              />

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowEntryModal(false)}
                  className="min-h-[40px] rounded-xl px-4 py-2 text-xs font-semibold text-slate-600"
                >
                  {strings.cancel}
                </button>
                <button
                  type="submit"
                  disabled={selectedPeriodLocked}
                  className="min-h-[40px] rounded-xl bg-blue-700 px-4 py-2 text-xs font-semibold text-white disabled:opacity-50"
                >
                  {strings.saveEntry}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Advance Entry Modal */}
      {showAdvanceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
            <h3 className="text-base font-bold text-slate-900">{strings.recordAdvanceBtn}</h3>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const amt = Math.trunc(Number(advAmount));
                if (!Number.isFinite(amt) || amt <= 0 || !advWorkerId) return;
                onRecordAdvance({
                  workerId: advWorkerId,
                  advanceDateIso: advDateIso || '2026-11-15',
                  amount: amt,
                  referenceNo: advRef.trim() || 'ADV',
                  note: advNote.trim() || 'Site advance',
                  submissionToken: advToken,
                });
                setShowAdvanceModal(false);
              }}
              className="mt-3 space-y-2.5"
            >
              <select
                value={advWorkerId}
                onChange={(e) => setAdvWorkerId(e.target.value)}
                className="h-10 w-full rounded-xl border border-slate-300 bg-white px-3 text-sm"
              >
                {workers.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.localWorkerCode || w.id} ·{' '}
                    {language === 'bn' ? w.fullNameBn : w.fullNameEn}
                  </option>
                ))}
              </select>
              <input
                type="date"
                value={advDateIso}
                onChange={(e) => setAdvDateIso(e.target.value)}
                className="h-9 w-full rounded-xl border border-slate-300 px-3 text-xs"
              />
              <input
                type="number"
                min={1}
                required
                value={advAmount}
                onChange={(e) => setAdvAmount(e.target.value)}
                placeholder={strings.paymentAmountLabel}
                className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm tabular-nums"
              />
              <input
                type="text"
                value={advRef}
                onChange={(e) => setAdvRef(e.target.value)}
                placeholder={strings.referenceNoLabel}
                className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm"
              />
              <input
                type="text"
                value={advNote}
                onChange={(e) => setAdvNote(e.target.value)}
                placeholder={strings.notesLabel}
                className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm"
              />
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowAdvanceModal(false)}
                  className="min-h-[38px] rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-600"
                >
                  {strings.cancel}
                </button>
                <button
                  type="submit"
                  className="min-h-[38px] rounded-xl bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white"
                >
                  {strings.saveEntry}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Allocate Advance Modal */}
      {allocateTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
            <h3 className="text-sm font-bold text-slate-900">
              {strings.allocateAdvanceBtn} ({allocateTarget.id})
            </h3>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (allocPeriodLocked) return;
                const rem = computeAdvanceRemaining(allocateTarget, allocations);
                const amt = Math.min(rem, Math.trunc(Number(allocAmount)));
                if (amt > 0) {
                  onAllocateAdvance({
                    advanceId: allocateTarget.id,
                    targetPeriod: allocPeriod,
                    amountToAllocate: amt,
                    note: allocNote.trim() || `Applied ${allocateTarget.id}`,
                  });
                  setAllocateTarget(null);
                }
              }}
              className="mt-3 space-y-2.5"
            >
              <select
                value={allocPeriod}
                onChange={(e) => setAllocPeriod(e.target.value)}
                className="h-9 w-full rounded-xl border border-slate-300 bg-white px-2 text-xs font-semibold"
              >
                {['2026-09', '2026-10', '2026-11', '2026-12'].map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
              {allocPeriodLocked && (
                <div className="rounded-xl border border-rose-200 bg-rose-50 px-2.5 py-2 text-[11px] text-rose-800">
                  {strings.payrollLockedWarning}
                </div>
              )}
              <input
                type="number"
                min={1}
                max={computeAdvanceRemaining(allocateTarget, allocations)}
                required
                value={allocAmount}
                onChange={(e) => setAllocAmount(e.target.value)}
                className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm tabular-nums"
              />
              <input
                type="text"
                value={allocNote}
                onChange={(e) => setAllocNote(e.target.value)}
                placeholder={strings.notesLabel}
                className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm"
              />
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setAllocateTarget(null)}
                  className="min-h-[38px] rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-600"
                >
                  {strings.cancel}
                </button>
                <button
                  type="submit"
                  disabled={allocPeriodLocked}
                  className="min-h-[38px] rounded-xl bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white disabled:opacity-50"
                >
                  {strings.confirmAction}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Void Confirmation Modal */}
      {voidTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
            <h3 className="text-sm font-bold text-slate-900">{strings.voidTransaction}</h3>
            <p className="mt-2 text-xs leading-relaxed text-slate-600">
              {strings.confirmVoidPaymentMsg}
            </p>
            <div className="mt-4 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setVoidTarget(null)}
                className="min-h-[38px] rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-600"
              >
                {strings.cancel}
              </button>
              <button
                type="button"
                onClick={() => {
                  onVoidPayment(voidTarget.id, 'Voided from Payment Ledger');
                  setVoidTarget(null);
                }}
                className="min-h-[38px] rounded-xl bg-rose-700 px-3.5 py-2 text-xs font-semibold text-white"
              >
                {strings.confirmAction}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
