import { useMemo, useState } from 'react';
import {
  CheckCircle2,
  Download,
  FileSpreadsheet,
  Info,
  Printer,
  X,
} from 'lucide-react';
import {
  BilingualUiStrings,
  PERIOD_LOCK_LABELS,
  WORK_CATEGORY_LABELS,
} from '../../data/bilingualStrings';
import {
  AppLanguage,
  DailyAttendanceRecord,
  PaymentAllocation,
  PayrollPeriodRecord,
  Site,
  SiteExpense,
  WorkCategory,
  Worker,
} from '../../types/siteLedger';
import {
  buildAllWorkersPayrollPdfBytes,
  buildPrintableAttendanceHtml,
  buildSpreadsheetExcelXml,
  triggerBlobDownload,
} from '../../utils/payrollExport';
import {
  computeAllSitesOverview,
  computeSpreadsheetTotals,
  computeWorkerMonthlySummary,
  formatMonthPrefix,
  formatPeriodIso,
  isPeriodFinalized,
  sumDutyUnits,
} from '../../utils/wageCalculator';
import { WorkerAvatarView } from './WorkerAvatarView';

interface ReportsScreenViewProps {
  strings: BilingualUiStrings;
  language: AppLanguage;
  activeSite: Site;
  sites: Site[];
  allowedSiteIds: Set<string>;
  workers: Worker[];
  allWorkers: Worker[];
  attendanceRecords: DailyAttendanceRecord[];
  allAttendanceRecords: DailyAttendanceRecord[];
  allocations: PaymentAllocation[];
  allAllocations: PaymentAllocation[];
  payrollPeriods: PayrollPeriodRecord[];
  expenses: SiteExpense[];
  allExpenses: SiteExpense[];
}

export function ReportsScreenView({
  strings,
  language,
  activeSite,
  sites,
  allowedSiteIds,
  workers,
  allWorkers,
  attendanceRecords,
  allAttendanceRecords,
  allocations,
  allAllocations,
  payrollPeriods,
  expenses,
  allExpenses,
}: ReportsScreenViewProps) {
  const [selectedYear, setSelectedYear] = useState(2026);
  const [selectedMonth, setSelectedMonth] = useState(11);
  const [selectedCategory, setSelectedCategory] = useState<'ALL' | WorkCategory>('ALL');
  const [selectedWorkerId, setSelectedWorkerId] = useState<string>('ALL');
  const [exportNotice, setExportNotice] = useState<string | null>(null);
  const [printPreviewHtml, setPrintPreviewHtml] = useState<string | null>(null);

  const periodIso = formatPeriodIso(selectedYear, selectedMonth);
  const monthPrefix = formatMonthPrefix(selectedYear, selectedMonth);
  const periodLocked = isPeriodFinalized(periodIso, payrollPeriods, activeSite.id);

  const filteredWorkers = useMemo(() => {
    return workers.filter((w) => {
      const catMatch = selectedCategory === 'ALL' || w.category === selectedCategory;
      const workerMatch = selectedWorkerId === 'ALL' || w.id === selectedWorkerId;
      return catMatch && workerMatch;
    });
  }, [workers, selectedCategory, selectedWorkerId]);

  const workerSummaries = useMemo(() => {
    return filteredWorkers.map((w) =>
      computeWorkerMonthlySummary(
        w,
        selectedYear,
        selectedMonth,
        attendanceRecords,
        allocations,
        payrollPeriods,
        activeSite.id,
        { [activeSite.id]: activeSite }
      )
    );
  }, [
    filteredWorkers,
    selectedYear,
    selectedMonth,
    attendanceRecords,
    allocations,
    payrollPeriods,
    activeSite,
  ]);

  const filteredWorkerIds = useMemo(
    () => new Set(filteredWorkers.map((w) => w.id)),
    [filteredWorkers]
  );

  const monthlyGeneralExpenses = useMemo(
    () =>
      expenses
        .filter((e) => !e.isVoided && e.expenseDateIso.startsWith(monthPrefix))
        .reduce((sum, e) => sum + e.amount, 0),
    [expenses, monthPrefix]
  );

  const yearlyGeneralExpenses = useMemo(() => {
    const yearPrefix = `${String(selectedYear).padStart(4, '0')}-`;
    return expenses
      .filter((e) => !e.isVoided && e.expenseDateIso.startsWith(yearPrefix))
      .reduce((sum, e) => sum + e.amount, 0);
  }, [expenses, selectedYear]);

  const allSitesOverview = useMemo(
    () =>
      computeAllSitesOverview(
        sites,
        allWorkers,
        allAttendanceRecords,
        allAllocations,
        allExpenses,
        periodIso,
        allowedSiteIds
      ),
    [sites, allWorkers, allAttendanceRecords, allAllocations, allExpenses, periodIso, allowedSiteIds]
  );

  const dailySiteSummary = useMemo(() => {
    const monthRecords = attendanceRecords.filter(
      (r) => r.dateIso.startsWith(monthPrefix) && filteredWorkerIds.has(r.workerId)
    );
    const byDate = new Map<string, DailyAttendanceRecord[]>();
    for (const r of monthRecords) {
      const list = byDate.get(r.dateIso) ?? [];
      list.push(r);
      byDate.set(r.dateIso, list);
    }
    return Array.from(byDate.entries())
      .sort(([a], [b]) => b.localeCompare(a))
      .map(([dateIso, recs]) => ({
        dateIso,
        workerCount: recs.filter(
          (r) => r.dutyType !== 'ABSENT' && r.dutyType !== 'LEAVE'
        ).length,
        dutyUnits: sumDutyUnits(recs),
        earned: recs.reduce((s, r) => s + r.earnedAmount, 0),
      }));
  }, [attendanceRecords, monthPrefix, filteredWorkerIds]);

  const monthlyTotals = useMemo(() => {
    let totalDutyUnitsHundredths = 0;
    let totalEarned = 0;
    let totalPaid = 0;
    let halfCount = 0;
    let fullCount = 0;
    let oneAndHalfCount = 0;
    let doubleCount = 0;
    let twoAndHalfCount = 0;
    let tripleCount = 0;
    let absentCount = 0;
    let leaveCount = 0;

    for (const s of workerSummaries) {
      totalDutyUnitsHundredths += Math.round(s.totalDutyUnits * 100);
      totalEarned += s.totalEarnedAmount;
      totalPaid += s.totalPaidAmount;
      halfCount += s.halfDutyCount;
      fullCount += s.fullDutyCount;
      oneAndHalfCount += s.oneAndHalfDutyCount;
      doubleCount += s.doubleDutyCount;
      twoAndHalfCount += s.twoAndHalfDutyCount;
      tripleCount += s.tripleDutyCount;
      absentCount += s.absentCount;
      leaveCount += s.leaveCount;
    }

    return {
      totalDutyUnits: totalDutyUnitsHundredths / 100,
      totalEarned,
      totalPaid,
      outstanding: totalEarned - totalPaid,
      halfCount,
      fullCount,
      oneAndHalfCount,
      doubleCount,
      twoAndHalfCount,
      tripleCount,
      absentCount,
      leaveCount,
    };
  }, [workerSummaries]);

  const yearlyTotals = useMemo(() => {
    const yearPrefix = `${String(selectedYear).padStart(4, '0')}-`;
    const yearRecords = attendanceRecords.filter(
      (r) => r.dateIso.startsWith(yearPrefix) && filteredWorkerIds.has(r.workerId)
    );
    const yearAllocations = allocations.filter(
      (a) =>
        !a.isVoided &&
        a.payrollPeriod.startsWith(yearPrefix) &&
        filteredWorkerIds.has(a.workerId)
    );
    const earned = yearRecords.reduce((s, r) => s + r.earnedAmount, 0);
    const paid = yearAllocations.reduce((s, a) => s + a.allocatedAmount, 0);
    return {
      dutyUnits: sumDutyUnits(yearRecords),
      earned,
      paid,
      outstanding: earned - paid,
    };
  }, [attendanceRecords, allocations, selectedYear, filteredWorkerIds]);

  const spreadsheetTotals = useMemo(
    () => computeSpreadsheetTotals(workerSummaries),
    [workerSummaries]
  );

  const handleExportExcel = () => {
    const filename = `site_ledger_report_${activeSite.siteCode}_${periodIso}.xls`;
    const xml = buildSpreadsheetExcelXml(
      language,
      periodIso,
      workerSummaries,
      spreadsheetTotals,
      activeSite.siteName,
      false
    );
    triggerBlobDownload(filename, xml, 'application/vnd.ms-excel');
    setExportNotice(filename);
  };

  const handleExportPdf = () => {
    const filename = `site_ledger_report_${activeSite.siteCode}_${periodIso}.pdf`;
    const pdfBytes = buildAllWorkersPayrollPdfBytes(
      periodIso,
      workerSummaries,
      spreadsheetTotals,
      activeSite.siteName,
      false
    );
    triggerBlobDownload(filename, pdfBytes, 'application/pdf');
    setExportNotice(filename);
  };

  const handleOpenPrintPreview = () => {
    setPrintPreviewHtml(
      buildPrintableAttendanceHtml(
        language,
        periodIso,
        workerSummaries,
        spreadsheetTotals,
        activeSite.siteName,
        false
      )
    );
  };

  return (
    <div className="space-y-4 p-4">
      <div className="flex items-start gap-2.5 rounded-xl border border-blue-200 bg-blue-50/70 px-3 py-2 text-xs text-blue-950">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-blue-700" />
        <span>
          {activeSite.siteCode} · {activeSite.siteName} — {strings.navReports}
        </span>
      </div>

      {/* Quick Previous / Current Month Selector */}
      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => {
            setSelectedYear(2026);
            setSelectedMonth(10);
          }}
          className={`min-h-[38px] rounded-xl border px-3 py-1.5 text-xs font-semibold transition-colors ${
            selectedYear === 2026 && selectedMonth === 10
              ? 'border-blue-700 bg-blue-50 text-blue-800'
              : 'border-slate-200 bg-white text-slate-700'
          }`}
        >
          {language === 'bn' ? 'পূর্ববর্তী মাস (২০২৬-১০)' : 'Previous Month (2026-10)'}
        </button>
        <button
          type="button"
          onClick={() => {
            setSelectedYear(2026);
            setSelectedMonth(11);
          }}
          className={`min-h-[38px] rounded-xl border px-3 py-1.5 text-xs font-semibold transition-colors ${
            selectedYear === 2026 && selectedMonth === 11
              ? 'border-blue-700 bg-blue-50 text-blue-800'
              : 'border-slate-200 bg-white text-slate-700'
          }`}
        >
          {language === 'bn' ? 'চলতি মাস (২০২৬-১১)' : 'Current Month (2026-11)'}
        </button>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-2 gap-2 rounded-2xl border border-slate-200 bg-white p-3">
        <div>
          <label className="block text-[11px] font-semibold text-slate-500">
            {strings.selectYear}
          </label>
          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(Number(e.target.value))}
            className="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-2 text-xs font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
          >
            {[2025, 2026, 2027].map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-slate-500">
            {strings.selectMonth}
          </label>
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(Number(e.target.value))}
            className="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-2 text-xs font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
          >
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((m) => (
              <option key={m} value={m}>
                {String(m).padStart(2, '0')}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-slate-500">
            {strings.categoryLabel}
          </label>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value as 'ALL' | WorkCategory)}
            className="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-2 text-xs font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
          >
            <option value="ALL">{strings.allFilter}</option>
            {(Object.keys(WORK_CATEGORY_LABELS) as WorkCategory[]).map((cat) => (
              <option key={cat} value={cat}>
                {language === 'bn'
                  ? WORK_CATEGORY_LABELS[cat].bn
                  : WORK_CATEGORY_LABELS[cat].en}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-slate-500">
            {strings.navWorkers}
          </label>
          <select
            value={selectedWorkerId}
            onChange={(e) => setSelectedWorkerId(e.target.value)}
            className="mt-1 h-9 w-full rounded-lg border border-slate-300 bg-white px-2 text-xs font-semibold text-slate-900 focus:border-blue-600 focus:outline-none"
          >
            <option value="ALL">{strings.allFilter}</option>
            {workers.map((w) => (
              <option key={w.id} value={w.id}>
                {w.localWorkerCode || w.id} · {language === 'bn' ? w.fullNameBn : w.fullNameEn}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Offline Exports */}
      <div className="grid grid-cols-3 gap-2">
        <button
          type="button"
          onClick={handleExportExcel}
          className="flex min-h-[38px] items-center justify-center gap-1 rounded-xl border border-slate-200 bg-white px-2 text-[11px] font-semibold text-slate-800 hover:bg-slate-50"
        >
          <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-700" />
          <span className="truncate">{strings.exportExcelBtn}</span>
        </button>
        <button
          type="button"
          onClick={handleExportPdf}
          className="flex min-h-[38px] items-center justify-center gap-1 rounded-xl border border-slate-200 bg-white px-2 text-[11px] font-semibold text-slate-800 hover:bg-slate-50"
        >
          <Download className="h-3.5 w-3.5 text-blue-700" />
          <span className="truncate">{strings.exportAllPdfBtn}</span>
        </button>
        <button
          type="button"
          onClick={handleOpenPrintPreview}
          className="flex min-h-[38px] items-center justify-center gap-1 rounded-xl border border-slate-200 bg-white px-2 text-[11px] font-semibold text-slate-800 hover:bg-slate-50"
        >
          <Printer className="h-3.5 w-3.5 text-slate-700" />
          <span className="truncate">{strings.printAttendanceBtn}</span>
        </button>
      </div>

      {exportNotice && (
        <div className="flex items-center justify-between gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-[11px] font-semibold text-emerald-900">
          <span className="flex items-center gap-1.5 truncate">
            <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
            <span className="truncate">
              {strings.exportSuccessNotice} {exportNotice}
            </span>
          </span>
          <button
            type="button"
            onClick={() => setExportNotice(null)}
            className="text-[10px] underline"
          >
            OK
          </button>
        </div>
      )}

      {/* Monthly Site Summary (Payroll + Separated General Site Expenses) */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <div className="flex items-center justify-between gap-2">
          <h3 className="text-sm font-bold text-slate-900">
            {strings.monthlySiteSummary} ({periodIso})
          </h3>
          <span
            className={`rounded-md px-2 py-0.5 text-[10px] font-bold ${
              periodLocked
                ? 'bg-amber-100 text-amber-800'
                : 'bg-emerald-50 text-emerald-800'
            }`}
          >
            {language === 'bn'
              ? PERIOD_LOCK_LABELS[periodLocked ? 'FINALIZED' : 'OPEN'].bn
              : PERIOD_LOCK_LABELS[periodLocked ? 'FINALIZED' : 'OPEN'].en}
          </span>
        </div>
        <div className="mt-2.5 divide-y divide-slate-100 text-xs">
          <div className="flex items-center justify-between py-2">
            <span className="text-slate-600">
              {strings.halfDutyLabel} / {strings.fullDutyLabel} / {strings.oneAndHalfDutyLabel}
            </span>
            <span className="font-semibold text-slate-900 tabular-nums">
              {monthlyTotals.halfCount} / {monthlyTotals.fullCount} /{' '}
              {monthlyTotals.oneAndHalfCount}
            </span>
          </div>
          <div className="flex items-center justify-between py-2">
            <span className="text-slate-600">
              {strings.doubleDutyLabel} / {strings.twoAndHalfDutyLabel} / {strings.tripleDutyLabel}
            </span>
            <span className="font-semibold text-slate-900 tabular-nums">
              {monthlyTotals.doubleCount} / {monthlyTotals.twoAndHalfCount} /{' '}
              {monthlyTotals.tripleCount}
            </span>
          </div>
          <div className="flex items-center justify-between py-2">
            <span className="text-slate-600">
              {strings.absentLabel} / {strings.leaveLabel}
            </span>
            <span className="font-semibold text-slate-900 tabular-nums">
              {monthlyTotals.absentCount} / {monthlyTotals.leaveCount}
            </span>
          </div>
          <div className="flex items-center justify-between py-2">
            <span className="text-slate-600">{strings.totalDutyUnits}</span>
            <span className="font-bold text-slate-900 tabular-nums">
              {monthlyTotals.totalDutyUnits.toFixed(1)}
            </span>
          </div>
          <div className="flex items-center justify-between py-2">
            <span className="text-slate-600">{strings.monthlyTotalEarned}</span>
            <span className="font-bold text-slate-900 tabular-nums">
              ৳{monthlyTotals.totalEarned.toLocaleString('en-US')}
            </span>
          </div>
          <div className="flex items-center justify-between py-2">
            <span className="text-slate-600">{strings.monthlyTotalPaid}</span>
            <span className="font-bold text-emerald-700 tabular-nums">
              ৳{monthlyTotals.totalPaid.toLocaleString('en-US')}
            </span>
          </div>
          <div className="flex items-center justify-between py-2">
            <span className="text-slate-600">{strings.monthlyOutstanding}</span>
            <span className="font-bold text-blue-800 tabular-nums">
              ৳{monthlyTotals.outstanding.toLocaleString('en-US')}
            </span>
          </div>
          <div className="flex items-center justify-between pt-2.5 font-bold">
            <span className="text-slate-800">{strings.generalExpensesCardLabel}</span>
            <span className="text-amber-700 tabular-nums">
              ৳{monthlyGeneralExpenses.toLocaleString('en-US')}
            </span>
          </div>
        </div>
      </div>

      {/* Yearly Summary */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <h3 className="text-sm font-bold text-slate-900">
          {strings.yearlyPayrollSummary} ({selectedYear})
        </h3>
        <div className="mt-2.5 grid grid-cols-2 gap-2.5 text-xs">
          <div className="rounded-xl border border-slate-100 bg-slate-50 p-2.5">
            <div className="text-[11px] text-slate-500">{strings.totalEarnedAmount}</div>
            <div className="mt-0.5 font-bold text-slate-900 tabular-nums">
              ৳{yearlyTotals.earned.toLocaleString('en-US')}
            </div>
          </div>
          <div className="rounded-xl border border-slate-100 bg-slate-50 p-2.5">
            <div className="text-[11px] text-slate-500">{strings.totalPaidAmount}</div>
            <div className="mt-0.5 font-bold text-emerald-700 tabular-nums">
              ৳{yearlyTotals.paid.toLocaleString('en-US')}
            </div>
          </div>
          <div className="rounded-xl border border-amber-100 bg-amber-50/50 p-2.5">
            <div className="text-[11px] text-amber-800">{strings.generalExpensesCardLabel}</div>
            <div className="mt-0.5 font-bold text-amber-900 tabular-nums">
              ৳{yearlyGeneralExpenses.toLocaleString('en-US')}
            </div>
          </div>
          <div className="rounded-xl border border-blue-100 bg-blue-50/50 p-2.5">
            <div className="text-[11px] text-blue-700">{strings.remainingBalance}</div>
            <div className="mt-0.5 font-bold text-blue-900 tabular-nums">
              ৳{yearlyTotals.outstanding.toLocaleString('en-US')}
            </div>
          </div>
        </div>
      </div>

      {/* All Sites Consolidated Comparison */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <h3 className="mb-2 text-sm font-bold text-slate-900">
          {strings.allSitesToggleLabel} ({periodIso})
        </h3>
        <div className="space-y-2 text-xs">
          {allSitesOverview.perSiteSummaries.map((s) => (
            <div
              key={s.site.id}
              className="rounded-xl border border-slate-100 bg-slate-50 p-2.5"
            >
              <div className="font-semibold text-slate-900">
                {s.site.siteCode} · {s.site.siteName}
              </div>
              <div className="mt-1 flex justify-between text-[11px] tabular-nums text-slate-600">
                <span>Earned: ৳{s.totalEarnedPayroll}</span>
                <span>Paid: ৳{s.totalPaidPayroll}</span>
                <span className="text-amber-700">Exp: ৳{s.totalGeneralExpenses}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Daily Site Attendance */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4">
        <h3 className="mb-2.5 text-sm font-bold text-slate-900">
          {strings.dailySiteAttendance}
        </h3>
        {dailySiteSummary.length === 0 ? (
          <p className="text-xs text-slate-500">{strings.notRecordedLabel}</p>
        ) : (
          <div className="divide-y divide-slate-100 text-xs">
            {dailySiteSummary.map((row) => (
              <div
                key={row.dateIso}
                className="flex items-center justify-between gap-2 py-2"
              >
                <div>
                  <div className="font-mono font-semibold text-slate-900">
                    {row.dateIso}
                  </div>
                  <div className="text-[11px] text-slate-500 tabular-nums">
                    {row.workerCount} {strings.navWorkers} · {row.dutyUnits.toFixed(1)}{' '}
                    {strings.dutyUnitsLabel}
                  </div>
                </div>
                <div className="font-bold text-blue-800 tabular-nums">
                  ৳{row.earned.toLocaleString('en-US')}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Worker-Wise Monthly Breakdown */}
      <div>
        <h3 className="mb-2.5 text-sm font-bold text-slate-900">
          {strings.workerWiseReportTitle}
        </h3>
        <div className="space-y-2">
          {workerSummaries.map((s) => {
            const name = language === 'bn' ? s.worker.fullNameBn : s.worker.fullNameEn;
            return (
              <div
                key={s.worker.id}
                className="rounded-2xl border border-slate-200 bg-white p-3.5"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex min-w-0 items-center gap-2.5">
                    <WorkerAvatarView
                      name={name}
                      avatarUrl={s.worker.avatarUrl}
                      sizeClass="h-9 w-9"
                      iconSizeClass="h-4 w-4"
                    />
                    <div className="min-w-0">
                      <div className="truncate text-xs font-semibold text-slate-900">
                        {name}
                      </div>
                      <div className="font-mono text-[11px] text-slate-500">
                        {s.worker.localWorkerCode || s.worker.id} · {s.totalDutyUnits.toFixed(1)}{' '}
                        {strings.dutyUnitsLabel}
                      </div>
                    </div>
                  </div>
                  <div className="shrink-0 text-right text-xs">
                    <div className="font-bold text-blue-800 tabular-nums">
                      ৳{s.outstandingBalance.toLocaleString('en-US')}
                    </div>
                    <div className="text-[10px] text-slate-500">{strings.remainingBalance}</div>
                  </div>
                </div>

                <div className="mt-2 grid grid-cols-2 gap-2 border-t border-slate-100 pt-2 text-[11px] tabular-nums">
                  <div>
                    <span className="text-slate-500">{strings.totalEarnedAmount}: </span>
                    <span className="font-semibold text-slate-900">
                      ৳{s.totalEarnedAmount}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-slate-500">{strings.totalPaidAmount}: </span>
                    <span className="font-semibold text-emerald-700">
                      ৳{s.totalPaidAmount}
                    </span>
                  </div>
                  <div className="col-span-2 text-slate-600">
                    H:{s.halfDutyCount} F:{s.fullDutyCount} 1.5:{s.oneAndHalfDutyCount} D:{s.doubleDutyCount} 2.5:{s.twoAndHalfDutyCount} T:{s.tripleDutyCount} A:{s.absentCount} L:{s.leaveCount}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Printable Attendance Sheet Preview Modal */}
      {printPreviewHtml && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-3">
          <div className="flex max-h-[85vh] w-full max-w-md flex-col overflow-hidden rounded-2xl bg-white shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
              <h3 className="text-sm font-bold text-slate-900">
                {strings.printAttendanceBtn} ({periodIso})
              </h3>
              <button
                type="button"
                onClick={() => setPrintPreviewHtml(null)}
                className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <iframe
              title={`Printable Attendance ${periodIso}`}
              srcDoc={printPreviewHtml}
              className="h-80 w-full border-0 bg-white"
            />
            <div className="flex gap-2 border-t border-slate-200 p-3">
              <button
                type="button"
                onClick={() => setPrintPreviewHtml(null)}
                className="min-h-[38px] flex-1 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700"
              >
                {strings.close}
              </button>
              <button
                type="button"
                onClick={() => {
                  const filename = `site_ledger_attendance_sheet_${periodIso}.html`;
                  triggerBlobDownload(filename, printPreviewHtml, 'text/html');
                  setExportNotice(filename);
                  setPrintPreviewHtml(null);
                }}
                className="min-h-[38px] flex-1 rounded-xl bg-blue-700 text-xs font-semibold text-white hover:bg-blue-800"
              >
                Download HTML Sheet
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
