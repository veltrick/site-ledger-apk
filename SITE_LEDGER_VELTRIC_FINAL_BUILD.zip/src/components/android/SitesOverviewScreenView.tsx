import { useMemo, useState } from 'react';
import {
  Archive,
  Building2,
  Check,
  Edit3,
  Plus,
  ShieldCheck,
  X,
} from 'lucide-react';
import {
  BilingualUiStrings,
  SITE_STATUS_LABELS,
  USER_ROLE_LABELS,
} from '../../data/bilingualStrings';
import {
  AppLanguage,
  DailyAttendanceRecord,
  PaymentAllocation,
  Site,
  SiteExpense,
  SiteStatus,
  UserRole,
  UserSiteAccount,
  Worker,
} from '../../types/siteLedger';
import { computeAllSitesOverview } from '../../utils/wageCalculator';

interface SitesOverviewScreenViewProps {
  strings: BilingualUiStrings;
  language: AppLanguage;
  activeRole: UserRole;
  activeSiteId: string;
  sites: Site[];
  allowedSiteIds: Set<string>;
  workers: Worker[];
  attendanceRecords: DailyAttendanceRecord[];
  allocations: PaymentAllocation[];
  expenses: SiteExpense[];
  userSiteAccounts: UserSiteAccount[];
  onSelectSite: (siteId: string) => void;
  onSaveSite: (site: Site) => void;
  onArchiveSite: (siteId: string) => void;
  onUpdateRoleSiteAssignments: (role: UserRole, assignedSiteIds: string[]) => void;
}

export function SitesOverviewScreenView({
  strings,
  language,
  activeRole,
  activeSiteId,
  sites,
  allowedSiteIds,
  workers,
  attendanceRecords,
  allocations,
  expenses,
  userSiteAccounts,
  onSelectSite,
  onSaveSite,
  onArchiveSite,
  onUpdateRoleSiteAssignments,
}: SitesOverviewScreenViewProps) {
  const [showSiteModal, setShowSiteModal] = useState(false);
  const [editingSite, setEditingSite] = useState<Site | null>(null);

  const isAdmin = activeRole === 'ADMIN';

  const overview = useMemo(
    () =>
      computeAllSitesOverview(
        sites,
        workers,
        attendanceRecords,
        allocations,
        expenses,
        null,
        allowedSiteIds
      ),
    [sites, workers, attendanceRecords, allocations, expenses, allowedSiteIds]
  );

  return (
    <div className="space-y-3.5 p-4">
      <div className="flex items-center justify-between gap-2">
        <h2 className="text-base font-bold text-slate-900">
          {strings.sitesOverviewTitle}
        </h2>
        {isAdmin && (
          <button
            type="button"
            onClick={() => {
              setEditingSite(null);
              setShowSiteModal(true);
            }}
            className="flex min-h-[38px] items-center gap-1 rounded-xl bg-blue-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-800 whitespace-nowrap"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>{strings.addSiteBtn}</span>
          </button>
        )}
      </div>

      {/* Combined All-Sites Financial Overview (Strict Separation of Payroll vs Site Expenses) */}
      <div className="grid grid-cols-2 gap-2.5">
        <div className="rounded-2xl border border-slate-200 bg-white p-3">
          <div className="text-[11px] font-medium text-slate-500">
            {strings.monthlyExpenses}
          </div>
          <div className="mt-1 text-base font-bold text-slate-900 tabular-nums">
            ৳{overview.combinedEarnedPayroll.toLocaleString('en-US')}
          </div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-3">
          <div className="text-[11px] font-medium text-slate-500">
            {strings.paidPayrollCardLabel}
          </div>
          <div className="mt-1 text-base font-bold text-emerald-700 tabular-nums">
            ৳{overview.combinedPaidPayroll.toLocaleString('en-US')}
          </div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-3">
          <div className="text-[11px] font-medium text-slate-500">
            {strings.generalExpensesCardLabel}
          </div>
          <div className="mt-1 text-base font-bold text-amber-700 tabular-nums">
            ৳{overview.combinedGeneralExpenses.toLocaleString('en-US')}
          </div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-3">
          <div className="text-[11px] font-medium text-slate-500">
            {strings.outstandingPayrollCardLabel}
          </div>
          <div className="mt-1 text-base font-bold text-blue-800 tabular-nums">
            ৳{overview.combinedOutstandingPayroll.toLocaleString('en-US')}
          </div>
        </div>
      </div>

      {/* Site Cards List */}
      <div className="space-y-2.5">
        {overview.perSiteSummaries.map((summary) => {
          const s = summary.site;
          const isCurrent = s.id === activeSiteId;
          const statusLabel =
            language === 'bn'
              ? SITE_STATUS_LABELS[s.status].bn
              : SITE_STATUS_LABELS[s.status].en;

          return (
            <div
              key={s.id}
              className={`rounded-2xl border bg-white p-3.5 transition-colors ${
                isCurrent ? 'border-blue-700 ring-1 ring-blue-700/20' : 'border-slate-200'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <button
                  type="button"
                  onClick={() => onSelectSite(s.id)}
                  className="min-w-0 flex-1 text-left"
                >
                  <div className="flex items-center gap-1.5">
                    <Building2 className="h-3.5 w-3.5 shrink-0 text-blue-700" />
                    <span className="font-mono text-xs font-bold text-blue-800">
                      {s.siteCode}
                    </span>
                    <span className="truncate text-sm font-bold text-slate-900">
                      {s.siteName}
                    </span>
                  </div>
                  <div className="mt-0.5 truncate text-[11px] text-slate-500">
                    {s.address} · {s.siteManager}
                  </div>
                </button>

                <div className="flex shrink-0 items-center gap-1">
                  <span
                    className={`rounded-md px-1.5 py-0.5 text-[10px] font-bold ${
                      s.status === 'ACTIVE'
                        ? 'bg-emerald-50 text-emerald-700'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {statusLabel}
                  </span>
                  {isAdmin && (
                    <button
                      type="button"
                      onClick={() => {
                        setEditingSite(s);
                        setShowSiteModal(true);
                      }}
                      className="rounded-lg p-1 text-slate-500 hover:bg-slate-100 hover:text-blue-700"
                      aria-label={strings.editSiteBtn}
                    >
                      <Edit3 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </div>

              <div className="mt-2.5 grid grid-cols-4 gap-1 border-t border-slate-100 pt-2 text-[11px] tabular-nums">
                <div>
                  <div className="text-[10px] text-slate-400">{strings.navWorkers}</div>
                  <div className="font-bold text-slate-900">
                    {summary.activeWorkersCount}/{summary.totalWorkersCount}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-400">{strings.monthlyExpenses}</div>
                  <div className="font-bold text-slate-900">
                    ৳{summary.totalEarnedPayroll.toLocaleString('en-US')}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-400">{strings.generalExpensesCardLabel}</div>
                  <div className="font-bold text-amber-700">
                    ৳{summary.totalGeneralExpenses.toLocaleString('en-US')}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-slate-400">{strings.outstandingPayrollCardLabel}</div>
                  <div className="font-bold text-blue-800">
                    ৳{summary.totalOutstandingPayroll.toLocaleString('en-US')}
                  </div>
                </div>
              </div>

              <div className="mt-2 flex items-center justify-between gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => onSelectSite(s.id)}
                  className={`rounded-lg px-2.5 py-1 text-[11px] font-semibold ${
                    isCurrent
                      ? 'bg-blue-700 text-white'
                      : 'border border-blue-200 bg-blue-50 text-blue-800 hover:bg-blue-100'
                  }`}
                >
                  {isCurrent ? strings.activeSiteLabel : `Switch → ${s.siteCode}`}
                </button>

                {isAdmin && s.status === 'ACTIVE' && sites.length > 1 && (
                  <button
                    type="button"
                    onClick={() => onArchiveSite(s.id)}
                    className="flex items-center gap-1 rounded-lg border border-slate-200 px-2 py-1 text-[11px] font-semibold text-slate-600 hover:bg-slate-50"
                  >
                    <Archive className="h-3 w-3" />
                    <span>{strings.archiveSiteBtn}</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* User-Site Access Control Matrix (Admin Only) */}
      {isAdmin && (
        <div className="rounded-2xl border border-slate-200 bg-white p-4">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
            <ShieldCheck className="h-4 w-4 text-blue-700" />
            <span>{strings.sitePermissionsTitle}</span>
          </div>
          <div className="mt-3 space-y-3">
            {userSiteAccounts
              .filter((acc) => acc.role !== 'ADMIN')
              .map((acc) => {
                const roleLabel =
                  language === 'bn'
                    ? USER_ROLE_LABELS[acc.role].bn
                    : USER_ROLE_LABELS[acc.role].en;
                return (
                  <div key={acc.userId} className="space-y-1.5">
                    <div className="text-[11px] font-semibold text-slate-700">
                      {roleLabel} ({acc.displayName})
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {sites.map((site) => {
                        const assigned = acc.assignedSiteIds.includes(site.id);
                        return (
                          <button
                            key={site.id}
                            type="button"
                            onClick={() => {
                              const nextIds = assigned
                                ? acc.assignedSiteIds.filter((id) => id !== site.id)
                                : [...acc.assignedSiteIds, site.id];
                              onUpdateRoleSiteAssignments(acc.role, nextIds);
                            }}
                            className={`flex items-center gap-1 rounded-lg border px-2 py-1 text-[11px] font-semibold transition-colors ${
                              assigned
                                ? 'border-blue-700 bg-blue-50 text-blue-800'
                                : 'border-slate-200 bg-slate-50 text-slate-500'
                            }`}
                          >
                            {assigned && <Check className="h-3 w-3" />}
                            <span>{site.siteCode}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* Add / Edit Site Modal */}
      {showSiteModal && (
        <SiteFormModal
          strings={strings}
          language={language}
          initialSite={editingSite}
          suggestedCode={`SITE-${sites.length + 1}`}
          onClose={() => {
            setShowSiteModal(false);
            setEditingSite(null);
          }}
          onSave={(saved) => {
            onSaveSite(saved);
            setShowSiteModal(false);
            setEditingSite(null);
          }}
        />
      )}
    </div>
  );
}

function SiteFormModal({
  strings,
  language,
  initialSite,
  suggestedCode,
  onClose,
  onSave,
}: {
  strings: BilingualUiStrings;
  language: AppLanguage;
  initialSite: Site | null;
  suggestedCode: string;
  onClose: () => void;
  onSave: (site: Site) => void;
}) {
  const [siteName, setSiteName] = useState(initialSite?.siteName ?? '');
  const [siteCode, setSiteCode] = useState(initialSite?.siteCode ?? suggestedCode);
  const [address, setAddress] = useState(initialSite?.address ?? '');
  const [clientName, setClientName] = useState(initialSite?.clientName ?? '');
  const [siteManager, setSiteManager] = useState(initialSite?.siteManager ?? '');
  const [status, setStatus] = useState<SiteStatus>(initialSite?.status ?? 'ACTIVE');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
      <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">
            {initialSite ? strings.editSiteBtn : strings.addSiteBtn}
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!siteName.trim() || !siteCode.trim()) return;
            onSave({
              id:
                initialSite?.id ??
                `SITE-${siteCode.trim().toUpperCase().replace(/[^A-Z0-9]/g, '')}`,
              siteName: siteName.trim(),
              siteCode: siteCode.trim().toUpperCase(),
              address: address.trim(),
              clientName: clientName.trim(),
              siteManager: siteManager.trim(),
              startDateIso: initialSite?.startDateIso ?? '2026-11-15',
              status,
              notes: initialSite?.notes ?? '',
            });
          }}
          className="mt-3 space-y-2.5"
        >
          <input
            type="text"
            required
            value={siteName}
            onChange={(e) => setSiteName(e.target.value)}
            placeholder={strings.siteNameLabel}
            className="h-10 w-full rounded-xl border border-slate-300 px-3 text-sm"
          />
          <input
            type="text"
            required
            value={siteCode}
            onChange={(e) => setSiteCode(e.target.value)}
            placeholder={strings.siteCodeLabel}
            className="h-10 w-full rounded-xl border border-slate-300 px-3 font-mono text-sm"
          />
          <input
            type="text"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder={strings.siteAddressLabel}
            className="h-9 w-full rounded-xl border border-slate-300 px-3 text-xs"
          />
          <input
            type="text"
            value={clientName}
            onChange={(e) => setClientName(e.target.value)}
            placeholder={strings.clientNameLabel}
            className="h-9 w-full rounded-xl border border-slate-300 px-3 text-xs"
          />
          <input
            type="text"
            value={siteManager}
            onChange={(e) => setSiteManager(e.target.value)}
            placeholder={strings.siteManagerLabel}
            className="h-9 w-full rounded-xl border border-slate-300 px-3 text-xs"
          />
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value as SiteStatus)}
            className="h-9 w-full rounded-xl border border-slate-300 bg-white px-2.5 text-xs font-semibold"
          >
            {(['ACTIVE', 'PAUSED', 'COMPLETED', 'ARCHIVED'] as SiteStatus[]).map((st) => (
              <option key={st} value={st}>
                {language === 'bn' ? SITE_STATUS_LABELS[st].bn : SITE_STATUS_LABELS[st].en}
              </option>
            ))}
          </select>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[38px] rounded-xl px-3.5 py-2 text-xs font-semibold text-slate-600"
            >
              {strings.cancel}
            </button>
            <button
              type="submit"
              className="min-h-[38px] rounded-xl bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white"
            >
              {strings.saveChanges}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
