import { useEffect, useRef, useState } from 'react';

interface VeltricSplashScreenViewProps {
  onComplete: () => void;
}

export function VeltricSplashScreenView({ onComplete }: VeltricSplashScreenViewProps) {
  const [phase, setPhase] = useState<'entering' | 'visible' | 'exiting'>('entering');
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  useEffect(() => {
    const enterFrame = requestAnimationFrame(() => {
      setPhase('visible');
    });

    const holdTimer = window.setTimeout(() => {
      setPhase('exiting');
    }, 1850);

    const doneTimer = window.setTimeout(() => {
      onCompleteRef.current();
    }, 2170);

    return () => {
      cancelAnimationFrame(enterFrame);
      window.clearTimeout(holdTimer);
      window.clearTimeout(doneTimer);
    };
  }, []);

  return (
    <div
      data-testid="veltric-splash-screen"
      className={`absolute inset-0 z-50 flex items-center justify-center transition-opacity duration-300 ease-out ${
        phase === 'exiting' ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      style={{
        background:
          'radial-gradient(circle at center, #071329 0%, #030814 58%, #010308 100%)',
      }}
    >
      <div className="relative flex items-center justify-center w-full h-full">
        {/* Subtle ambient glow layer strictly behind the untouched PNG */}
        <div
          aria-hidden="true"
          className={`pointer-events-none absolute aspect-square w-[74%] max-w-[300px] rounded-full transition-opacity duration-500 ${
            phase === 'entering' ? 'opacity-0' : 'opacity-100 animate-pulse'
          }`}
          style={{
            background:
              'radial-gradient(circle, rgba(0, 212, 255, 0.28) 0%, rgba(0, 102, 255, 0.14) 45%, rgba(0, 0, 0, 0) 72%)',
            filter: 'blur(18px)',
          }}
        />

        {/* Exact uploaded VELTRIC PNG logo: uncropped, untinted, aspect-locked */}
        <img
          src="/assets/aistudio/InShot_20261120_132804721_7eb17f11.png"
          alt="VELTRIC"
          draggable={false}
          className={`relative z-10 aspect-square w-[56%] max-w-[230px] object-contain select-none transition-all duration-500 ease-out ${
            phase === 'entering' ? 'opacity-0 scale-95' : 'opacity-100 scale-100'
          }`}
        />
      </div>
    </div>
  );
}
