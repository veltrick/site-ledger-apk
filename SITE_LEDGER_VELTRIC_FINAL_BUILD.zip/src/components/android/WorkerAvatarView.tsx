import { useState } from 'react';
import { User } from 'lucide-react';

interface WorkerAvatarViewProps {
  name: string;
  avatarUrl: string | null;
  sizeClass?: string;
  iconSizeClass?: string;
}

export function WorkerAvatarView({
  name,
  avatarUrl,
  sizeClass = 'h-11 w-11',
  iconSizeClass = 'h-5 w-5',
}: WorkerAvatarViewProps) {
  const [imageError, setImageError] = useState(false);

  const showPhoto = Boolean(avatarUrl) && !imageError;

  return (
    <div
      className={`relative flex shrink-0 items-center justify-center overflow-hidden rounded-full border border-slate-200 bg-blue-50 text-blue-900 ${sizeClass}`}
    >
      {showPhoto ? (
        <img
          src={avatarUrl ?? ''}
          alt={name}
          referrerPolicy="no-referrer"
          className="h-full w-full object-cover"
          onError={() => setImageError(true)}
        />
      ) : (
        <User className={iconSizeClass} aria-hidden="true" />
      )}
    </div>
  );
}
