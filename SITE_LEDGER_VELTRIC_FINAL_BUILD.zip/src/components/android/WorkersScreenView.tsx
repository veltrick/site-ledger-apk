import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Camera,
  Edit3,
  Info,
  Plus,
  RefreshCw,
  Search,
  Trash2,
  User,
  X,
} from 'lucide-react';
import { BilingualUiStrings, WORK_CATEGORY_LABELS } from '../../data/bilingualStrings';
import {
  AdvanceRecord,
  AppLanguage,
  AttendanceAuditEntry,
  DailyAttendanceRecord,
  DutyMultiplierConfig,
  DutyType,
  PaymentAllocation,
  PaymentAuditEntry,
  PaymentLedgerEntry,
  PayrollPeriodRecord,
  Site,
  UserRole,
  WorkCategory,
  Worker,
  WorkerSiteHistory,
} from '../../types/siteLedger';
import { processPickedWorkerPhoto } from '../../utils/imageResize';
import { isLocalWorkerCodeDuplicate } from '../../utils/wageCalculator';
import { WorkerAvatarView } from './WorkerAvatarView';
import { WorkerProfileView } from './WorkerProfileView';

type WorkerSortOption = 'NAME' | 'ID' | 'CATEGORY';

interface WorkersScreenViewProps {
  strings: BilingualUiStrings;
  language: AppLanguage;
  activeSite: Site;
  allSites: Site[];
  workers: Worker[];
  allWorkersAcrossSites: Worker[];
  workerTransfers: WorkerSiteHistory[];
  activeRole: UserRole;
  dutyConfig: DutyMultiplierConfig;
  attendanceRecords: DailyAttendanceRecord[];
  allAttendanceRecords: DailyAttendanceRecord[];
  attendanceAudits: AttendanceAuditEntry[];
  payments: PaymentLedgerEntry[];
  allPayments: PaymentLedgerEntry[];
  advances: AdvanceRecord[];
  allAdvances: AdvanceRecord[];
  allocations: PaymentAllocation[];
  allAllocations: PaymentAllocation[];
  paymentAudits: PaymentAuditEntry[];
  payrollPeriods: PayrollPeriodRecord[];
  initialProfileWorkerId?: string | null;
  onConsumeInitialProfileWorker?: () => void;
  onAddWorker: (input: {
    fullName: string;
    localWorkerCode: string;
    phoneNumber: string;
    category: WorkCategory;
    joiningDateIso: string;
    dailyWage: number;
    foodAllowance: number;
    isActive: boolean;
    avatarUrl: string | null;
    photoPath: string | null;
  }) => void;
  onEditWorker: (updated: Worker) => void;
  onTransferWorker: (input: {
    workerId: string;
    toSiteId: string;
    newLocalCode: string;
    transferDateIso: string;
    note: string;
  }) => void;
  onRecordAttendance: (input: {
    dateIso: string;
    worker: Worker;
    dutyType: DutyType;
    note: string;
    editReason?: string;
  }) => void;
  onRecordPayment: (input: {
    workerId: string;
    dateIso: string;
    applicablePeriod: string;
    paidAmount: number;
    referenceNo: string;
    note: string;
    submissionToken: string;
  }) => void;
  onRecordAdvance: (input: {
    workerId: string;
    advanceDateIso: string;
    amount: number;
    referenceNo: string;
    note: string;
    submissionToken: string;
  }) => void;
  onAllocateAdvance: (input: {
    advanceId: string;
    targetPeriod: string;
    amountToAllocate: number;
    note: string;
  }) => void;
  onVoidPayment: (transactionId: string, reason: string) => void;
}

export function WorkersScreenView({
  strings,
  language,
  activeSite,
  allSites,
  workers,
  allWorkersAcrossSites,
  workerTransfers,
  activeRole,
  dutyConfig,
  allAttendanceRecords,
  attendanceAudits,
  allPayments,
  allAdvances,
  allAllocations,
  paymentAudits,
  payrollPeriods,
  initialProfileWorkerId = null,
  onConsumeInitialProfileWorker,
  onAddWorker,
  onEditWorker,
  onTransferWorker,
  onRecordAttendance,
  onRecordPayment,
  onRecordAdvance,
  onAllocateAdvance,
  onVoidPayment,
}: WorkersScreenViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'INACTIVE'>('ALL');
  const [sortOption, setSortOption] = useState<WorkerSortOption>('NAME');
  const [showAddModal, setShowAddModal] = useState(false);
  const [profileWorkerId, setProfileWorkerId] = useState<string | null>(initialProfileWorkerId);
  const [editingWorker, setEditingWorker] = useState<Worker | null>(null);

  useEffect(() => {
    if (initialProfileWorkerId) {
      setProfileWorkerId(initialProfileWorkerId);
      onConsumeInitialProfileWorker?.();
    }
  }, [initialProfileWorkerId, onConsumeInitialProfileWorker]);

  const canManageWorkers = activeRole !== 'ACCOUNTANT';

  const filteredWorkers = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = workers.filter((w) => {
      const code = (w.localWorkerCode || w.id).toLowerCase();
      const matchesQuery =
        !q ||
        w.fullNameEn.toLowerCase().includes(q) ||
        w.fullNameBn.toLowerCase().includes(q) ||
        code.includes(q) ||
        w.id.toLowerCase().includes(q) ||
        w.phoneNumber.toLowerCase().includes(q);
      const matchesStatus =
        statusFilter === 'ALL'
          ? true
          : statusFilter === 'ACTIVE'
            ? w.isActive
            : !w.isActive;
      return matchesQuery && matchesStatus;
    });

    return [...list].sort((a, b) => {
      if (sortOption === 'ID') {
        return (a.localWorkerCode || a.id).localeCompare(b.localWorkerCode || b.id);
      }
      if (sortOption === 'CATEGORY') return a.category.localeCompare(b.category);
      const nameA = language === 'bn' ? a.fullNameBn : a.fullNameEn;
      const nameB = language === 'bn' ? b.fullNameBn : b.fullNameEn;
      return nameA.localeCompare(nameB);
    });
  }, [workers, searchQuery, statusFilter, sortOption, language]);

  const profileWorker = useMemo(
    () =>
      workers.find((w) => w.id === profileWorkerId) ??
      allWorkersAcrossSites.find((w) => w.id === profileWorkerId) ??
      null,
    [workers, allWorkersAcrossSites, profileWorkerId]
  );

  if (profileWorker) {
    return (
      <>
        <WorkerProfileView
          strings={strings}
          language={language}
          worker={profileWorker}
          allSites={allSites}
          allWorkersAcrossSites={allWorkersAcrossSites}
          workerTransfers={workerTransfers}
          activeRole={activeRole}
          dutyConfig={dutyConfig}
          allAttendance={allAttendanceRecords}
          attendanceAudits={attendanceAudits}
          allPayments={allPayments}
          advances={allAdvances}
          allocations={allAllocations}
          paymentAudits={paymentAudits}
          payrollPeriods={payrollPeriods}
          onBack={() => setProfileWorkerId(null)}
          onEditWorkerClick={() => {
            if (canManageWorkers) setEditingWorker(profileWorker);
          }}
          onTransferWorker={onTransferWorker}
          onRecordAttendance={onRecordAttendance}
          onRecordPayment={onRecordPayment}
          onRecordAdvance={onRecordAdvance}
          onAllocateAdvance={onAllocateAdvance}
          onVoidPayment={onVoidPayment}
        />

        {editingWorker && (
          <WorkerFormModal
            strings={strings}
            language={language}
            title={strings.editWorker}
            confirmLabel={strings.saveChanges}
            siteId={editingWorker.siteId}
            allWorkersAcrossSites={allWorkersAcrossSites}
            initialWorker={editingWorker}
            suggestedCode={editingWorker.localWorkerCode || editingWorker.id}
            onClose={() => setEditingWorker(null)}
            onSubmit={(payload) => {
              onEditWorker({
                ...editingWorker,
                localWorkerCode: payload.localWorkerCode,
                fullNameEn: payload.fullName,
                fullNameBn:
                  language === 'bn' ? payload.fullName : editingWorker.fullNameBn,
                phoneNumber: payload.phoneNumber,
                category: payload.category,
                joiningDateIso: payload.joiningDateIso,
                leavingDateIso: payload.leavingDateIso,
                dailyWage: payload.dailyWage,
                dailyFoodAllowance: payload.foodAllowance,
                isActive: payload.isActive,
                avatarUrl: payload.avatarUrl,
                photoPath: payload.photoPath,
              });
              setEditingWorker(null);
            }}
          />
        )}
      </>
    );
  }

  return (
    <div className="relative space-y-3.5 p-4">
      <div className="flex items-start gap-2.5 rounded-xl border border-blue-200 bg-blue-50/70 px-3 py-2 text-xs text-blue-950">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-blue-700" />
        <span>
          {activeSite.siteCode} · {activeSite.siteName} — {strings.navWorkers}
        </span>
      </div>

      <div className="flex items-center justify-between gap-2">
        <h2 className="text-base font-bold text-slate-900">
          {strings.navWorkers} ({filteredWorkers.length})
        </h2>
        {canManageWorkers && (
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="flex min-h-[40px] items-center gap-1.5 rounded-xl bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white transition-colors hover:bg-blue-800 whitespace-nowrap shrink-0"
          >
            <Plus className="h-4 w-4" />
            <span>{strings.addWorker}</span>
          </button>
        )}
      </div>

      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={strings.searchWorkersPlaceholder}
          className="h-11 w-full rounded-xl border border-slate-200 bg-white pl-9 pr-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none"
        />
      </div>

      <div className="flex items-center gap-1 rounded-xl bg-slate-200/70 p-1">
        {(['ALL', 'ACTIVE', 'INACTIVE'] as const).map((tab) => {
          const label =
            tab === 'ALL'
              ? strings.allFilter
              : tab === 'ACTIVE'
                ? strings.activeStatus
                : strings.inactiveStatus;
          const active = statusFilter === tab;
          return (
            <button
              key={tab}
              type="button"
              onClick={() => setStatusFilter(tab)}
              className={`flex-1 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                active
                  ? 'bg-white text-blue-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {label}
            </button>
          );
        })}
      </div>

      <div className="flex items-center justify-between gap-2 text-xs">
        <span className="font-semibold text-slate-500">{strings.sortLabel}:</span>
        <div className="flex items-center gap-1">
          {([
            { id: 'NAME', label: strings.sortByName },
            { id: 'ID', label: strings.sortById },
            { id: 'CATEGORY', label: strings.sortByCategory },
          ] as const).map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => setSortOption(opt.id)}
              className={`rounded-lg border px-2.5 py-1 text-[11px] font-semibold transition-colors ${
                sortOption === opt.id
                  ? 'border-blue-700 bg-blue-50 text-blue-800'
                  : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {filteredWorkers.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center text-sm text-slate-500">
          {strings.noWorkersFound}
        </div>
      ) : (
        <div className="space-y-2.5">
          {filteredWorkers.map((worker) => {
            const displayName = language === 'bn' ? worker.fullNameBn : worker.fullNameEn;
            const categoryText =
              language === 'bn'
                ? WORK_CATEGORY_LABELS[worker.category].bn
                : WORK_CATEGORY_LABELS[worker.category].en;

            return (
              <div
                key={worker.id}
                className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white p-3.5 transition-colors hover:border-blue-300"
              >
                <button
                  type="button"
                  onClick={() => setProfileWorkerId(worker.id)}
                  className="flex min-w-0 flex-1 items-center gap-3 text-left"
                >
                  <WorkerAvatarView
                    name={displayName}
                    avatarUrl={worker.avatarUrl}
                    sizeClass="h-12 w-12"
                    iconSizeClass="h-5 w-5"
                  />

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate text-sm font-semibold text-slate-900">
                        {displayName}
                      </span>
                      <span
                        className={`text-xs font-semibold whitespace-nowrap shrink-0 ${
                          worker.isActive ? 'text-emerald-700' : 'text-rose-700'
                        }`}
                      >
                        {worker.isActive ? strings.activeStatus : strings.inactiveStatus}
                      </span>
                    </div>

                    <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-slate-500">
                      <span className="font-mono font-medium text-slate-700">
                        {worker.localWorkerCode || worker.id}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{categoryText}</span>
                      {worker.phoneNumber && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span>{worker.phoneNumber}</span>
                        </>
                      )}
                    </div>

                    <div className="mt-1 text-xs font-medium text-slate-800 tabular-nums">
                      {strings.dailyWageLabel}: ৳{worker.dailyWage}
                      {strings.perDaySuffix}
                    </div>
                  </div>
                </button>

                {canManageWorkers && (
                  <button
                    type="button"
                    onClick={() => setEditingWorker(worker)}
                    aria-label={`${strings.editWorker} ${displayName}`}
                    className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 hover:text-blue-700"
                  >
                    <Edit3 className="h-4 w-4" />
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}

      {showAddModal && (
        <WorkerFormModal
          strings={strings}
          language={language}
          title={strings.addWorker}
          confirmLabel={strings.saveWorker}
          siteId={activeSite.id}
          allWorkersAcrossSites={allWorkersAcrossSites}
          initialWorker={null}
          suggestedCode={`SL-${111 + workers.length}`}
          onClose={() => setShowAddModal(false)}
          onSubmit={(payload) => {
            onAddWorker(payload);
            setShowAddModal(false);
          }}
        />
      )}

      {editingWorker && (
        <WorkerFormModal
          strings={strings}
          language={language}
          title={strings.editWorker}
          confirmLabel={strings.saveChanges}
          siteId={editingWorker.siteId}
          allWorkersAcrossSites={allWorkersAcrossSites}
          initialWorker={editingWorker}
          suggestedCode={editingWorker.localWorkerCode || editingWorker.id}
          onClose={() => setEditingWorker(null)}
          onSubmit={(payload) => {
            onEditWorker({
              ...editingWorker,
              localWorkerCode: payload.localWorkerCode,
              fullNameEn: payload.fullName,
              fullNameBn:
                language === 'bn' ? payload.fullName : editingWorker.fullNameBn,
              phoneNumber: payload.phoneNumber,
              category: payload.category,
              joiningDateIso: payload.joiningDateIso,
              leavingDateIso: payload.leavingDateIso,
              dailyWage: payload.dailyWage,
              dailyFoodAllowance: payload.foodAllowance,
              isActive: payload.isActive,
              avatarUrl: payload.avatarUrl,
              photoPath: payload.photoPath,
            });
            setEditingWorker(null);
          }}
        />
      )}
    </div>
  );
}

interface WorkerFormModalProps {
  strings: BilingualUiStrings;
  language: AppLanguage;
  title: string;
  confirmLabel: string;
  siteId: string;
  allWorkersAcrossSites: Worker[];
  initialWorker: Worker | null;
  suggestedCode: string;
  onClose: () => void;
  onSubmit: (payload: {
    fullName: string;
    localWorkerCode: string;
    phoneNumber: string;
    category: WorkCategory;
    joiningDateIso: string;
    leavingDateIso: string | null;
    dailyWage: number;
    foodAllowance: number;
    isActive: boolean;
    avatarUrl: string | null;
    photoPath: string | null;
  }) => void;
}

function WorkerFormModal({
  strings,
  language,
  title,
  confirmLabel,
  siteId,
  allWorkersAcrossSites,
  initialWorker,
  suggestedCode,
  onClose,
  onSubmit,
}: WorkerFormModalProps) {
  const isEdit = initialWorker !== null;
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [name, setName] = useState(
    initialWorker
      ? language === 'bn'
        ? initialWorker.fullNameBn
        : initialWorker.fullNameEn
      : ''
  );
  const [localCode, setLocalCode] = useState(
    initialWorker?.localWorkerCode ?? initialWorker?.id ?? suggestedCode
  );
  const [phoneNumber, setPhoneNumber] = useState(initialWorker?.phoneNumber ?? '');
  const [category, setCategory] = useState<WorkCategory>(initialWorker?.category ?? 'MASON');
  const [joiningDateIso, setJoiningDateIso] = useState(
    initialWorker?.joiningDateIso ?? '2026-11-15'
  );
  const [leavingDateIso, setLeavingDateIso] = useState(
    initialWorker?.leavingDateIso ?? ''
  );
  const [dailyWage, setDailyWage] = useState(String(initialWorker?.dailyWage ?? 750));
  const [foodAllowance, setFoodAllowance] = useState(
    String(initialWorker?.dailyFoodAllowance ?? 150)
  );
  const [isActive, setIsActive] = useState(initialWorker?.isActive ?? true);

  const [previewAvatarUrl, setPreviewAvatarUrl] = useState<string | null>(
    initialWorker?.avatarUrl ?? null
  );
  const [previewPhotoPath, setPreviewPhotoPath] = useState<string | null>(
    initialWorker?.photoPath ?? null
  );
  const [hasNewSelection, setHasNewSelection] = useState(false);

  const duplicateError = isLocalWorkerCodeDuplicate(
    siteId,
    localCode,
    initialWorker?.id ?? null,
    allWorkersAcrossSites
  );

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const result = await processPickedWorkerPhoto(
      file,
      initialWorker?.id ?? localCode
    );
    setPreviewAvatarUrl(result.dataUrl);
    setPreviewPhotoPath(result.relativePath);
    setHasNewSelection(true);
    e.target.value = '';
  };

  const handleRemovePhoto = () => {
    setPreviewAvatarUrl(null);
    setPreviewPhotoPath(null);
    setHasNewSelection(false);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !localCode.trim() || duplicateError) return;
    onSubmit({
      fullName: name.trim(),
      localWorkerCode: localCode.trim().toUpperCase(),
      phoneNumber: phoneNumber.trim(),
      category,
      joiningDateIso: joiningDateIso.trim() || '2026-11-15',
      leavingDateIso: isEdit && leavingDateIso.trim() ? leavingDateIso.trim() : null,
      dailyWage: Number(dailyWage) || 650,
      foodAllowance: Number(foodAllowance) || 150,
      isActive,
      avatarUrl: previewAvatarUrl,
      photoPath: previewPhotoPath,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4">
      <div className="max-h-[90vh] w-full max-w-sm overflow-y-auto rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-slate-900">{title}</h3>
          <button
            type="button"
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100"
            aria-label={strings.cancel}
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <form onSubmit={handleSave} className="mt-4 space-y-3">
          <div className="flex flex-col items-center rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />

            <div className="flex h-22 w-22 items-center justify-center overflow-hidden rounded-full border-2 border-white bg-blue-50 text-blue-900 shadow-xs">
              {previewAvatarUrl ? (
                <img
                  src={previewAvatarUrl}
                  alt={name || strings.workerProfile}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover"
                />
              ) : (
                <User className="h-9 w-9" aria-hidden="true" />
              )}
            </div>

            {hasNewSelection && (
              <p className="mt-2 text-center text-[11px] font-medium text-blue-700">
                {strings.photoPreviewNotice}
              </p>
            )}

            {!previewAvatarUrl ? (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="mt-3 flex min-h-[38px] items-center gap-1.5 rounded-xl border border-blue-200 bg-white px-3.5 py-2 text-xs font-semibold text-blue-700 transition-colors hover:bg-blue-50"
              >
                <Camera className="h-4 w-4" />
                <span>{strings.addPhoto}</span>
              </button>
            ) : (
              <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex min-h-[38px] items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-800 transition-colors hover:bg-slate-100"
                >
                  <RefreshCw className="h-3.5 w-3.5 text-blue-700" />
                  <span>{strings.replacePhoto}</span>
                </button>
                <button
                  type="button"
                  onClick={handleRemovePhoto}
                  className="flex min-h-[38px] items-center gap-1.5 rounded-xl border border-rose-200 bg-white px-3 py-2 text-xs font-semibold text-rose-700 transition-colors hover:bg-rose-50"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  <span>{strings.removePhoto}</span>
                </button>
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600">
              {strings.fullNameLabel}
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="mt-1 h-10 w-full rounded-xl border border-slate-300 px-3 text-sm focus:border-blue-600 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-medium text-slate-600">
                {strings.workerIdLabel}
              </label>
              <input
                type="text"
                required
                value={localCode}
                onChange={(e) => setLocalCode(e.target.value)}
                className={`mt-1 h-10 w-full rounded-xl border px-3 font-mono text-sm focus:outline-none ${
                  duplicateError
                    ? 'border-rose-500 focus:border-rose-600'
                    : 'border-slate-300 focus:border-blue-600'
                }`}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600">
                {strings.categoryLabel}
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as WorkCategory)}
                className="mt-1 h-10 w-full rounded-xl border border-slate-300 bg-white px-2.5 text-sm focus:border-blue-600 focus:outline-none"
              >
                {(Object.keys(WORK_CATEGORY_LABELS) as WorkCategory[]).map((cat) => (
                  <option key={cat} value={cat}>
                    {language === 'bn'
                      ? WORK_CATEGORY_LABELS[cat].bn
                      : WORK_CATEGORY_LABELS[cat].en}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {duplicateError && (
            <div className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-medium text-rose-800">
              {strings.duplicateLocalCodeError}
            </div>
          )}

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-medium text-slate-600">
                {strings.phoneNumberLabel}
              </label>
              <input
                type="text"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="017XX-XXXXXX"
                className="mt-1 h-10 w-full rounded-xl border border-slate-300 px-3 text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600">
                {strings.joiningDateLabel}
              </label>
              <input
                type="date"
                value={joiningDateIso}
                onChange={(e) => setJoiningDateIso(e.target.value)}
                className="mt-1 h-10 w-full rounded-xl border border-slate-300 px-2.5 text-xs focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          {isEdit && (
            <div>
              <label className="block text-xs font-medium text-slate-600">
                {strings.leavingDateLabel}
              </label>
              <input
                type="date"
                value={leavingDateIso}
                onChange={(e) => setLeavingDateIso(e.target.value)}
                className="mt-1 h-10 w-full rounded-xl border border-slate-300 px-3 text-sm focus:border-blue-600 focus:outline-none"
              />
            </div>
          )}

          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-medium text-slate-600">
                {strings.dailyWageLabel}
              </label>
              <input
                type="number"
                min={100}
                required
                value={dailyWage}
                onChange={(e) => setDailyWage(e.target.value)}
                className="mt-1 h-10 w-full rounded-xl border border-slate-300 px-3 text-sm tabular-nums focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600">
                {strings.foodAllowanceLabel}
              </label>
              <input
                type="number"
                min={0}
                required
                value={foodAllowance}
                onChange={(e) => setFoodAllowance(e.target.value)}
                className="mt-1 h-10 w-full rounded-xl border border-slate-300 px-3 text-sm tabular-nums focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          {isEdit && (
            <div className="flex items-center justify-between rounded-xl border border-slate-200 px-3 py-2.5">
              <span className="text-xs font-medium text-slate-700">{strings.statusLabel}</span>
              <button
                type="button"
                onClick={() => setIsActive((prev) => !prev)}
                className={`rounded-lg px-3 py-1 text-xs font-semibold ${
                  isActive
                    ? 'bg-emerald-50 text-emerald-700'
                    : 'bg-rose-50 text-rose-700'
                }`}
              >
                {isActive ? strings.activeStatus : strings.inactiveStatus}
              </button>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[40px] rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100"
            >
              {strings.cancel}
            </button>
            <button
              type="submit"
              disabled={duplicateError}
              className="min-h-[40px] rounded-xl bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800 disabled:opacity-50"
            >
              {confirmLabel}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
