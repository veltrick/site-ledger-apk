import { useState } from 'react';
import { Check, Copy, FileCode2, Folder } from 'lucide-react';
import { ANDROID_PROJECT_FILES, AndroidSourceFile } from '../../data/androidProjectFiles';

interface CodeExplorerViewProps {
  initialSelectedPath?: string;
}

export function CodeExplorerView({ initialSelectedPath }: CodeExplorerViewProps) {
  const defaultFile =
    ANDROID_PROJECT_FILES.find((f) => f.path === initialSelectedPath) ??
    ANDROID_PROJECT_FILES.find((f) => f.shortName === 'SiteLedgerApp.kt') ??
    ANDROID_PROJECT_FILES[0];

  const [selectedFile, setSelectedFile] = useState<AndroidSourceFile | undefined>(defaultFile);
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    if (!selectedFile) return;
    await navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="grid min-h-[680px] grid-cols-1 overflow-hidden rounded-2xl border border-slate-200 bg-white lg:grid-cols-[300px_1fr]">
      <aside className="thin-scroll max-h-[680px] overflow-y-auto border-b border-slate-200 bg-slate-50/70 p-3 lg:border-b-0 lg:border-r">
        <div className="mb-2.5 flex items-center gap-2 px-2 text-xs font-semibold text-slate-600">
          <Folder className="h-4 w-4 text-blue-700" />
          <span>android-project/ ({ANDROID_PROJECT_FILES.length} files)</span>
        </div>

        <div className="space-y-1">
          {ANDROID_PROJECT_FILES.map((file) => {
            const active = selectedFile?.path === file.path;
            return (
              <button
                key={file.path}
                type="button"
                onClick={() => setSelectedFile(file)}
                className={`flex w-full flex-col rounded-xl px-2.5 py-2 text-left transition-colors ${
                  active
                    ? 'bg-blue-700 text-white'
                    : 'text-slate-700 hover:bg-slate-200/70'
                }`}
              >
                <span className="flex items-center gap-1.5 truncate text-xs font-semibold">
                  <FileCode2 className="h-3.5 w-3.5 shrink-0" />
                  <span className="truncate">{file.shortName}</span>
                </span>
                <span
                  className={`mt-0.5 truncate pl-5 text-[11px] ${
                    active ? 'text-blue-100' : 'text-slate-500'
                  }`}
                >
                  {file.folder}
                </span>
              </button>
            );
          })}
        </div>
      </aside>

      <div className="flex min-w-0 flex-col bg-slate-950 text-slate-100">
        <div className="flex items-center justify-between gap-3 border-b border-slate-800 px-4 py-3">
          <div className="min-w-0 truncate font-mono text-xs text-slate-300">
            {selectedFile?.path}
          </div>
          <button
            type="button"
            onClick={handleCopy}
            className="flex min-h-[34px] shrink-0 items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-200 transition-colors hover:bg-slate-800"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
            <span>{copied ? 'Copied' : 'Copy File'}</span>
          </button>
        </div>

        <pre className="thin-scroll flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed text-slate-200">
          <code>{selectedFile?.content ?? ''}</code>
        </pre>
      </div>
    </div>
  );
}
