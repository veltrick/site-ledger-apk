import { NavDestination } from '../types/siteLedger';

const rawModules = import.meta.glob(
  ['/android-project/**/*', '!/android-project/**/*.png'],
  {
    query: '?raw',
    import: 'default',
    eager: true,
  }
) as Record<string, string>;

export const VELTRIC_LOGO_ANDROID_ASSET = {
  androidPath: 'app/src/main/res/drawable/veltric_logo.png',
  localAssetUrl: '/assets/aistudio/InShot_20261120_132804721_7eb17f11.png',
};

export interface AndroidSourceFile {
  path: string;
  shortName: string;
  folder: string;
  content: string;
}

export const ANDROID_PROJECT_FILES: AndroidSourceFile[] = Object.entries(rawModules)
  .map(([fullPath, content]) => {
    const cleanPath = fullPath.replace(/^\/android-project\//, '');
    const parts = cleanPath.split('/');
    const shortName = parts[parts.length - 1];
    const folder = parts.length > 1 ? parts.slice(0, -1).join('/') : '(root)';
    return {
      path: cleanPath,
      shortName,
      folder,
      content,
    };
  })
  .sort((a, b) => a.path.localeCompare(b.path));

export const SCREEN_TO_KOTLIN_FILE: Record<NavDestination, string> = {
  dashboard: 'app/src/main/java/com/siteledger/app/ui/screens/DashboardScreen.kt',
  workers: 'app/src/main/java/com/siteledger/app/ui/screens/WorkersScreen.kt',
  attendance: 'app/src/main/java/com/siteledger/app/ui/screens/AttendanceScreen.kt',
  spreadsheet: 'app/src/main/java/com/siteledger/app/ui/screens/PayrollSpreadsheetScreen.kt',
  payments: 'app/src/main/java/com/siteledger/app/ui/screens/PaymentsScreen.kt',
  expenses: 'app/src/main/java/com/siteledger/app/ui/screens/ExpensesScreen.kt',
  reports: 'app/src/main/java/com/siteledger/app/ui/screens/ReportsScreen.kt',
  sites: 'app/src/main/java/com/siteledger/app/ui/screens/SitesManagementScreen.kt',
  settings: 'app/src/main/java/com/siteledger/app/ui/screens/SettingsScreen.kt',
  about: 'app/src/main/java/com/siteledger/app/ui/screens/AboutScreen.kt',
};
