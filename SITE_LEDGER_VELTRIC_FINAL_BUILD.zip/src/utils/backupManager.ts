import {
  AdvanceRecord,
  AppLanguage,
  AttendanceAuditEntry,
  BackupHistoryRecord,
  BackupManifest,
  BackupRecordCounts,
  BackupValidationResult,
  DailyAttendanceRecord,
  DEFAULT_SITE_ID,
  DutyMultiplierConfig,
  ExpenseAuditEntry,
  ExpenseCategory,
  PaymentAllocation,
  PaymentAuditEntry,
  PaymentLedgerEntry,
  PayrollAuditEntry,
  PayrollPeriodRecord,
  Site,
  SiteExpense,
  SyncEvent,
  UserRole,
  UserSiteAccount,
  Worker,
  WorkerSiteHistory,
} from '../types/siteLedger';
import { buildZipBytes, readZipEntries } from './zipBuilder';

export const BACKUP_SCHEMA_VERSION = 6;
export const BACKUP_APP_ID = 'com.siteledger.app';
export const BACKUP_APP_VERSION = '3.0.0-v6';

export interface SiteLedgerPersistState {
  schemaVersion: number;
  language: AppLanguage;
  activeRole: UserRole;
  selectedSiteId: string;
  selectedDateIso: string;
  sites: Site[];
  workers: Worker[];
  workerTransfers: WorkerSiteHistory[];
  attendance: DailyAttendanceRecord[];
  attendanceAudits: AttendanceAuditEntry[];
  payments: PaymentLedgerEntry[];
  advances: AdvanceRecord[];
  allocations: PaymentAllocation[];
  paymentAudits: PaymentAuditEntry[];
  payrollPeriods: PayrollPeriodRecord[];
  payrollAudits: PayrollAuditEntry[];
  dutyMultipliersBySite: Record<string, DutyMultiplierConfig>;
  expenseCategories: ExpenseCategory[];
  expenses: SiteExpense[];
  expenseAudits: ExpenseAuditEntry[];
  userSiteAccounts: UserSiteAccount[];
  backupHistory: BackupHistoryRecord[];
  syncEvents: SyncEvent[];
}

// Pure TypeScript SHA-256 implementation (works synchronously in both browser and Node tests)
const K = new Uint32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]);

export function sha256Hex(data: Uint8Array): string {
  const bitLen = data.length * 8;
  const padLen = ((data.length + 8) % 64 === 0 ? 64 : 64 - ((data.length + 8) % 64)) + 8;
  const padded = new Uint8Array(data.length + padLen);
  padded.set(data);
  padded[data.length] = 0x80;

  const dv = new DataView(padded.buffer);
  const hi = Math.floor(bitLen / 0x100000000);
  const lo = bitLen >>> 0;
  dv.setUint32(padded.length - 8, hi, false);
  dv.setUint32(padded.length - 4, lo, false);

  let h0 = 0x6a09e667;
  let h1 = 0xbb67ae85;
  let h2 = 0x3c6ef372;
  let h3 = 0xa54ff53a;
  let h4 = 0x510e527f;
  let h5 = 0x9b05688c;
  let h6 = 0x1f83d9ab;
  let h7 = 0x5be0cd19;

  const w = new Uint32Array(64);
  for (let offset = 0; offset < padded.length; offset += 64) {
    for (let i = 0; i < 16; i++) {
      w[i] = dv.getUint32(offset + i * 4, false);
    }
    for (let i = 16; i < 64; i++) {
      const s0 = ((w[i - 15] >>> 7) | (w[i - 15] << 25)) ^ ((w[i - 15] >>> 18) | (w[i - 15] << 14)) ^ (w[i - 15] >>> 3);
      const s1 = ((w[i - 2] >>> 17) | (w[i - 2] << 15)) ^ ((w[i - 2] >>> 19) | (w[i - 2] << 13)) ^ (w[i - 2] >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
    }

    let a = h0;
    let b = h1;
    let c = h2;
    let d = h3;
    let e = h4;
    let f = h5;
    let g = h6;
    let h = h7;

    for (let i = 0; i < 64; i++) {
      const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
      const ch = (e & f) ^ (~e & g);
      const temp1 = (h + S1 + ch + K[i] + w[i]) >>> 0;
      const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const temp2 = (S0 + maj) >>> 0;

      h = g;
      g = f;
      f = e;
      e = (d + temp1) >>> 0;
      d = c;
      c = b;
      b = a;
      a = (temp1 + temp2) >>> 0;
    }

    h0 = (h0 + a) >>> 0;
    h1 = (h1 + b) >>> 0;
    h2 = (h2 + c) >>> 0;
    h3 = (h3 + d) >>> 0;
    h4 = (h4 + e) >>> 0;
    h5 = (h5 + f) >>> 0;
    h6 = (h6 + g) >>> 0;
    h7 = (h7 + h) >>> 0;
  }

  return [h0, h1, h2, h3, h4, h5, h6, h7]
    .map((v) => v.toString(16).padStart(8, '0'))
    .join('');
}

export function suggestedBackupFileName(now = new Date()): string {
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  const hh = String(now.getHours()).padStart(2, '0');
  const min = String(now.getMinutes()).padStart(2, '0');
  return `SITE_LEDGER_BACKUP_${yyyy}_${mm}_${dd}_${hh}_${min}.zip`;
}

function dataUrlToBytes(dataUrl: string): Uint8Array {
  const base64Idx = dataUrl.indexOf('base64,');
  if (base64Idx >= 0) {
    const b64 = dataUrl.slice(base64Idx + 7);
    const binary = typeof atob === 'function' ? atob(b64) : Buffer.from(b64, 'base64').toString('binary');
    const out = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      out[i] = binary.charCodeAt(i);
    }
    return out;
  }
  return new TextEncoder().encode(dataUrl);
}

export function buildRecordCounts(state: SiteLedgerPersistState): BackupRecordCounts {
  return {
    sites: state.sites.length,
    workers: state.workers.length,
    attendanceRecords: state.attendance.length,
    payments: state.payments.length,
    advances: state.advances.length,
    allocations: state.allocations.length,
    expenses: state.expenses.length,
    workerPhotos: state.workers.filter((w) => w.photoPath && (w.avatarUrl || '').length > 0).length,
    receiptImages: state.expenses.filter((e) => e.receiptPath && (e.receiptDataUrl || '').length > 0).length,
  };
}

export function createBackupPackage(
  state: SiteLedgerPersistState,
  createdAt = new Date()
): {
  fileName: string;
  zipBytes: Uint8Array;
  manifest: BackupManifest;
  historyRecord: BackupHistoryRecord;
} {
  const encoder = new TextEncoder();
  const createdAtIso = createdAt.toISOString().slice(0, 19);
  const fileName = suggestedBackupFileName(createdAt);
  const backupId = `BKP-${Date.now()}`;

  // Strip volatile history recursion inside database snapshot while preserving all business records
  const sanitizedSnapshot: SiteLedgerPersistState = {
    ...state,
    schemaVersion: BACKUP_SCHEMA_VERSION,
  };

  const dbEntryPath = 'database/site_ledger_snapshot.json';
  const dbJson = JSON.stringify(sanitizedSnapshot, null, 2);
  const dbBytes = encoder.encode(dbJson);
  const dbSha = sha256Hex(dbBytes);

  const zipFiles: Array<{ path: string; content: string | Uint8Array }> = [
    { path: dbEntryPath, content: dbBytes },
  ];

  const workerPhotoChecksums: Record<string, string> = {};
  for (const w of state.workers) {
    if (w.photoPath && w.avatarUrl) {
      const normalized = w.photoPath.startsWith('worker_photos/')
        ? w.photoPath
        : `worker_photos/${w.photoPath}`;
      const imgBytes = dataUrlToBytes(w.avatarUrl);
      workerPhotoChecksums[normalized] = sha256Hex(imgBytes);
      zipFiles.push({ path: normalized, content: imgBytes });
    }
  }

  const receiptImageChecksums: Record<string, string> = {};
  for (const e of state.expenses) {
    if (e.receiptPath && e.receiptDataUrl) {
      const normalized = e.receiptPath.startsWith('receipt_images/')
        ? e.receiptPath
        : `receipt_images/${e.receiptPath}`;
      const imgBytes = dataUrlToBytes(e.receiptDataUrl);
      receiptImageChecksums[normalized] = sha256Hex(imgBytes);
      zipFiles.push({ path: normalized, content: imgBytes });
    }
  }

  const counts = buildRecordCounts(state);
  const schemaSummary = {
    appId: BACKUP_APP_ID,
    schemaVersion: BACKUP_SCHEMA_VERSION,
    tables: [
      'sites',
      'workers',
      'worker_site_history',
      'attendance',
      'attendance_audits',
      'payments',
      'advances',
      'payment_allocations',
      'payment_audits',
      'payroll_periods',
      'payroll_audits',
      'duty_settings',
      'expense_categories',
      'expenses',
      'expense_audits',
      'user_site_assignments',
      'backup_history',
      'sync_events',
    ],
    counts,
    createdAtIso,
  };
  zipFiles.push({
    path: 'metadata/schema_summary.json',
    content: JSON.stringify(schemaSummary, null, 2),
  });

  const manifest: BackupManifest = {
    backupId,
    appId: BACKUP_APP_ID,
    appVersion: BACKUP_APP_VERSION,
    schemaVersion: BACKUP_SCHEMA_VERSION,
    createdAtIso,
    databaseEntry: dbEntryPath,
    databaseSha256: dbSha,
    checksumSha256: dbSha,
    workerPhotoChecksums,
    receiptImageChecksums,
    counts,
  };
  zipFiles.push({
    path: 'backup_manifest.json',
    content: JSON.stringify(manifest, null, 2),
  });

  const zipBytes = buildZipBytes(zipFiles);
  const archiveSha = sha256Hex(zipBytes);
  manifest.checksumSha256 = archiveSha;

  const historyRecord: BackupHistoryRecord = {
    id: backupId,
    fileName,
    createdAtIso,
    schemaVersion: BACKUP_SCHEMA_VERSION,
    appVersion: BACKUP_APP_VERSION,
    checksumSha256: archiveSha,
    fileSizeBytes: zipBytes.length,
    counts,
    verifiedStatus: 'VERIFIED',
    fileExists: true,
  };

  return { fileName, zipBytes, manifest, historyRecord };
}

export function inspectAndVerifyBackupZip(
  zipBytes: Uint8Array,
  fileName: string,
  currentState?: SiteLedgerPersistState
): {
  validation: BackupValidationResult;
  stagedState: SiteLedgerPersistState | null;
  manifest: BackupManifest | null;
} {
  const errors: string[] = [];
  const warnings: string[] = [];
  const decoder = new TextDecoder();

  let entries;
  try {
    entries = readZipEntries(zipBytes);
  } catch (err) {
    return {
      validation: {
        isValid: false,
        fileName,
        createdAtIso: '',
        schemaVersion: 0,
        appVersion: '',
        checksumSha256: '',
        fileSizeBytes: zipBytes.length,
        counts: {
          sites: 0,
          workers: 0,
          attendanceRecords: 0,
          payments: 0,
          advances: 0,
          allocations: 0,
          expenses: 0,
          workerPhotos: 0,
          receiptImages: 0,
        },
        checksumsMatched: false,
        integrityCheckPassed: false,
        isOlderThanCurrentData: false,
        errors: [err instanceof Error ? err.message : 'Invalid ZIP archive'],
        warnings: [],
      },
      stagedState: null,
      manifest: null,
    };
  }

  for (const e of entries) {
    if (!e.crcValid) {
      errors.push(`CRC32 mismatch on ${e.path}`);
    }
  }

  const byPath = new Map(entries.map((e) => [e.path, e]));
  const manifestEntry = byPath.get('backup_manifest.json');
  if (!manifestEntry) {
    errors.push('Missing backup_manifest.json');
  }

  let manifest: BackupManifest | null = null;
  if (manifestEntry) {
    try {
      manifest = JSON.parse(decoder.decode(manifestEntry.bytes)) as BackupManifest;
      if (manifest.appId !== BACKUP_APP_ID) {
        errors.push(`Unexpected appId in manifest: ${manifest.appId}`);
      }
      if (!manifest.schemaVersion || manifest.schemaVersion < 1) {
        errors.push('Invalid schemaVersion in manifest');
      }
    } catch {
      errors.push('Malformed backup_manifest.json');
    }
  }

  const dbPath = manifest?.databaseEntry || 'database/site_ledger_snapshot.json';
  const dbEntry = byPath.get(dbPath);
  if (!dbEntry) {
    errors.push(`Missing database payload: ${dbPath}`);
  }

  let checksumsMatched = true;
  if (manifest && dbEntry) {
    const actualDbSha = sha256Hex(dbEntry.bytes);
    if (actualDbSha !== manifest.databaseSha256) {
      checksumsMatched = false;
      errors.push('Database SHA-256 checksum mismatch (tampered or corrupted)');
    }
  }

  if (manifest) {
    for (const [photoPath, expectedSha] of Object.entries(manifest.workerPhotoChecksums || {})) {
      const photoEntry = byPath.get(photoPath);
      if (!photoEntry) {
        checksumsMatched = false;
        errors.push(`Missing referenced worker photo: ${photoPath}`);
      } else if (sha256Hex(photoEntry.bytes) !== expectedSha) {
        checksumsMatched = false;
        errors.push(`SHA-256 mismatch on worker photo: ${photoPath}`);
      }
    }
    for (const [receiptPath, expectedSha] of Object.entries(manifest.receiptImageChecksums || {})) {
      const rEntry = byPath.get(receiptPath);
      if (!rEntry) {
        checksumsMatched = false;
        errors.push(`Missing referenced receipt photo: ${receiptPath}`);
      } else if (sha256Hex(rEntry.bytes) !== expectedSha) {
        checksumsMatched = false;
        errors.push(`SHA-256 mismatch on receipt photo: ${receiptPath}`);
      }
    }
  }

  let stagedState: SiteLedgerPersistState | null = null;
  if (dbEntry) {
    try {
      const parsed = JSON.parse(decoder.decode(dbEntry.bytes)) as SiteLedgerPersistState;
      if (!Array.isArray(parsed.sites) || !Array.isArray(parsed.workers)) {
        errors.push('Database integrity check failed: required tables missing');
      } else {
        stagedState = normalizeRestoredState(parsed);
      }
    } catch {
      errors.push('Database JSON corrupted');
    }
  }

  const integrityCheckPassed = errors.length === 0 && stagedState !== null;
  let isOlderThanCurrentData = false;
  if (currentState && manifest && stagedState) {
    const latestLiveTimestamp = findLatestMutationIso(currentState);
    if (latestLiveTimestamp && manifest.createdAtIso < latestLiveTimestamp) {
      isOlderThanCurrentData = true;
      warnings.push('Backup timestamp is older than latest local activity');
    }
  }

  const counts = manifest?.counts ??
    (stagedState ? buildRecordCounts(stagedState) : {
      sites: 0,
      workers: 0,
      attendanceRecords: 0,
      payments: 0,
      advances: 0,
      allocations: 0,
      expenses: 0,
      workerPhotos: 0,
      receiptImages: 0,
    });

  return {
    validation: {
      isValid: errors.length === 0 && checksumsMatched && integrityCheckPassed,
      fileName,
      createdAtIso: manifest?.createdAtIso ?? '',
      schemaVersion: manifest?.schemaVersion ?? 0,
      appVersion: manifest?.appVersion ?? '',
      checksumSha256: sha256Hex(zipBytes),
      fileSizeBytes: zipBytes.length,
      counts,
      checksumsMatched,
      integrityCheckPassed,
      isOlderThanCurrentData,
      errors,
      warnings,
    },
    stagedState: integrityCheckPassed ? stagedState : null,
    manifest,
  };
}

/**
 * Safely migrates pre-v6 backups (single-site schema) onto DEFAULT_SITE_ID = 'SITE-MAIN'
 * without losing any historical workers, photos, attendance, payments, advances, or locks.
 */
export function normalizeRestoredState(raw: Partial<SiteLedgerPersistState>): SiteLedgerPersistState {
  const defaultSite: Site = {
    id: DEFAULT_SITE_ID,
    siteName: 'Gulshan Tower Foundation',
    siteCode: 'GLS-01',
    address: 'Plot 42, Gulshan Ave, Dhaka',
    clientName: 'Navana Urban Developments',
    siteManager: 'Site Admin',
    startDateIso: '2026-08-01',
    status: 'ACTIVE',
    notes: 'Migrated default primary site',
  };

  const sites = raw.sites && raw.sites.length > 0 ? raw.sites : [defaultSite];

  return {
    schemaVersion: BACKUP_SCHEMA_VERSION,
    language: raw.language ?? 'en',
    activeRole: raw.activeRole ?? 'ADMIN',
    selectedSiteId: raw.selectedSiteId || sites[0].id || DEFAULT_SITE_ID,
    selectedDateIso: raw.selectedDateIso || '2026-11-15',
    sites,
    workers: (raw.workers ?? []).map((w) => ({
      ...w,
      siteId: w.siteId || DEFAULT_SITE_ID,
      localWorkerCode: w.localWorkerCode || w.id,
    })),
    workerTransfers: raw.workerTransfers ?? [],
    attendance: (raw.attendance ?? []).map((a) => ({
      ...a,
      siteId: a.siteId || DEFAULT_SITE_ID,
    })),
    attendanceAudits: (raw.attendanceAudits ?? []).map((a) => ({
      ...a,
      siteId: a.siteId || DEFAULT_SITE_ID,
    })),
    payments: (raw.payments ?? []).map((p) => ({
      ...p,
      siteId: p.siteId || DEFAULT_SITE_ID,
    })),
    advances: (raw.advances ?? []).map((a) => ({
      ...a,
      siteId: a.siteId || DEFAULT_SITE_ID,
    })),
    allocations: (raw.allocations ?? []).map((a) => ({
      ...a,
      siteId: a.siteId || DEFAULT_SITE_ID,
    })),
    paymentAudits: (raw.paymentAudits ?? []).map((a) => ({
      ...a,
      siteId: a.siteId || DEFAULT_SITE_ID,
    })),
    payrollPeriods: (raw.payrollPeriods ?? []).map((p) => ({
      ...p,
      siteId: p.siteId || DEFAULT_SITE_ID,
    })),
    payrollAudits: (raw.payrollAudits ?? []).map((a) => ({
      ...a,
      siteId: a.siteId || DEFAULT_SITE_ID,
    })),
    dutyMultipliersBySite: raw.dutyMultipliersBySite ?? {},
    expenseCategories: raw.expenseCategories ?? [],
    expenses: (raw.expenses ?? []).map((e) => ({
      ...e,
      siteId: e.siteId || DEFAULT_SITE_ID,
    })),
    expenseAudits: raw.expenseAudits ?? [],
    userSiteAccounts: raw.userSiteAccounts ?? [],
    backupHistory: raw.backupHistory ?? [],
    syncEvents: raw.syncEvents ?? [],
  };
}

export function executeAtomicRestore(params: {
  zipBytes: Uint8Array;
  fileName: string;
  currentState: SiteLedgerPersistState;
  applyState: (nextState: SiteLedgerPersistState) => void;
  saveSafetyBackup?: (safetyZip: Uint8Array, safetyFileName: string) => void;
  simulateWriteFailure?: boolean;
}): {
  success: boolean;
  validation: BackupValidationResult;
  safetyBackupFileName: string | null;
  rolledBack: boolean;
} {
  const {
    zipBytes,
    fileName,
    currentState,
    applyState,
    saveSafetyBackup,
    simulateWriteFailure = false,
  } = params;

  const inspected = inspectAndVerifyBackupZip(zipBytes, fileName, currentState);
  if (!inspected.validation.isValid || !inspected.stagedState) {
    return {
      success: false,
      validation: inspected.validation,
      safetyBackupFileName: null,
      rolledBack: false,
    };
  }

  // Step 1: Capture pre-restore safety backup before mutating any state
  const safety = createBackupPackage(currentState);
  const safetyName = `SAFETY_PRE_RESTORE_${safety.fileName}`;
  saveSafetyBackup?.(safety.zipBytes, safetyName);

  // Step 2: Atomic swap with rollback protection on mid-restore failure
  try {
    if (simulateWriteFailure) {
      throw new Error('Simulated mid-restore I/O failure');
    }
    applyState(inspected.stagedState);
    return {
      success: true,
      validation: inspected.validation,
      safetyBackupFileName: safetyName,
      rolledBack: false,
    };
  } catch (err) {
    // Roll back cleanly to original pre-restore state
    applyState(currentState);
    return {
      success: false,
      validation: {
        ...inspected.validation,
        isValid: false,
        errors: [
          ...inspected.validation.errors,
          `Restore rolled back safely: ${err instanceof Error ? err.message : 'Write error'}`,
        ],
      },
      safetyBackupFileName: safetyName,
      rolledBack: true,
    };
  }
}

function findLatestMutationIso(state: SiteLedgerPersistState): string {
  let latest = '';
  for (const a of state.attendance) {
    if (a.updatedAtIso > latest) latest = a.updatedAtIso;
  }
  for (const p of state.payments) {
    if (p.createdAtIso > latest) latest = p.createdAtIso;
  }
  for (const e of state.expenses) {
    if (e.createdAtIso > latest) latest = e.createdAtIso;
  }
  return latest;
}
