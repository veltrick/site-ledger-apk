/**
 * Offline browser helper mirroring WorkerPhotoStorage.kt:
 * downscales a picked gallery image cleanly and assigns a unique relative path
 * inside worker_photos/ or receipt_images/ for backup compatibility.
 */
export async function processPickedWorkerPhoto(
  file: File,
  workerId: string
): Promise<{ dataUrl: string; relativePath: string }> {
  return processPickedMediaImage(file, 'worker_photos', `worker_${workerId}`);
}

export async function processPickedReceiptPhoto(
  file: File,
  expenseId: string
): Promise<{ dataUrl: string; relativePath: string }> {
  return processPickedMediaImage(file, 'receipt_images', `receipt_${expenseId}`);
}

async function processPickedMediaImage(
  file: File,
  folder: 'worker_photos' | 'receipt_images',
  prefix: string
): Promise<{ dataUrl: string; relativePath: string }> {
  const safePrefix = prefix.replace(/[^A-Za-z0-9_-]/g, '_') || 'img';
  const uniqueSuffix =
    typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? crypto.randomUUID().slice(0, 8)
      : Math.random().toString(36).slice(2, 10);
  const relativePath = `${folder}/${safePrefix}_${uniqueSuffix}.jpg`;

  const rawDataUrl = await readFileAsDataUrl(file);
  const resizedDataUrl = await downscaleImageDataUrl(rawDataUrl, 480);
  return {
    dataUrl: resizedDataUrl,
    relativePath,
  };
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function downscaleImageDataUrl(dataUrl: string, maxDimension: number): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxDimension / Math.max(img.width, img.height));
      const width = Math.max(1, Math.round(img.width * scale));
      const height = Math.max(1, Math.round(img.height * scale));
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(dataUrl);
        return;
      }
      ctx.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', 0.86));
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}
