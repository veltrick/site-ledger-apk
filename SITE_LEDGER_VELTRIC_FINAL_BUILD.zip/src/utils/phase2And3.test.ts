import assert from 'node:assert/strict';
import test from 'node:test';
import {
  DEFAULT_SITE_ID,
  PaymentAllocation,
  Site,
  SiteExpense,
  Worker,
  DailyAttendanceRecord,
  AdvanceRecord,
  PayrollPeriodRecord,
  UserSiteAccount,
} from '../types/siteLedger.ts';
import {
  BACKUP_SCHEMA_VERSION,
  createBackupPackage,
  executeAtomicRestore,
  inspectAndVerifyBackupZip,
  normalizeRestoredState,
  SiteLedgerPersistState,
} from './backupManager.ts';
import {
  computeAllSitesOverview,
  computeSiteFinancialSummary,
  computeSpreadsheetRows,
  computeSpreadsheetTotals,
  computeUnallocatedAdvanceBalance,
  computeWorkerOverallBalances,
  DEFAULT_DUTY_MULTIPLIERS,
  isLocalWorkerCodeDuplicate,
} from './wageCalculator.ts';
import { buildZipBytes, readZipEntries } from './zipBuilder.ts';

function buildFixtureState(): SiteLedgerPersistState {
  const siteA: Site = {
    id: DEFAULT_SITE_ID,
    siteName: 'Gulshan Tower Foundation',
    siteCode: 'GLS-01',
    address: 'Plot 42, Gulshan Ave',
    clientName: 'Navana',
    siteManager: 'Tariq',
    startDateIso: '2026-08-01',
    status: 'ACTIVE',
    notes: 'Primary site',
  };
  const siteB: Site = {
    id: 'SITE-BANANI',
    siteName: 'Banani Commercial Annex',
    siteCode: 'BNN-02',
    address: 'Road 11, Banani',
    clientName: 'Bengal Holdings',
    siteManager: 'Hasan',
    startDateIso: '2026-10-01',
    status: 'ACTIVE',
    notes: 'Secondary site',
  };

  const w1: Worker = {
    id: 'GLS-W1',
    siteId: DEFAULT_SITE_ID,
    localWorkerCode: 'SL-101',
    fullNameEn: 'Rafiqul Islam',
    fullNameBn: 'রফিকুল ইসলাম',
    phoneNumber: '01711-000101',
    category: 'MASON',
    joiningDateIso: '2026-08-10',
    leavingDateIso: null,
    dailyWage: 750,
    dailyFoodAllowance: 150,
    isActive: true,
    avatarUrl: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/',
    photoPath: 'worker_photos/worker_GLS-W1.jpg',
  };
  const w2: Worker = {
    id: 'BNN-W1',
    siteId: 'SITE-BANANI',
    localWorkerCode: 'SL-101', // same localWorkerCode allowed in a different site!
    fullNameEn: 'Habibur Rahman',
    fullNameBn: 'হাবিবুর রহমান',
    phoneNumber: '01812-000201',
    category: 'STEEL_FIXER',
    joiningDateIso: '2026-10-05',
    leavingDateIso: null,
    dailyWage: 800,
    dailyFoodAllowance: 150,
    isActive: true,
    avatarUrl: null,
    photoPath: null,
  };

  const attendance: DailyAttendanceRecord[] = [
    {
      dateIso: '2026-11-10',
      workerId: 'GLS-W1',
      siteId: DEFAULT_SITE_ID,
      dutyType: 'FULL_DUTY',
      dailyWageSnapshot: 750,
      multiplierSnapshot: 1.0,
      earnedAmount: 750,
      note: '',
      updatedAtIso: '2026-11-10T17:00:00',
      updatedByRole: 'ADMIN',
    },
    {
      dateIso: '2026-11-11',
      workerId: 'BNN-W1',
      siteId: 'SITE-BANANI',
      dutyType: 'ONE_AND_HALF_DUTY',
      dailyWageSnapshot: 800,
      multiplierSnapshot: 1.5,
      earnedAmount: 1200,
      note: '',
      updatedAtIso: '2026-11-11T19:00:00',
      updatedByRole: 'ADMIN',
    },
  ];

  const allocations: PaymentAllocation[] = [
    {
      allocationId: 'AL-1',
      siteId: DEFAULT_SITE_ID,
      sourceType: 'PAYMENT',
      sourceId: 'TXN-1',
      workerId: 'GLS-W1',
      payrollPeriod: '2026-11',
      allocatedAmount: 500,
      allocatedAtIso: '2026-11-10T18:00:00',
      allocatedByRole: 'ACCOUNTANT',
      note: 'Part paid',
      isVoided: false,
    },
  ];

  const expenses: SiteExpense[] = [
    {
      id: 'EXP-1',
      siteId: DEFAULT_SITE_ID,
      expenseDateIso: '2026-11-12',
      categoryId: 'CAT-CEMENT',
      title: 'OPC Cement batch',
      amount: 12000,
      vendorName: 'Meghna Supply',
      paymentMethod: 'BANK',
      referenceNo: 'CHQ-1',
      notes: '',
      receiptPath: 'receipt_images/receipt_EXP-1.jpg',
      receiptDataUrl: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/',
      recordedByRole: 'ACCOUNTANT',
      createdAtIso: '2026-11-12T12:00:00',
      isVoided: false,
    },
    {
      id: 'EXP-VOID',
      siteId: DEFAULT_SITE_ID,
      expenseDateIso: '2026-11-12',
      categoryId: 'CAT-FOOD',
      title: 'Duplicate snack voucher',
      amount: 9999,
      vendorName: 'Tea Shop',
      paymentMethod: 'CASH',
      referenceNo: 'V-9',
      notes: 'Reversed',
      receiptPath: null,
      receiptDataUrl: null,
      recordedByRole: 'ADMIN',
      createdAtIso: '2026-11-12T13:00:00',
      isVoided: true,
    },
    {
      id: 'EXP-2',
      siteId: 'SITE-BANANI',
      expenseDateIso: '2026-11-13',
      categoryId: 'CAT-TRANSPORT',
      title: 'Crane rental',
      amount: 4500,
      vendorName: 'Karim Transport',
      paymentMethod: 'CASH',
      referenceNo: 'V-2',
      notes: '',
      receiptPath: null,
      receiptDataUrl: null,
      recordedByRole: 'ADMIN',
      createdAtIso: '2026-11-13T14:00:00',
      isVoided: false,
    },
  ];

  const advances: AdvanceRecord[] = [
    {
      id: 'ADV-1',
      siteId: DEFAULT_SITE_ID,
      workerId: 'GLS-W1',
      advanceDateIso: '2026-11-05',
      amount: 400,
      referenceNo: 'A-1',
      note: 'Advance',
      recordedByRole: 'ADMIN',
      createdAtIso: '2026-11-05T10:00:00',
      isVoided: false,
    },
  ];

  const payrollPeriods: PayrollPeriodRecord[] = [
    {
      siteId: DEFAULT_SITE_ID,
      periodIso: '2026-11',
      status: 'OPEN',
      finalizedAtIso: null,
      finalizedByRole: null,
      reopenedAtIso: null,
      reopenedByRole: null,
      notes: '',
    },
    {
      siteId: 'SITE-BANANI',
      periodIso: '2026-11',
      status: 'OPEN',
      finalizedAtIso: null,
      finalizedByRole: null,
      reopenedAtIso: null,
      reopenedByRole: null,
      notes: '',
    },
  ];

  const userSiteAccounts: UserSiteAccount[] = [
    {
      userId: 'USER-ADMIN',
      displayName: 'Admin',
      role: 'ADMIN',
      assignedSiteIds: [DEFAULT_SITE_ID, 'SITE-BANANI'],
      canManageAllSites: true,
    },
    {
      userId: 'USER-MANAGER',
      displayName: 'Banani Manager',
      role: 'MANAGER',
      assignedSiteIds: ['SITE-BANANI'],
      canManageAllSites: false,
    },
  ];

  return {
    schemaVersion: BACKUP_SCHEMA_VERSION,
    language: 'bn',
    activeRole: 'ADMIN',
    selectedSiteId: DEFAULT_SITE_ID,
    selectedDateIso: '2026-11-15',
    sites: [siteA, siteB],
    workers: [w1, w2],
    workerTransfers: [],
    attendance,
    attendanceAudits: [],
    payments: [],
    advances,
    allocations,
    paymentAudits: [],
    payrollPeriods,
    payrollAudits: [],
    dutyMultipliersBySite: {
      [DEFAULT_SITE_ID]: DEFAULT_DUTY_MULTIPLIERS,
      'SITE-BANANI': DEFAULT_DUTY_MULTIPLIERS,
    },
    expenseCategories: [{ id: 'CAT-CEMENT', nameEn: 'Cement', nameBn: 'সিমেন্ট', isSystemDefault: true }],
    expenses,
    expenseAudits: [],
    userSiteAccounts,
    backupHistory: [],
    syncEvents: [],
  };
}

// =========================================================================
// PHASE 2: OFFLINE BACKUP & ATOMIC RESTORE TESTS
// =========================================================================

test('Phase 2.1: Full offline backup ZIP creation -> data wipe -> SHA-256 verified atomic restore preserves 100% of records & media', () => {
  const original = buildFixtureState();
  const created = createBackupPackage(original, new Date('2026-11-15T14:35:00'));

  assert.match(created.fileName, /^SITE_LEDGER_BACKUP_2026_11_15_14_35\.zip$/);
  assert.equal(created.historyRecord.verifiedStatus, 'VERIFIED');
  assert.equal(created.historyRecord.counts.sites, 2);
  assert.equal(created.historyRecord.counts.workers, 2);
  assert.equal(created.historyRecord.counts.workerPhotos, 1);
  assert.equal(created.historyRecord.counts.receiptImages, 1);

  const entries = readZipEntries(created.zipBytes);
  const paths = entries.map((e) => e.path);
  assert.ok(paths.includes('backup_manifest.json'));
  assert.ok(paths.includes('metadata/schema_summary.json'));
  assert.ok(paths.includes('database/site_ledger_snapshot.json'));
  assert.ok(paths.includes('worker_photos/worker_GLS-W1.jpg'));
  assert.ok(paths.includes('receipt_images/receipt_EXP-1.jpg'));

  // Zero plaintext secrets or cloud tokens stored anywhere inside backup archive
  for (const e of entries) {
    const asText = new TextDecoder().decode(e.bytes);
    assert.ok(!asText.includes('GEMINI_API_KEY'));
    assert.ok(!asText.includes('access_token'));
    assert.ok(!asText.includes('Bearer '));
  }

  // Simulate wiped live app state before restore
  let liveState: SiteLedgerPersistState = {
    ...original,
    workers: [],
    sites: [original.sites[0]],
    attendance: [],
    expenses: [],
    advances: [],
    allocations: [],
  };

  let safetySavedName = '';
  const result = executeAtomicRestore({
    zipBytes: created.zipBytes,
    fileName: created.fileName,
    currentState: liveState,
    applyState: (next) => {
      liveState = next;
    },
    saveSafetyBackup: (_bytes, name) => {
      safetySavedName = name;
    },
  });

  assert.equal(result.success, true);
  assert.equal(result.rolledBack, false);
  assert.ok(safetySavedName.startsWith('SAFETY_PRE_RESTORE_SITE_LEDGER_BACKUP_'));
  assert.equal(liveState.sites.length, 2);
  assert.equal(liveState.workers.length, 2);
  assert.equal(liveState.workers[0].photoPath, 'worker_photos/worker_GLS-W1.jpg');
  assert.equal(liveState.expenses.length, 3);
  assert.equal(liveState.expenses[0].receiptPath, 'receipt_images/receipt_EXP-1.jpg');
  assert.equal(liveState.language, 'bn');
});

test('Phase 2.2: Corrupted ZIP bytes & tampered SHA-256 payload are rejected without modifying live state', () => {
  const original = buildFixtureState();
  const created = createBackupPackage(original, new Date('2026-11-15T15:00:00'));

  // 1) Completely malformed bytes
  let liveState = original;
  const corruptResult = executeAtomicRestore({
    zipBytes: new Uint8Array([1, 2, 3, 4, 5, 99]),
    fileName: 'corrupt.zip',
    currentState: liveState,
    applyState: (next) => {
      liveState = next;
    },
  });
  assert.equal(corruptResult.success, false);
  assert.equal(liveState.workers.length, 2);

  // 2) Valid ZIP structure where database JSON was altered without updating manifest SHA-256
  const entries = readZipEntries(created.zipBytes);
  const tamperedZip = buildZipBytes(
    entries.map((e) => {
      if (e.path === 'database/site_ledger_snapshot.json') {
        const altered = new TextDecoder().decode(e.bytes).replace('Rafiqul Islam', 'Tampered Name');
        return { path: e.path, content: altered };
      }
      return { path: e.path, content: e.bytes };
    })
  );

  const tamperedCheck = inspectAndVerifyBackupZip(tamperedZip, 'tampered.zip', original);
  assert.equal(tamperedCheck.validation.isValid, false);
  assert.equal(tamperedCheck.validation.checksumsMatched, false);
  assert.ok(tamperedCheck.validation.errors.some((err) => err.includes('SHA-256')));
});

test('Phase 2.3: Older backup warning flag triggers & simulated write failure rolls back atomically', () => {
  const olderState = buildFixtureState();
  const olderBackup = createBackupPackage(olderState, new Date('2026-11-01T09:00:00'));

  const newerLiveState: SiteLedgerPersistState = {
    ...olderState,
    workers: [
      ...olderState.workers,
      {
        ...olderState.workers[0],
        id: 'NEW-W3',
        localWorkerCode: 'SL-999',
        fullNameEn: 'New Worker After Backup',
      },
    ],
  };

  const inspection = inspectAndVerifyBackupZip(
    olderBackup.zipBytes,
    olderBackup.fileName,
    newerLiveState
  );
  assert.equal(inspection.validation.isValid, true);
  assert.equal(inspection.validation.isOlderThanCurrentData, true);
  assert.ok(inspection.validation.warnings.length > 0);

  let stateRef = newerLiveState;
  const failResult = executeAtomicRestore({
    zipBytes: olderBackup.zipBytes,
    fileName: olderBackup.fileName,
    currentState: newerLiveState,
    applyState: (next) => {
      stateRef = next;
    },
    simulateWriteFailure: true,
  });

  assert.equal(failResult.success, false);
  assert.equal(failResult.rolledBack, true);
  assert.equal(stateRef.workers.length, 3);
  assert.equal(stateRef.workers[2].id, 'NEW-W3');
});

// =========================================================================
// PHASE 3: MULTI-SITE MANAGEMENT & EXPENSES TESTS
// =========================================================================

test('Phase 3.1: Strict site isolation & duplicate localWorkerCode blocked per site while allowed across sites', () => {
  const state = buildFixtureState();

  // SL-101 already exists in SITE-MAIN and SITE-BANANI
  assert.equal(isLocalWorkerCodeDuplicate(DEFAULT_SITE_ID, 'SL-101', null, state.workers), true);
  assert.equal(isLocalWorkerCodeDuplicate('SITE-BANANI', 'sl-101', null, state.workers), true);
  // Editing the same worker doesn't flag self as duplicate
  assert.equal(isLocalWorkerCodeDuplicate(DEFAULT_SITE_ID, 'SL-101', 'GLS-W1', state.workers), false);
  // Same code in a brand new 3rd site is allowed
  assert.equal(isLocalWorkerCodeDuplicate('SITE-DHANMONDI', 'SL-101', null, state.workers), false);

  const mainFinance = computeSiteFinancialSummary(
    state.sites[0],
    state.workers,
    state.attendance,
    state.allocations,
    state.expenses
  );
  const bananiFinance = computeSiteFinancialSummary(
    state.sites[1],
    state.workers,
    state.attendance,
    state.allocations,
    state.expenses
  );

  // Gulshan: 750 earned, 500 paid, 250 outstanding, 12000 expense (voided 9999 excluded)
  assert.equal(mainFinance.totalEarnedPayroll, 750);
  assert.equal(mainFinance.totalPaidPayroll, 500);
  assert.equal(mainFinance.totalOutstandingPayroll, 250);
  assert.equal(mainFinance.totalGeneralExpenses, 12000);

  // Banani: 1200 earned, 0 paid, 1200 outstanding, 4500 expense
  assert.equal(bananiFinance.totalEarnedPayroll, 1200);
  assert.equal(bananiFinance.totalPaidPayroll, 0);
  assert.equal(bananiFinance.totalOutstandingPayroll, 1200);
  assert.equal(bananiFinance.totalGeneralExpenses, 4500);
});

test('Phase 3.2: Worker site transfer preserves prior site historical earnings & balances accurately', () => {
  const state = buildFixtureState();
  // Transfer GLS-W1 from SITE-MAIN to SITE-BANANI with new local code BNN-105
  const transferredWorkers = state.workers.map((w) =>
    w.id === 'GLS-W1' ? { ...w, siteId: 'SITE-BANANI', localWorkerCode: 'BNN-105' } : w
  );
  const postTransferAttendance: DailyAttendanceRecord[] = [
    ...state.attendance,
    {
      dateIso: '2026-11-14',
      workerId: 'GLS-W1',
      siteId: 'SITE-BANANI',
      dutyType: 'DOUBLE_DUTY',
      dailyWageSnapshot: 750,
      multiplierSnapshot: 2.0,
      earnedAmount: 1500,
      note: 'Post transfer shift at Banani',
      updatedAtIso: '2026-11-14T20:00:00',
      updatedByRole: 'ADMIN',
    },
  ];

  // Prior site Gulshan still keeps GLS-W1's 750 earned & 500 paid
  const gulshanBalances = computeWorkerOverallBalances(
    'GLS-W1',
    postTransferAttendance,
    state.allocations,
    DEFAULT_SITE_ID
  );
  assert.equal(gulshanBalances.totalEarned, 750);
  assert.equal(gulshanBalances.totalPaid, 500);

  // Cross-site total equals exact combined total (750 + 1500 = 2250 earned, 500 paid, 1750 owed)
  const crossSiteBalances = computeWorkerOverallBalances(
    'GLS-W1',
    postTransferAttendance,
    state.allocations,
    null
  );
  assert.equal(crossSiteBalances.totalEarned, 2250);
  assert.equal(crossSiteBalances.totalPaid, 500);
  assert.equal(crossSiteBalances.outstanding, 1750);

  // All-Sites Consolidated Spreadsheet includes GLS-W1 row under Gulshan AND Banani separately without double counting
  const allRows = computeSpreadsheetRows({
    year: 2026,
    month: 11,
    selectedSiteId: DEFAULT_SITE_ID,
    allSitesMode: true,
    sites: state.sites,
    workers: transferredWorkers,
    allAttendance: postTransferAttendance,
    allAllocations: state.allocations,
    periodRecords: state.payrollPeriods,
  });
  const totals = computeSpreadsheetTotals(allRows);
  // Gulshan: 750 + Banani (BNN-W1 1200 + GLS-W1 1500 = 2700) => Total 3450
  assert.equal(totals.totalEarnedSalary, 3450);
  assert.equal(totals.totalPaidSalary, 500);
  assert.equal(totals.totalOutstandingSalary, 2950);
});

test('Phase 3.3: Non-destructive pre-v6 -> v6 migration preserves all workers, photos, advances & RBAC filtering', () => {
  const preV6Raw = {
    language: 'en' as const,
    activeRole: 'ADMIN' as const,
    workers: [
      {
        id: 'SL-LEGACY-1',
        fullNameEn: 'Legacy Mason',
        fullNameBn: 'পুরানো মিস্ত্রি',
        phoneNumber: '01700-123123',
        category: 'MASON' as const,
        joiningDateIso: '2026-06-01',
        leavingDateIso: null,
        dailyWage: 700,
        dailyFoodAllowance: 100,
        isActive: true,
        avatarUrl: null,
        photoPath: 'worker_photos/worker_SL-LEGACY-1.jpg',
      } as unknown as Worker,
    ],
    attendance: [
      {
        dateIso: '2026-10-10',
        workerId: 'SL-LEGACY-1',
        dutyType: 'FULL_DUTY' as const,
        dailyWageSnapshot: 700,
        multiplierSnapshot: 1.0,
        earnedAmount: 700,
        note: 'Legacy attendance',
        updatedAtIso: '2026-10-10T17:00:00',
        updatedByRole: 'ADMIN' as const,
      } as unknown as DailyAttendanceRecord,
    ],
  };

  const migrated = normalizeRestoredState(preV6Raw);
  assert.equal(migrated.schemaVersion, BACKUP_SCHEMA_VERSION);
  assert.equal(migrated.sites[0].id, DEFAULT_SITE_ID);
  assert.equal(migrated.workers[0].siteId, DEFAULT_SITE_ID);
  assert.equal(migrated.workers[0].localWorkerCode, 'SL-LEGACY-1');
  assert.equal(migrated.workers[0].photoPath, 'worker_photos/worker_SL-LEGACY-1.jpg');
  assert.equal(migrated.attendance[0].siteId, DEFAULT_SITE_ID);

  // RBAC restriction on All-Sites Overview
  const state = buildFixtureState();
  const managerAllowed = new Set(['SITE-BANANI']);
  const overviewForManager = computeAllSitesOverview(
    state.sites,
    state.workers,
    state.attendance,
    state.allocations,
    state.expenses,
    null,
    managerAllowed
  );
  assert.equal(overviewForManager.perSiteSummaries.length, 1);
  assert.equal(overviewForManager.perSiteSummaries[0].site.id, 'SITE-BANANI');
  assert.equal(overviewForManager.combinedGeneralExpenses, 4500);
  assert.equal(
    computeUnallocatedAdvanceBalance('GLS-W1', state.advances, state.allocations),
    400
  );
});

test('Phase 3.4: 500-worker multi-site consolidated spreadsheet matches individual site totals', () => {
  const state = buildFixtureState();
  const workers500: Worker[] = Array.from({ length: 500 }, (_, i) => ({
    ...state.workers[0],
    id: `MS-${i + 1}`,
    siteId: i % 2 === 0 ? DEFAULT_SITE_ID : 'SITE-BANANI',
    localWorkerCode: `LOC-${String(i + 1).padStart(3, '0')}`,
  }));
  const att500: DailyAttendanceRecord[] = workers500.map((w, i) => ({
    dateIso: '2026-11-15',
    workerId: w.id,
    siteId: w.siteId,
    dutyType: i % 2 === 0 ? 'FULL_DUTY' : 'HALF_DUTY',
    dailyWageSnapshot: 600,
    multiplierSnapshot: i % 2 === 0 ? 1.0 : 0.5,
    earnedAmount: i % 2 === 0 ? 600 : 300,
    note: '',
    updatedAtIso: '2026-11-15T17:00:00',
    updatedByRole: 'ADMIN',
  }));

  const rowsA = computeSpreadsheetRows({
    year: 2026,
    month: 11,
    selectedSiteId: DEFAULT_SITE_ID,
    allSitesMode: false,
    sites: state.sites,
    workers: workers500,
    allAttendance: att500,
    allAllocations: [],
    periodRecords: state.payrollPeriods,
  });
  const rowsB = computeSpreadsheetRows({
    year: 2026,
    month: 11,
    selectedSiteId: 'SITE-BANANI',
    allSitesMode: false,
    sites: state.sites,
    workers: workers500,
    allAttendance: att500,
    allAllocations: [],
    periodRecords: state.payrollPeriods,
  });
  const rowsAll = computeSpreadsheetRows({
    year: 2026,
    month: 11,
    selectedSiteId: DEFAULT_SITE_ID,
    allSitesMode: true,
    sites: state.sites,
    workers: workers500,
    allAttendance: att500,
    allAllocations: [],
    periodRecords: state.payrollPeriods,
  });

  const tA = computeSpreadsheetTotals(rowsA);
  const tB = computeSpreadsheetTotals(rowsB);
  const tAll = computeSpreadsheetTotals(rowsAll);

  assert.equal(tAll.totalWorkers, tA.totalWorkers + tB.totalWorkers);
  assert.equal(tAll.totalEarnedSalary, tA.totalEarnedSalary + tB.totalEarnedSalary);
  assert.equal(tAll.totalDutyUnits, tA.totalDutyUnits + tB.totalDutyUnits);
  assert.equal(tAll.totalEarnedSalary, 250 * 600 + 250 * 300);
});
