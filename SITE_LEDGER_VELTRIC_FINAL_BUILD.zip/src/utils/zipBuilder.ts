// Pure TypeScript STORE ZIP builder & reader with CRC32 integrity verification.
// Supports both Android Studio project source exports and SITE LEDGER offline backups.

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

export function crc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    crc = CRC_TABLE[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

export interface ZipInputFile {
  path: string;
  content: string | Uint8Array;
}

export interface ParsedZipEntry {
  path: string;
  bytes: Uint8Array;
  expectedCrc32: number;
  actualCrc32: number;
  crcValid: boolean;
}

export function buildZipBytes(files: ZipInputFile[]): Uint8Array {
  const encoder = new TextEncoder();
  const localParts: Uint8Array[] = [];
  const centralParts: Uint8Array[] = [];
  let offset = 0;

  for (const file of files) {
    const nameBytes = encoder.encode(file.path);
    const dataBytes =
      typeof file.content === 'string'
        ? encoder.encode(file.content)
        : file.content;
    const crc = crc32(dataBytes);

    const localHeader = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(localHeader.buffer);
    lv.setUint32(0, 0x04034b50, true); // Local file header signature
    lv.setUint16(4, 20, true);
    lv.setUint16(6, 0x0800, true); // UTF-8
    lv.setUint16(8, 0, true); // STORE
    lv.setUint16(10, 0, true);
    lv.setUint16(12, 0x5421, true);
    lv.setUint32(14, crc, true);
    lv.setUint32(18, dataBytes.length, true);
    lv.setUint32(22, dataBytes.length, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true);
    localHeader.set(nameBytes, 30);

    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(centralHeader.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0x0800, true);
    cv.setUint16(10, 0, true);
    cv.setUint16(12, 0, true);
    cv.setUint16(14, 0x5421, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, dataBytes.length, true);
    cv.setUint32(24, dataBytes.length, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint16(30, 0, true);
    cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true);
    cv.setUint16(36, 0, true);
    cv.setUint32(38, 0, true);
    cv.setUint32(42, offset, true);
    centralHeader.set(nameBytes, 46);

    localParts.push(localHeader, dataBytes);
    centralParts.push(centralHeader);
    offset += localHeader.length + dataBytes.length;
  }

  let centralSize = 0;
  for (const part of centralParts) {
    centralSize += part.length;
  }

  const endRecord = new Uint8Array(22);
  const ev = new DataView(endRecord.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(4, 0, true);
  ev.setUint16(6, 0, true);
  ev.setUint16(8, files.length, true);
  ev.setUint16(10, files.length, true);
  ev.setUint32(12, centralSize, true);
  ev.setUint32(16, offset, true);
  ev.setUint16(20, 0, true);

  const totalLength =
    offset + centralSize + endRecord.length;
  const output = new Uint8Array(totalLength);
  let cursor = 0;
  for (const part of localParts) {
    output.set(part, cursor);
    cursor += part.length;
  }
  for (const part of centralParts) {
    output.set(part, cursor);
    cursor += part.length;
  }
  output.set(endRecord, cursor);
  return output;
}

export function buildZipBlob(files: ZipInputFile[]): Blob {
  const bytes = buildZipBytes(files);
  return new Blob([Uint8Array.from(bytes)], { type: 'application/zip' });
}

/**
 * Parses a STORE (method 0) ZIP archive created by SITE LEDGER or standard ZIP tools,
 * validating End-Of-Central-Directory, Local File Headers, lengths, and CRC-32 checksums.
 */
export function readZipEntries(bytes: Uint8Array): ParsedZipEntry[] {
  if (bytes.length < 22) {
    throw new Error('Corrupted ZIP: file too short');
  }
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);

  // Locate End of Central Directory (0x06054b50) near tail
  let eocdOffset = -1;
  const minScan = Math.max(0, bytes.length - 65557);
  for (let i = bytes.length - 22; i >= minScan; i--) {
    if (view.getUint32(i, true) === 0x06054b50) {
      eocdOffset = i;
      break;
    }
  }
  if (eocdOffset < 0) {
    throw new Error('Corrupted ZIP: End of Central Directory signature not found');
  }

  const totalEntries = view.getUint16(eocdOffset + 10, true);
  const centralSize = view.getUint32(eocdOffset + 12, true);
  const centralOffset = view.getUint32(eocdOffset + 16, true);
  if (centralOffset + centralSize > eocdOffset) {
    throw new Error('Corrupted ZIP: central directory bounds invalid');
  }

  const decoder = new TextDecoder();
  const entries: ParsedZipEntry[] = [];
  let cdCursor = centralOffset;

  for (let i = 0; i < totalEntries; i++) {
    if (cdCursor + 46 > bytes.length || view.getUint32(cdCursor, true) !== 0x02014b50) {
      throw new Error('Corrupted ZIP: invalid central directory header');
    }
    const compressionMethod = view.getUint16(cdCursor + 10, true);
    if (compressionMethod !== 0) {
      throw new Error(`Unsupported compression method ${compressionMethod}; expected STORE (0)`);
    }
    const expectedCrc32 = view.getUint32(cdCursor + 16, true);
    const compressedSize = view.getUint32(cdCursor + 20, true);
    const uncompressedSize = view.getUint32(cdCursor + 24, true);
    const nameLen = view.getUint16(cdCursor + 28, true);
    const extraLen = view.getUint16(cdCursor + 30, true);
    const commentLen = view.getUint16(cdCursor + 32, true);
    const localHeaderOffset = view.getUint32(cdCursor + 42, true);

    if (compressedSize !== uncompressedSize) {
      throw new Error('Corrupted ZIP: compressed vs uncompressed size mismatch');
    }

    if (
      localHeaderOffset + 30 > bytes.length ||
      view.getUint32(localHeaderOffset, true) !== 0x04034b50
    ) {
      throw new Error('Corrupted ZIP: invalid local file header signature');
    }
    const lhNameLen = view.getUint16(localHeaderOffset + 26, true);
    const lhExtraLen = view.getUint16(localHeaderOffset + 28, true);
    const dataStart = localHeaderOffset + 30 + lhNameLen + lhExtraLen;
    const dataEnd = dataStart + uncompressedSize;
    if (dataEnd > bytes.length) {
      throw new Error('Corrupted ZIP: entry payload truncated');
    }

    const path = decoder.decode(bytes.subarray(cdCursor + 46, cdCursor + 46 + nameLen));
    const entryBytes = bytes.slice(dataStart, dataEnd);
    const actualCrc32 = crc32(entryBytes);

    entries.push({
      path,
      bytes: entryBytes,
      expectedCrc32,
      actualCrc32,
      crcValid: expectedCrc32 === actualCrc32,
    });

    cdCursor += 46 + nameLen + extraLen + commentLen;
  }

  return entries;
}
